// Copyright Epic Games, Inc. All Rights Reserved.


#include "CockpitPortGameModeBase.h"

#include "FSendThread.h"

#include "SendCockpitPort.h"
#include "UDPCockpitPort.h"

ACockpitPortGameModeBase::ACockpitPortGameModeBase()
{
	 
}

void ACockpitPortGameModeBase::BeginPlay()
{
	Super::BeginPlay();
	PlaneModel=ReadINIFileInt(TEXT("DeafaultSetting"),TEXT("Index"));
	
	//向上位机发送查询指令，分8个线程
	for(int32 a=0;a<SendPorts.Num();a++)
	{
		MyObject=GetWorld()->SpawnActor<ASendCockpitPort>(ASendCockpitPort::StaticClass(),FVector::ZeroVector,FRotator::ZeroRotator);
		MyObject->SendPort=SendPorts[a];
		MyThread=new FSendThread(MyObject);
		MyThread->SocketIP=ReadINIFileString(TEXT("DeafaultSetting"),TEXT("ServerIP"));
		MyThread->Port=SendPorts[a];
		MyThread->PlaneIndex=PlaneModel;
		MyThread->Index=1;
		MyThread->Thread = FRunnableThread::Create(MyThread, TEXT("MyThread"));
		SendCockpitPorts.Add(MyObject);
		SendThreads.Add(MyThread);
	}
	//航电发包线程
	MyObject=GetWorld()->SpawnActor<ASendCockpitPort>(ASendCockpitPort::StaticClass(),FVector::ZeroVector,FRotator::ZeroRotator);
	MyObject->PlaneIndex=ReadINIFileInt(TEXT("DeafaultSetting"),TEXT("Index"));
	MyThread=new FSendThread(MyObject);
	MyThread->SocketIP=ReadINIFileString(TEXT("Avionics"),TEXT("IP"));
	MyThread->Port=ReadINIFileInt(TEXT("Avionics"),TEXT("Port"));
	MyThread->Index=2;
	MyThread->Thread=FRunnableThread::Create(MyThread,TEXT("MYThread"));
	SendCockpitPorts.Add(MyObject);
	SendThreads.Add(MyThread);
	//飞防发包线程
	MyObject=GetWorld()->SpawnActor<ASendCockpitPort>(ASendCockpitPort::StaticClass(),FVector::ZeroVector,FRotator::ZeroRotator);
	MyObject->PlaneIndex=ReadINIFileInt(TEXT("DeafaultSetting"),TEXT("Index"));
	MyThread=new FSendThread(MyObject);
	MyThread->SocketIP=ReadINIFileString(TEXT("FS"),TEXT("IP"));
	MyThread->Port=ReadINIFileInt(TEXT("FS"),TEXT("Port"));
	MyThread->Index=3;
	MyThread->Thread=FRunnableThread::Create(MyThread,TEXT("FSThread"));
	SendCockpitPorts.Add(MyObject);
	SendThreads.Add(MyThread);
	GetWorld()->SpawnActor<ASendCockpitPort>(ASendCockpitPort::StaticClass(),FVector::ZeroVector,FRotator::ZeroRotator);

	GetWorld()->SpawnActor<AUDPCockpitPort>(AUDPCockpitPort::StaticClass(),FVector::ZeroVector,FRotator::ZeroRotator);
	
	// 可以在需要的时候等待线程完成
	// MyThread->Thread->WaitForCompletion();
	// 注意：在实际项目中，可能需要更好的线程同步和异常处理机制
}

void ACockpitPortGameModeBase::EndPlay(const EEndPlayReason::Type EndPlayReason)
{

	Super::EndPlay(EndPlayReason);
	
	for (auto b:SendThreads)
	{
		b->Stop();
		b->Thread->Kill(true);// 如果线程正在执行，则等待它完成
		delete b->Thread;
		b->Thread=nullptr;
	}
	
}



FString ACockpitPortGameModeBase::ReadINIFileString(FString Section,FString Key)
{
	
	FString Name;
	
	bool success;
	success = GConfig->GetString(*Section, *Key, Name, FPaths::ProjectDir()+TEXT("Content/Info.ini"));
	
	if (success)
	{
		int a=0;
		UE_LOG(LogTemp, Warning, TEXT("IP:%s"), *Name);
		return Name;
	}
	
	return " ";
}
int32 ACockpitPortGameModeBase::ReadINIFileInt(FString Section, FString Key)
{
		
	int32 Name;
	
	bool success;
	success = GConfig->GetInt(*Section, *Key, Name, FPaths::ProjectDir()+TEXT("Content/Info.ini"));
	
	if (success)
	{
		UE_LOG(LogTemp, Warning, TEXT("IP:%d"), Name);
		return Name;
	}
	
	return 0;
}