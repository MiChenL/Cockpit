// Fill out your copyright notice in the Description page of Project Settings.


#include "UDPCockpitPort.h"
#include <Runtime/Networking/Public/Interfaces/IPv4/IPv4Endpoint.h>
#include <Runtime/Networking/Public/Interfaces/IPv4/IPv4Address.h>

#include "CockpitPortGameStateBase.h"
#include "CockpitPort/CockpitPortGameModeBase.h"
#include "Kismet/GameplayStatics.h"

// Sets default values
AUDPCockpitPort::AUDPCockpitPort()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	FrameHeaderArray10.Add(4001,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x10, 0x01});
	FrameHeaderArray10.Add(4002,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x10, 0x02});
	FrameHeaderArray10.Add(4003,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x10, 0x03});
	FrameHeaderArray10.Add(4004,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x10, 0x04});
	FrameHeaderArray10.Add(4005,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x10, 0x05});
	FrameHeaderArray10.Add(4006,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x10, 0x06});
	FrameHeaderArray10.Add(4007,{0x07, 0x03, 0x02});
	FrameHeaderArray10.Add(4008,{0x08, 0x03, 0x02});

	FrameHeaderArray11.Add(4001,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x01});
	FrameHeaderArray11.Add(4002,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x02});
	FrameHeaderArray11.Add(4003,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x03});
	FrameHeaderArray11.Add(4004,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x04});
	FrameHeaderArray11.Add(4005,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x05});
	FrameHeaderArray11.Add(4006,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x06});
	FrameHeaderArray11.Add(4007,{0x07, 0x03, 0x02});
	FrameHeaderArray11.Add(4008,{0x08, 0x03, 0x02});

	FrameHeaderArray16.Add(4001,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x16, 0x01});
	FrameHeaderArray16.Add(4002,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x16, 0x02});
	FrameHeaderArray16.Add(4003,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x16, 0x03});
	FrameHeaderArray16.Add(4004,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x16, 0x04});
	FrameHeaderArray16.Add(4005,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x16, 0x05});
	FrameHeaderArray16.Add(4006,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x16, 0x06});
	FrameHeaderArray16.Add(4007,{0x07, 0x03, 0x02});
	FrameHeaderArray16.Add(4008,{0x08, 0x03, 0x02});

	FrameHeaderArray20.Add(4001,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x20, 0x01});
	FrameHeaderArray20.Add(4002,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x20, 0x02});
	FrameHeaderArray20.Add(4003,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x20, 0x03});
	FrameHeaderArray20.Add(4004,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x20, 0x04});
	FrameHeaderArray20.Add(4005,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x20, 0x05});
	FrameHeaderArray20.Add(4006,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x20, 0x06});
	FrameHeaderArray20.Add(4007,{0x07, 0x03, 0x02});
	FrameHeaderArray20.Add(4008,{0x08, 0x03, 0x02});
}

// Called when the game starts or when spawned
void AUDPCockpitPort::BeginPlay()
{
	Super::BeginPlay();
	GS=Cast<ACockpitPortGameStateBase>(GetWorld()->GetGameState());
	PlaneIndex=Cast<ACockpitPortGameModeBase>(GetWorld()->GetAuthGameMode())->PlaneModel;
	for(int a=0;a<8;a++)
	{
		StartUDPReceiver("ListenSocket",GetLocalIpAddress(),Ports[a]);		
	}
	
	
}

// Called every frame
void AUDPCockpitPort::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	
}

void AUDPCockpitPort::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
#if 1
	for(int i=0;i<8;i++)
	{
		FUdpSocketReceiver* Receiver = Receivers[i];
		if (Receiver)
		{
			Receiver->Stop();
			delete Receiver;
			Receiver=nullptr;
			Receivers.Remove(Receiver);
		}
		FSocket* MySocket = ListenSockets.FindRef(Ports[i]);
		if (MySocket)
		{
			MySocket->Close();
			ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(MySocket);
			ListenSockets.Remove(Ports[i]);
		}
		
	}
	
	
#endif
}

bool AUDPCockpitPort::ReadBit(uint8 ByteValue,int32 BitIndex)
{
   
    // 这里选择第四位（从右到左，从0开始计数）
    // 使用位运算获取指定位的数值
    bool BitValue = (ByteValue & (1 << BitIndex)) != 0;
   // UE_LOG(LogTemp,Log,TEXT("bits_%d:%d"),BitIndex,BitValue)
    return BitValue;
}

void AUDPCockpitPort::StartUDPReceiver(const FString& YourChosenSocketName, const FString& TheIP, const int32 ThePort)
{
    TSharedRef<FInternetAddr> targetAddr = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->CreateInternetAddr();
    FIPv4Address Addr;
    FIPv4Address::Parse(TheIP, Addr);
    FIPv4Endpoint Endpoint(FIPv4Address::Any, ThePort);  //
                               //FIPv4Endpoint Endpoint(Addr, ThePort);
    
    FSocket *ListenSocket = FUdpSocketBuilder(*YourChosenSocketName)
        .AsNonBlocking()
        .AsReusable()
        .BoundToEndpoint(Endpoint)
        .WithReceiveBufferSize(2 * 1024 * 1024);
    //BUFFER SIZE
    int32 BufferSize = 2 * 1024 * 1024;
    ListenSocket->SetSendBufferSize(BufferSize, BufferSize);
    ListenSocket->SetReceiveBufferSize(BufferSize, BufferSize);

    if (!ListenSocket)
    {
        UE_LOG(LogTemp, Warning, TEXT("No Scokets"));
        

    }
    if (ListenSocket)
    {
        UE_LOG(LogTemp, Warning, TEXT("The receiver is initialized"));
        
        FUdpSocketReceiver*Receiver = new FUdpSocketReceiver(ListenSocket, FTimespan::FromMilliseconds(10), TEXT("DEFAULT"));
#if 0
        Receiver->OnDataReceived().BindLambda([this](const FArrayReaderPtr& Data, const FIPv4Endpoint& From)
            {
                TArray<uint8> ReceiveBytes;
                ReceiveBytes.Append(Data->GetData(), Data->Num());
                FMemory::Memcpy(ReceiveBytes.GetData(), Data->GetData(), Data->Num() * sizeof(uint8));
                if (this->OnByteMessage.IsBound())
                {
                    this->OnByteMessage.Broadcast(ReceiveBytes, From.ToString());
                }

            });
#endif
        Receiver->OnDataReceived().BindUObject(this,&AUDPCockpitPort::RecvData);
        Receiver->Start();
    	ListenSockets.Add(ThePort,ListenSocket);
    	Receivers.Add(Receiver);
    }
}

void AUDPCockpitPort::RecvData(const FArrayReaderPtr& Data, const FIPv4Endpoint& From)
{
	TArray<uint8> ReceiveBytes;
	ReceiveBytes.Append(Data->GetData(), Data->Num());
	FMemory::Memcpy(ReceiveBytes.GetData(), Data->GetData(), Data->Num() * sizeof(uint8));
	//接收端口
	uint16 Port=From.Port;
	int32 ByteIndex=1;
	//帧头长度
	int32 HeaderSize;
	if(Port==4007||Port==4008)
	{
		HeaderSize=4;
	}
	else
	{
		 HeaderSize=8;
	}
	int32 add=0;
	for(int32 a=0;a<ReceiveBytes.Num()-1;a++)
	{
		add+=ReceiveBytes[a];
	}
	if(add<0)return;
	//取实际校验和和数据包中校验和
	uint8 tensPlance1=(add>>4)&0xF;
	uint8 onesPlance1=add&0xF;
	uint8 tensPlance2=(ReceiveBytes.Last()>>4)&0xF;
	uint8 onesPlance2=(ReceiveBytes.Last())&0xF;
	TMap<int32,TArray<uint8>>TempFrame;
#if 1
	switch (PlaneIndex)
	{
	case 10:TempFrame=FrameHeaderArray10;
		break;
	case 11:TempFrame=FrameHeaderArray11;
		break;
	case 16:TempFrame=FrameHeaderArray16;
		break;
	case 20:TempFrame=FrameHeaderArray20;
		break;
	}

	if(FMemory::Memcmp(ReceiveBytes.GetData(),TempFrame.Find(Port)->GetData(),HeaderSize)!=0)
	{
		int32 b=0;
		return;
		//帧头不匹配
	}
#endif
	
	//校验和匹配
	if(Port!=4007||Port!=4008)
	{
		if(tensPlance1!=tensPlance2||onesPlance1!=onesPlance2)
		{
			//校验和不匹配
			return;
		}
	
	}
	/*串口位置用于标记不同串口，具体值：0xff:  用于查询型号
	0x01:  仪表板
	0x02:  左台
	0x03: 右台 
	0x04: 驾驶杆
	0x05:油门1
	0x06:油门2
	0x07: 左刹车
	0x08: 右刹车*/
	if(PlaneIndex==10)
	{
		switch (Port)
		{
		case 4001://仪表盘
			
			ConvertBytes(AllBits1,ByteIndex,ReceiveBytes);
			ConvertStruct1_10(ReceiveBytes);
			break;
		case 4002://左台
			ConvertBytes(AllBits2,ByteIndex,ReceiveBytes);
			ConvertStruct2_10(ReceiveBytes);

			break;
		case 4003://右台
			ConvertBytes(AllBits3,ByteIndex,ReceiveBytes);
			ConvertStruct3_10(ReceiveBytes);

			break;
		case 4004://驾驶杆
			
			ConvertBytes(AllBits4,ByteIndex,ReceiveBytes);
			ConvertStruct4_10(ReceiveBytes);

			break;
		case 4005://油门1
			ConvertBytes(AllBits5,ByteIndex,ReceiveBytes);
			ConvertStruct5_10(ReceiveBytes);

			break;
		case 4006://油门2
			ConvertBytes(AllBits6,ByteIndex,ReceiveBytes);
			
			break;
		case 4007://左刹车
			if(ReceiveBytes.Num()<7)return;
			
			break;
		case 4008://右刹车
			if(ReceiveBytes.Num()<7)return;
			
			break;
		
		default:
			break;
		}
	}
	else if (PlaneIndex==11)
	{

		switch (Port)
		{
		case 4001://仪表盘
			if(ReceiveBytes.Num()<25)return;
			ConvertBytes(AllBits1,ByteIndex,ReceiveBytes);
			ConvertStruct1(ReceiveBytes);
			break;
		case 4002://左台
			ConvertBytes(AllBits2,ByteIndex,ReceiveBytes);
			ConvertStruct2(ReceiveBytes);
			break;
		case 4003://右台
			ConvertBytes(AllBits3,ByteIndex,ReceiveBytes);
			ConvertStruct3(ReceiveBytes);
			break;
		case 4004://驾驶杆
			if(ReceiveBytes.Num()!=22)return;
			ConvertBytes(AllBits4,ByteIndex,ReceiveBytes);
			ConvertStruct4(ReceiveBytes);
			break;
		case 4005://油门1
			ConvertBytes(AllBits5,ByteIndex,ReceiveBytes);
			ConvertStruct5(ReceiveBytes);
			break;
		case 4006://油门2
			ConvertBytes(AllBits6,ByteIndex,ReceiveBytes);
			ConvertStruct6(ReceiveBytes);
			break;
		case 4007://左刹车
			if(ReceiveBytes.Num()<7)return;
			curbv=(uint16)ReceiveBytes[3]<<8|(uint16)(ReceiveBytes[4]);
			GS->Fs11.pb1=GetBreakValue(0xFE2,0xF42,curbv);
			break;
		case 4008://右刹车
			if(ReceiveBytes.Num()<7)return;
			curbv2=(uint16)ReceiveBytes[3]<<8|(uint16)(ReceiveBytes[4]);
			GS->Fs11.pb2=GetBreakValue(0x58,0x102,curbv2);
			break;
		
		default:
			break;
		}

	}
	else if(PlaneIndex==16)
	{

		switch (Port)
		{
		case 4001://仪表盘
			if(ReceiveBytes.Num()<25)return;
			ConvertBytes(AllBits1,ByteIndex,ReceiveBytes);
			ConvertStruct1_16(ReceiveBytes);
			break;
		case 4002://左台
			ConvertBytes(AllBits2,ByteIndex,ReceiveBytes);
			ConvertStruct2_16(ReceiveBytes);
			break;
		case 4003://右台
			ConvertBytes(AllBits3,ByteIndex,ReceiveBytes);
			ConvertStruct3_16(ReceiveBytes);
			break;
		case 4004://驾驶杆
			if(ReceiveBytes.Num()!=22)return;
			ConvertBytes(AllBits4,ByteIndex,ReceiveBytes);
			ConvertStruct4_16(ReceiveBytes);
			break;
		case 4005://油门1
			ConvertBytes(AllBits5,ByteIndex,ReceiveBytes);
			ConvertStruct5_16(ReceiveBytes);
			break;
		case 4006://油门2
			ConvertBytes(AllBits6,ByteIndex,ReceiveBytes);
			ConvertStruct6_16(ReceiveBytes);
			break;
		case 4007://左刹车
			if(ReceiveBytes.Num()<7)return;
			
			break;
		case 4008://右刹车
			if(ReceiveBytes.Num()<7)return;
			
			break;
		
		default:
			break;
		}

	}
	else if(PlaneIndex==20)
	{
		switch (Port)
		{
		case 4001://仪表盘
			if(ReceiveBytes.Num()<25)return;
			ConvertBytes(AllBits1,ByteIndex,ReceiveBytes);
			ConvertStruct1_20(ReceiveBytes);
			break;
		case 4002://左台
			ConvertBytes(AllBits2,ByteIndex,ReceiveBytes);
			ConvertStruct2_20(ReceiveBytes);
			break;
		case 4003://右台
			ConvertBytes(AllBits3,ByteIndex,ReceiveBytes);
			ConvertStruct3_20(ReceiveBytes);
			break;
		case 4004://驾驶杆
			if(ReceiveBytes.Num()!=22)return;
			ConvertBytes(AllBits4,ByteIndex,ReceiveBytes);
			ConvertStruct4_20(ReceiveBytes);
			break;
		case 4005://油门1
			ConvertBytes(AllBits5,ByteIndex,ReceiveBytes);
			ConvertStruct5_20(ReceiveBytes);
			break;
		case 4006://油门2
			ConvertBytes(AllBits6,ByteIndex,ReceiveBytes);
			ConvertStruct6_20(ReceiveBytes);
			break;
		case 4007://左刹车
			if(ReceiveBytes.Num()<7)return;
			
			break;
		case 4008://右刹车
			if(ReceiveBytes.Num()<7)return;
			
			break;
		
		default:
			break;
		}
	}
}

void AUDPCockpitPort::ConvertBytes(TMap<int32,TArray<uint8>>&Bytes,int32& ByteIndex,TArray<uint8>RecvData)
{
	//以下过程将收到的所有数据转为二维数组Key为字节数，Value为当前字节所有位的实际数据。
	//for(auto a:RecvData)
	//{
	//	
	//	TArray<uint8> tempbits;
	//	for(int32 b=0;b<8;b++)
	//	{
	//		tempbits.Add(ReadBit(a,b));
	//		int32 c=b;
	//	}
	//	Bytes.Add(ByteIndex,tempbits);
	//	ByteIndex++;
	//}
	
	for(int a=9;a<RecvData.Num();a++)
	{
		TArray<uint8> tempbits;
		for(int32 b=0;b<8;b++)
		{
			tempbits.Add(ReadBit(RecvData[a],b));
			
		}
		Bytes.Add(ByteIndex,tempbits);
		ByteIndex++;
	}
}

void AUDPCockpitPort::ConvertStruct1_10(const TArray<uint8>&ReceiveBytes)
{
	GS->A10.Ins.Byte1bit0=AllBits1.FindRef(1)[0];
	GS->A10.Ins.Byte1bit1=AllBits1.FindRef(1)[1];
	GS->A10.Ins.Byte1bit2=AllBits1.FindRef(1)[2];
	GS->A10.Ins.Byte1bit3=AllBits1.FindRef(1)[3];
	GS->A10.Ins.Byte1bit4=AllBits1.FindRef(1)[4];
	GS->A10.Ins.Byte1bit5=AllBits1.FindRef(1)[5];
	GS->A10.Ins.Byte1bit6=AllBits1.FindRef(1)[6];
	GS->A10.Ins.Byte1bit7=AllBits1.FindRef(1)[7];
	GS->A10.Ins.Byte2bit0=AllBits1.FindRef(2)[0];
	GS->A10.Ins.Byte2bit1=AllBits1.FindRef(2)[1];
	GS->A10.Ins.Byte2bit2=AllBits1.FindRef(2)[2];
	GS->A10.Ins.Byte2bit3=AllBits1.FindRef(2)[3];
	GS->A10.Ins.Byte2bit4=AllBits1.FindRef(2)[4];
	GS->A10.Ins.Byte2bit5=AllBits1.FindRef(2)[5];
	GS->A10.Ins.Byte2bit6=AllBits1.FindRef(2)[6];
	GS->A10.Ins.Byte2bit7=AllBits1.FindRef(2)[7];
	GS->A10.Ins.Byte3bit0=AllBits1.FindRef(3)[0];
	GS->A10.Ins.Byte3bit1=AllBits1.FindRef(3)[1];
	GS->A10.Ins.Byte3bit2=AllBits1.FindRef(3)[2];
	GS->A10.Ins.Byte3bit3=AllBits1.FindRef(3)[3];
	GS->A10.Ins.Byte3bit4=AllBits1.FindRef(3)[4];
	GS->A10.Ins.Byte3bit5=AllBits1.FindRef(3)[5];
	GS->A10.Ins.Byte3bit6=AllBits1.FindRef(3)[6];
	GS->A10.Ins.Byte3bit7=AllBits1.FindRef(3)[7];
	GS->A10.Ins.Byte4bit0=AllBits1.FindRef(4)[0];
	GS->A10.Ins.Byte4bit1=AllBits1.FindRef(4)[1];
	GS->A10.Ins.Byte4bit2=AllBits1.FindRef(4)[2];
	GS->A10.Ins.Byte4bit3=AllBits1.FindRef(4)[3];
	GS->A10.Ins.Byte4bit4=AllBits1.FindRef(4)[4];
	GS->A10.Ins.Byte4bit5=AllBits1.FindRef(4)[5];
	GS->A10.Ins.Byte4bit6=AllBits1.FindRef(4)[6];
	GS->A10.Ins.Byte4bit7=AllBits1.FindRef(4)[7];
	GS->A10.Ins.Byte5bit0=AllBits1.FindRef(5)[0];
	GS->A10.Ins.Byte5bit1=AllBits1.FindRef(5)[1];
	GS->A10.Ins.Byte5bit2=AllBits1.FindRef(5)[2];
	GS->A10.Ins.Byte5bit3=AllBits1.FindRef(5)[3];
	GS->A10.Ins.Byte5bit4=AllBits1.FindRef(5)[4];
	GS->A10.Ins.Byte5bit5=AllBits1.FindRef(5)[5];
	GS->A10.Ins.Byte5bit6=AllBits1.FindRef(5)[6];
	GS->A10.Ins.Byte5bit7=AllBits1.FindRef(5)[7];
	GS->A10.Ins.Byte6bit0=AllBits1.FindRef(6)[0];
	GS->A10.Ins.Byte6bit1=AllBits1.FindRef(6)[1];
	GS->A10.Ins.Byte6bit2=AllBits1.FindRef(6)[2];
	GS->A10.Ins.Byte6bit3=AllBits1.FindRef(6)[3];
	GS->A10.Ins.Byte6bit4=AllBits1.FindRef(6)[4];
	GS->A10.Ins.Byte6bit5=AllBits1.FindRef(6)[5];
	GS->A10.Ins.Byte6bit6=AllBits1.FindRef(6)[6];
	GS->A10.Ins.Byte6bit7=AllBits1.FindRef(6)[7];
	GS->A10.Ins.Byte7bit0=AllBits1.FindRef(7)[0];
	GS->A10.Ins.Byte7bit1=AllBits1.FindRef(7)[1];
	GS->A10.Ins.Byte7bit2=AllBits1.FindRef(7)[2];
	GS->A10.Ins.Byte7bit3=AllBits1.FindRef(7)[3];
	GS->A10.Ins.Byte7bit4=AllBits1.FindRef(7)[4];
	GS->A10.Ins.Byte7bit5=AllBits1.FindRef(7)[5];
	GS->A10.Ins.Byte7bit6=AllBits1.FindRef(7)[6];
	GS->A10.Ins.Byte7bit7=AllBits1.FindRef(7)[7];
	GS->A10.Ins.Byte8bit0=AllBits1.FindRef(8)[0];
	GS->A10.Ins.Byte8bit1=AllBits1.FindRef(8)[1];
	GS->A10.Ins.Byte8bit2=AllBits1.FindRef(8)[2];
	GS->A10.Ins.Byte8bit3=AllBits1.FindRef(8)[3];
	GS->A10.Ins.Byte8bit4=AllBits1.FindRef(8)[4];
	GS->A10.Ins.Byte8bit5=AllBits1.FindRef(8)[5];
	GS->A10.Ins.Byte8bit6=AllBits1.FindRef(8)[6];
	GS->A10.Ins.Byte8bit7=AllBits1.FindRef(8)[7];
	GS->A10.Ins.Byte9bit0=AllBits1.FindRef(9)[0];
	GS->A10.Ins.Byte9bit1=AllBits1.FindRef(9)[1];
	GS->A10.Ins.Byte9bit2=AllBits1.FindRef(9)[2];
	GS->A10.Ins.Byte9bit3=AllBits1.FindRef(9)[3];
	GS->A10.Ins.Byte9bit4=AllBits1.FindRef(9)[4];
	GS->A10.Ins.Byte9bit5=AllBits1.FindRef(9)[5];
	GS->A10.Ins.Byte9bit6=AllBits1.FindRef(9)[6];
	GS->A10.Ins.Byte9bit7=AllBits1.FindRef(9)[7];
	GS->A10.Ins.Byte10bit0=AllBits1.FindRef(10)[0];
	GS->A10.Ins.Byte10bit1=AllBits1.FindRef(10)[1];
	GS->A10.Ins.Byte10bit2=AllBits1.FindRef(10)[2];
	GS->A10.Ins.Byte10bit3=AllBits1.FindRef(10)[3];
	GS->A10.Ins.Byte10bit4=AllBits1.FindRef(10)[4];
	GS->A10.Ins.Byte10bit5=AllBits1.FindRef(10)[5];
	GS->A10.Ins.Byte10bit6=AllBits1.FindRef(10)[6];
	GS->A10.Ins.Byte10bit7=AllBits1.FindRef(10)[7];
	GS->A10.Ins.Byte11bit0=AllBits1.FindRef(11)[0];
	GS->A10.Ins.Byte11bit1=AllBits1.FindRef(11)[1];
	GS->A10.Ins.Byte11bit2=AllBits1.FindRef(11)[2];
	GS->A10.Ins.Byte11bit3=AllBits1.FindRef(11)[3];
	GS->A10.Ins.Byte11bit4=AllBits1.FindRef(11)[4];
	GS->A10.Ins.Byte11bit5=AllBits1.FindRef(11)[5];
	GS->A10.Ins.Byte11bit6=AllBits1.FindRef(11)[6];
	GS->A10.Ins.Byte11bit7=AllBits1.FindRef(11)[7];
	GS->A10.Ins.Byte12bit0=AllBits1.FindRef(12)[0];
	GS->A10.Ins.Byte12bit1=AllBits1.FindRef(12)[1];
	GS->A10.Ins.Byte12bit2=AllBits1.FindRef(12)[2];
	GS->A10.Ins.Byte12bit3=AllBits1.FindRef(12)[3];
	GS->A10.Ins.Byte12bit4=AllBits1.FindRef(12)[4];
	GS->A10.Ins.Byte12bit5=AllBits1.FindRef(12)[5];
	GS->A10.Ins.Byte12bit6=AllBits1.FindRef(12)[6];
	GS->A10.Ins.Byte12bit7=AllBits1.FindRef(12)[7];
	GS->A10.Ins.Byte13bit0=AllBits1.FindRef(13)[0];
	GS->A10.Ins.Byte13bit1=AllBits1.FindRef(13)[1];
	GS->A10.Ins.Byte13bit2=AllBits1.FindRef(13)[2];
	GS->A10.Ins.Byte13bit3=AllBits1.FindRef(13)[3];
	GS->A10.Ins.Byte13bit4=AllBits1.FindRef(13)[4];
	GS->A10.Ins.Byte13bit5=AllBits1.FindRef(13)[5];
	GS->A10.Ins.Byte13bit6=AllBits1.FindRef(13)[6];
	GS->A10.Ins.Byte13bit7=AllBits1.FindRef(13)[7];
	GS->A10.Ins.Byte14bit0=AllBits1.FindRef(14)[0];
	GS->A10.Ins.Byte14bit1=AllBits1.FindRef(14)[1];
	GS->A10.Ins.Byte14bit2=AllBits1.FindRef(14)[2];
	GS->A10.Ins.Byte14bit3=AllBits1.FindRef(14)[3];
	GS->A10.Ins.Byte14bit4=AllBits1.FindRef(14)[4];
	GS->A10.Ins.Byte14bit5=AllBits1.FindRef(14)[5];
	GS->A10.Ins.Byte14bit6=AllBits1.FindRef(14)[6];
	GS->A10.Ins.Byte14bit7=AllBits1.FindRef(14)[7];
	GS->A10.Ins.Byte15bit0=AllBits1.FindRef(15)[0];
	GS->A10.Ins.Byte15bit1=AllBits1.FindRef(15)[1];
	GS->A10.Ins.Byte15bit2=AllBits1.FindRef(15)[2];
	GS->A10.Ins.Byte15bit3=AllBits1.FindRef(15)[3];
	GS->A10.Ins.Byte15bit4=AllBits1.FindRef(15)[4];
	GS->A10.Ins.Byte15bit5=AllBits1.FindRef(15)[5];
	GS->A10.Ins.Byte15bit6=AllBits1.FindRef(15)[6];
	GS->A10.Ins.Byte15bit7=AllBits1.FindRef(15)[7];
	GS->A10.Ins.Byte16bit0=AllBits1.FindRef(16)[0];
	GS->A10.Ins.Byte16bit1=AllBits1.FindRef(16)[1];
	GS->A10.Ins.Byte16bit2=AllBits1.FindRef(16)[2];
	GS->A10.Ins.Byte16bit3=AllBits1.FindRef(16)[3];
	GS->A10.Ins.Byte16bit4=AllBits1.FindRef(16)[4];
	GS->A10.Ins.Byte16bit5=AllBits1.FindRef(16)[5];
	GS->A10.Ins.Byte16bit6=AllBits1.FindRef(16)[6];
	GS->A10.Ins.Byte16bit7=AllBits1.FindRef(16)[7];
	GS->A10.Ins.Byte17bit0=AllBits1.FindRef(17)[0];
	GS->A10.Ins.Byte17bit1=AllBits1.FindRef(17)[1];
	GS->A10.Ins.Byte17bit2=AllBits1.FindRef(17)[2];
	GS->A10.Ins.Byte17bit3=AllBits1.FindRef(17)[3];
	GS->A10.Ins.Byte17bit4=AllBits1.FindRef(17)[4];
	GS->A10.Ins.Byte17bit5=AllBits1.FindRef(17)[5];
	GS->A10.Ins.Byte17bit6=AllBits1.FindRef(17)[6];
	GS->A10.Ins.Byte17bit7=AllBits1.FindRef(17)[7];
	GS->A10.Ins.Byte18bit0=AllBits1.FindRef(18)[0];
	GS->A10.Ins.Byte18bit1=AllBits1.FindRef(18)[1];
	GS->A10.Ins.Byte18bit2=AllBits1.FindRef(18)[2];
	GS->A10.Ins.Byte18bit3=AllBits1.FindRef(18)[3];
	GS->A10.Ins.Byte18bit4=AllBits1.FindRef(18)[4];
	GS->A10.Ins.Byte18bit5=AllBits1.FindRef(18)[5];
	GS->A10.Ins.Byte18bit6=AllBits1.FindRef(18)[6];
	GS->A10.Ins.Byte18bit7=AllBits1.FindRef(18)[7];
	GS->A10.Ins.Byte19bit0=AllBits1.FindRef(19)[0];
	GS->A10.Ins.Byte19bit1=AllBits1.FindRef(19)[1];
	GS->A10.Ins.Byte19bit2=AllBits1.FindRef(19)[2];
	GS->A10.Ins.Byte19bit3=AllBits1.FindRef(19)[3];
	GS->A10.Ins.Byte19bit4=AllBits1.FindRef(19)[4];
	GS->A10.Ins.Byte19bit5=AllBits1.FindRef(19)[5];
	GS->A10.Ins.Byte19bit6=AllBits1.FindRef(19)[6];
	GS->A10.Ins.Byte19bit7=AllBits1.FindRef(19)[7];
	GS->A10.Ins.Byte20bit0=AllBits1.FindRef(20)[0];
	GS->A10.Ins.Byte20bit1=AllBits1.FindRef(20)[1];
	GS->A10.Ins.Byte20bit2=AllBits1.FindRef(20)[2];
	GS->A10.Ins.Byte20bit3=AllBits1.FindRef(20)[3];
	GS->A10.Ins.Byte20bit4=AllBits1.FindRef(20)[4];
	GS->A10.Ins.Byte20bit5=AllBits1.FindRef(20)[5];
	GS->A10.Ins.Byte20bit6=AllBits1.FindRef(20)[6];
	GS->A10.Ins.Byte20bit7=AllBits1.FindRef(20)[7];

	GS->A10.Ins.Byte21=ReceiveBytes[30];
	GS->A10.Ins.Byte22=ReceiveBytes[31];
	GS->A10.Ins.Byte23=ReceiveBytes[32];
	GS->A10.Ins.Byte24=ReceiveBytes[33];
	GS->A10.Ins.Byte25=ReceiveBytes[34];
	GS->A10.Ins.Byte26=ReceiveBytes[35];
}

void AUDPCockpitPort::ConvertStruct2_10(const TArray<uint8>&ReceiveBytes)
{
	GS->A10.Lcs.Byte1bit0=AllBits2.FindRef(1)[0];
	GS->A10.Lcs.Byte1bit1=AllBits2.FindRef(1)[1];
	GS->A10.Lcs.Byte1bit2=AllBits2.FindRef(1)[2];
	GS->A10.Lcs.Byte1bit3=AllBits2.FindRef(1)[3];
	GS->A10.Lcs.Byte1bit4=AllBits2.FindRef(1)[4];
	GS->A10.Lcs.Byte1bit5=AllBits2.FindRef(1)[5];
	GS->A10.Lcs.Byte1bit6=AllBits2.FindRef(1)[6];
	GS->A10.Lcs.Byte1bit7=AllBits2.FindRef(1)[7];
	GS->A10.Lcs.Byte2bit0=AllBits2.FindRef(2)[0];
	GS->A10.Lcs.Byte2bit1=AllBits2.FindRef(2)[1];
	GS->A10.Lcs.Byte2bit2=AllBits2.FindRef(2)[2];
	GS->A10.Lcs.Byte2bit3=AllBits2.FindRef(2)[3];
	GS->A10.Lcs.Byte2bit4=AllBits2.FindRef(2)[4];
	GS->A10.Lcs.Byte2bit5=AllBits2.FindRef(2)[5];
	GS->A10.Lcs.Byte2bit6=AllBits2.FindRef(2)[6];
	GS->A10.Lcs.Byte2bit7=AllBits2.FindRef(2)[7];
	GS->A10.Lcs.Byte3bit0=AllBits2.FindRef(3)[0];
	GS->A10.Lcs.Byte3bit1=AllBits2.FindRef(3)[1];
	GS->A10.Lcs.Byte3bit2=AllBits2.FindRef(3)[2];
	GS->A10.Lcs.Byte3bit3=AllBits2.FindRef(3)[3];
	GS->A10.Lcs.Byte3bit4=AllBits2.FindRef(3)[4];
	GS->A10.Lcs.Byte3bit5=AllBits2.FindRef(3)[5];
	GS->A10.Lcs.Byte3bit6=AllBits2.FindRef(3)[6];
	GS->A10.Lcs.Byte3bit7=AllBits2.FindRef(3)[7];
	GS->A10.Lcs.Byte4bit0=AllBits2.FindRef(4)[0];
	GS->A10.Lcs.Byte4bit1=AllBits2.FindRef(4)[1];
	GS->A10.Lcs.Byte4bit2=AllBits2.FindRef(4)[2];
	GS->A10.Lcs.Byte4bit3=AllBits2.FindRef(4)[3];
	GS->A10.Lcs.Byte4bit4=AllBits2.FindRef(4)[4];
	GS->A10.Lcs.Byte4bit5=AllBits2.FindRef(4)[5];
	GS->A10.Lcs.Byte4bit6=AllBits2.FindRef(4)[6];
	GS->A10.Lcs.Byte4bit7=AllBits2.FindRef(4)[7];
	GS->A10.Lcs.Byte5bit0=AllBits2.FindRef(5)[0];
	GS->A10.Lcs.Byte5bit1=AllBits2.FindRef(5)[1];
	GS->A10.Lcs.Byte5bit2=AllBits2.FindRef(5)[2];
	GS->A10.Lcs.Byte5bit3=AllBits2.FindRef(5)[3];
	GS->A10.Lcs.Byte5bit4=AllBits2.FindRef(5)[4];
	GS->A10.Lcs.Byte5bit5=AllBits2.FindRef(5)[5];
	GS->A10.Lcs.Byte5bit6=AllBits2.FindRef(5)[6];
	GS->A10.Lcs.Byte5bit7=AllBits2.FindRef(5)[7];
	GS->A10.Lcs.Byte6bit0=AllBits2.FindRef(6)[0];
	GS->A10.Lcs.Byte6bit1=AllBits2.FindRef(6)[1];
	GS->A10.Lcs.Byte6bit2=AllBits2.FindRef(6)[2];
	GS->A10.Lcs.Byte6bit3=AllBits2.FindRef(6)[3];
	GS->A10.Lcs.Byte6bit4=AllBits2.FindRef(6)[4];
	GS->A10.Lcs.Byte6bit5=AllBits2.FindRef(6)[5];
	GS->A10.Lcs.Byte6bit6=AllBits2.FindRef(6)[6];
	GS->A10.Lcs.Byte6bit7=AllBits2.FindRef(6)[7];
	GS->A10.Lcs.Byte7bit0=AllBits2.FindRef(7)[0];
	GS->A10.Lcs.Byte7bit1=AllBits2.FindRef(7)[1];
	GS->A10.Lcs.Byte7bit2=AllBits2.FindRef(7)[2];
	GS->A10.Lcs.Byte7bit3=AllBits2.FindRef(7)[3];
	GS->A10.Lcs.Byte7bit4=AllBits2.FindRef(7)[4];
	GS->A10.Lcs.Byte7bit5=AllBits2.FindRef(7)[5];
	GS->A10.Lcs.Byte7bit6=AllBits2.FindRef(7)[6];
	GS->A10.Lcs.Byte7bit7=AllBits2.FindRef(7)[7];
	GS->A10.Lcs.Byte8bit0=AllBits2.FindRef(8)[0];

	GS->A10.Lcs.Byte9=ReceiveBytes[18];
	GS->A10.Lcs.Byte10=ReceiveBytes[19];
	GS->A10.Lcs.Byte11=ReceiveBytes[20];
	GS->A10.Lcs.Byte12=ReceiveBytes[21];
	GS->A10.Lcs.Byte13=ReceiveBytes[22];
}

void AUDPCockpitPort::ConvertStruct3_10(const TArray<uint8>&ReceiveBytes)
{
	GS->A10.Rcs.Byte1bit0=AllBits3.FindRef(1)[0];
	GS->A10.Rcs.Byte1bit1=AllBits3.FindRef(1)[1];
	GS->A10.Rcs.Byte1bit2=AllBits3.FindRef(1)[2];
	GS->A10.Rcs.Byte1bit3=AllBits3.FindRef(1)[3];
	GS->A10.Rcs.Byte1bit4=AllBits3.FindRef(1)[4];
	GS->A10.Rcs.Byte1bit5=AllBits3.FindRef(1)[5];
	GS->A10.Rcs.Byte1bit6=AllBits3.FindRef(1)[6];
	GS->A10.Rcs.Byte1bit7=AllBits3.FindRef(1)[7];
	GS->A10.Rcs.Byte2bit0=AllBits3.FindRef(2)[0];
	GS->A10.Rcs.Byte2bit1=AllBits3.FindRef(2)[1];
	GS->A10.Rcs.Byte2bit2=AllBits3.FindRef(2)[2];
	GS->A10.Rcs.Byte2bit3=AllBits3.FindRef(2)[3];
	GS->A10.Rcs.Byte2bit4=AllBits3.FindRef(2)[4];
	GS->A10.Rcs.Byte2bit5=AllBits3.FindRef(2)[5];
	GS->A10.Rcs.Byte2bit6=AllBits3.FindRef(2)[6];
	GS->A10.Rcs.Byte2bit7=AllBits3.FindRef(2)[7];
	GS->A10.Rcs.Byte3bit0=AllBits3.FindRef(3)[0];
	GS->A10.Rcs.Byte3bit1=AllBits3.FindRef(3)[1];
	GS->A10.Rcs.Byte3bit2=AllBits3.FindRef(3)[2];
	GS->A10.Rcs.Byte3bit3=AllBits3.FindRef(3)[3];
	GS->A10.Rcs.Byte3bit4=AllBits3.FindRef(3)[4];
	GS->A10.Rcs.Byte3bit5=AllBits3.FindRef(3)[5];
	GS->A10.Rcs.Byte3bit6=AllBits3.FindRef(3)[6];
	GS->A10.Rcs.Byte3bit7=AllBits3.FindRef(3)[7];
	GS->A10.Rcs.Byte4bit0=AllBits3.FindRef(4)[0];
	GS->A10.Rcs.Byte4bit1=AllBits3.FindRef(4)[1];
	GS->A10.Rcs.Byte4bit2=AllBits3.FindRef(4)[2];
	GS->A10.Rcs.Byte4bit3=AllBits3.FindRef(4)[3];
	GS->A10.Rcs.Byte4bit4=AllBits3.FindRef(4)[4];
	GS->A10.Rcs.Byte4bit5=AllBits3.FindRef(4)[5];
	GS->A10.Rcs.Byte4bit6=AllBits3.FindRef(4)[6];
	GS->A10.Rcs.Byte4bit7=AllBits3.FindRef(4)[7];
	GS->A10.Rcs.Byte5bit0=AllBits3.FindRef(5)[0];
	GS->A10.Rcs.Byte5bit1=AllBits3.FindRef(5)[1];
	GS->A10.Rcs.Byte5bit2=AllBits3.FindRef(5)[2];
	GS->A10.Rcs.Byte5bit3=AllBits3.FindRef(5)[3];
	GS->A10.Rcs.Byte5bit4=AllBits3.FindRef(5)[4];
	GS->A10.Rcs.Byte5bit5=AllBits3.FindRef(5)[5];
	GS->A10.Rcs.Byte5bit6=AllBits3.FindRef(5)[6];
	GS->A10.Rcs.Byte5bit7=AllBits3.FindRef(5)[7];
	GS->A10.Rcs.Byte6bit0=AllBits3.FindRef(6)[0];
	GS->A10.Rcs.Byte6bit1=AllBits3.FindRef(6)[1];
	GS->A10.Rcs.Byte6bit2=AllBits3.FindRef(6)[2];
	GS->A10.Rcs.Byte6bit3=AllBits3.FindRef(6)[3];
	GS->A10.Rcs.Byte6bit4=AllBits3.FindRef(6)[4];
	GS->A10.Rcs.Byte6bit5=AllBits3.FindRef(6)[5];
	GS->A10.Rcs.Byte6bit6=AllBits3.FindRef(6)[6];
	GS->A10.Rcs.Byte6bit7=AllBits3.FindRef(6)[7];
	GS->A10.Rcs.Byte7bit0=AllBits3.FindRef(7)[0];
	GS->A10.Rcs.Byte7bit1=AllBits3.FindRef(7)[1];
	GS->A10.Rcs.Byte7bit2=AllBits3.FindRef(7)[2];
	GS->A10.Rcs.Byte7bit3=AllBits3.FindRef(7)[3];
	GS->A10.Rcs.Byte7bit4=AllBits3.FindRef(7)[4];
	GS->A10.Rcs.Byte7bit5=AllBits3.FindRef(7)[5];
	GS->A10.Rcs.Byte7bit6=AllBits3.FindRef(7)[6];
	GS->A10.Rcs.Byte7bit7=AllBits3.FindRef(7)[7];
	GS->A10.Rcs.Byte8bit0=AllBits3.FindRef(8)[0];
	GS->A10.Rcs.Byte8bit1=AllBits3.FindRef(8)[1];
	GS->A10.Rcs.Byte8bit2=AllBits3.FindRef(8)[2];
	GS->A10.Rcs.Byte8bit3=AllBits3.FindRef(8)[3];
	GS->A10.Rcs.Byte8bit4=AllBits3.FindRef(8)[4];
	GS->A10.Rcs.Byte8bit5=AllBits3.FindRef(8)[5];
	GS->A10.Rcs.Byte8bit6=AllBits3.FindRef(8)[6];
	GS->A10.Rcs.Byte8bit7=AllBits3.FindRef(8)[7];
	GS->A10.Rcs.Byte9bit0=AllBits3.FindRef(9)[0];
	GS->A10.Rcs.Byte9bit1=AllBits3.FindRef(9)[1];
	GS->A10.Rcs.Byte9bit2=AllBits3.FindRef(9)[2];
	GS->A10.Rcs.Byte9bit3=AllBits3.FindRef(9)[3];
	GS->A10.Rcs.Byte9bit4=AllBits3.FindRef(9)[4];

	GS->A10.Rcs.Byte10=ReceiveBytes[19];
	GS->A10.Rcs.Byte11=ReceiveBytes[20];
	GS->A10.Rcs.Byte12=ReceiveBytes[21];
	GS->A10.Rcs.Byte13=ReceiveBytes[22];
	GS->A10.Rcs.Byte14=ReceiveBytes[23];
	GS->A10.Rcs.Byte15=ReceiveBytes[24];
	GS->A10.Rcs.Byte16=ReceiveBytes[25];
	GS->A10.Rcs.Byte17=ReceiveBytes[26];
	GS->A10.Rcs.Byte18=ReceiveBytes[27];
}

void AUDPCockpitPort::ConvertStruct4_10(const TArray<uint8>&ReceiveBytes)
{
	GS->A10.Aps.Byte1bit0=AllBits4.FindRef(1)[0];
	GS->A10.Aps.Byte1bit1=AllBits4.FindRef(1)[1];
	GS->A10.Aps.Byte1bit2=AllBits4.FindRef(1)[2];
	GS->A10.Aps.Byte1bit3=AllBits4.FindRef(1)[3];
	GS->A10.Aps.Byte1bit4=AllBits4.FindRef(1)[4];
	GS->A10.Aps.Byte1bit5=AllBits4.FindRef(1)[5];
	GS->A10.Aps.Byte1bit6=AllBits4.FindRef(1)[6];
	GS->A10.Aps.Byte1bit7=AllBits4.FindRef(1)[7];
	GS->A10.Aps.Byte2bit0=AllBits4.FindRef(2)[0];
	GS->A10.Aps.Byte2bit1=AllBits4.FindRef(2)[1];
	GS->A10.Aps.Byte2bit2=AllBits4.FindRef(2)[2];
	GS->A10.Aps.Byte2bit3=AllBits4.FindRef(2)[3];
	GS->A10.Aps.Byte2bit4=AllBits4.FindRef(2)[4];
	GS->A10.Aps.Byte2bit5=AllBits4.FindRef(2)[5];
	GS->A10.Aps.Byte2bit6=AllBits4.FindRef(2)[6];
	GS->A10.Aps.Byte2bit7=AllBits4.FindRef(2)[7];
	GS->A10.Aps.Byte3bit0=AllBits4.FindRef(3)[0];
	GS->A10.Aps.Byte3bit1=AllBits4.FindRef(3)[1];
	GS->A10.Aps.Byte3bit2=AllBits4.FindRef(3)[2];
	GS->A10.Aps.Byte3bit3=AllBits4.FindRef(3)[3];
	GS->A10.Aps.Byte3bit4=AllBits4.FindRef(3)[4];
}

void AUDPCockpitPort::ConvertStruct5_10(const TArray<uint8>&ReceiveBytes)
{
	GS->A10.Atl.Byte1bit0=AllBits5.FindRef(1)[0];
	GS->A10.Atl.Byte1bit1=AllBits5.FindRef(1)[1];
	GS->A10.Atl.Byte1bit2=AllBits5.FindRef(1)[2];
	GS->A10.Atl.Byte1bit3=AllBits5.FindRef(1)[3];
	GS->A10.Atl.Byte1bit4=AllBits5.FindRef(1)[4];
	GS->A10.Atl.Byte1bit5=AllBits5.FindRef(1)[5];
	GS->A10.Atl.Byte1bit6=AllBits5.FindRef(1)[6];
	GS->A10.Atl.Byte1bit7=AllBits5.FindRef(1)[7];
	GS->A10.Atl.Byte2bit0=AllBits5.FindRef(2)[0];
	GS->A10.Atl.Byte2bit1=AllBits5.FindRef(2)[1];
	GS->A10.Atl.Byte2bit2=AllBits5.FindRef(2)[2];
	GS->A10.Atl.Byte2bit3=AllBits5.FindRef(2)[3];
	GS->A10.Atl.Byte2bit4=AllBits5.FindRef(2)[4];
	GS->A10.Atl.Byte2bit5=AllBits5.FindRef(2)[5];
	GS->A10.Atl.Byte2bit6=AllBits5.FindRef(2)[6];
	GS->A10.Atl.Byte2bit7=AllBits5.FindRef(2)[7];
	GS->A10.Atl.Byte3bit0=AllBits5.FindRef(3)[0];
	GS->A10.Atl.Byte3bit1=AllBits5.FindRef(3)[1];
	GS->A10.Atl.Byte3bit2=AllBits5.FindRef(3)[2];
}

void AUDPCockpitPort::ConvertStruct1(const TArray<uint8>&ReceiveBytes)
{
	
	//飞防数据
	GS->Fs11.sw_gear=(bool)(1-AllBits1.FindRef(9)[1]);
	//航电数据
	GS->A11.Ins.Byte1bit0= AllBits1.FindRef(1)[0];
	GS->A11.Ins.Byte1bit1= AllBits1.FindRef(1)[1];
	GS->A11.Ins.Byte1bit2= AllBits1.FindRef(1)[2];
	GS->A11.Ins.Byte1bit3= AllBits1.FindRef(1)[3];
	GS->A11.Ins.Byte1bit4= AllBits1.FindRef(1)[4];
	GS->A11.Ins.Byte1bit5= AllBits1.FindRef(1)[5];
	GS->A11.Ins.Byte1bit6= AllBits1.FindRef(1)[6];
	GS->A11.Ins.Byte1bit7= AllBits1.FindRef(1)[7];

	GS->A11.Ins.Byte2bit0= AllBits1.FindRef(2)[0];
	GS->A11.Ins.Byte2bit1= AllBits1.FindRef(2)[1];
	GS->A11.Ins.Byte2bit2= AllBits1.FindRef(2)[2];
	GS->A11.Ins.Byte2bit3= AllBits1.FindRef(2)[3];
	GS->A11.Ins.Byte2bit4= AllBits1.FindRef(2)[4];
	GS->A11.Ins.Byte2bit5= AllBits1.FindRef(2)[5];
	GS->A11.Ins.Byte2bit6= AllBits1.FindRef(2)[6];
	GS->A11.Ins.Byte2bit7= AllBits1.FindRef(2)[7];

	GS->A11.Ins.Byte3bit0= AllBits1.FindRef(3)[0];
	GS->A11.Ins.Byte3bit1= AllBits1.FindRef(3)[1];
	GS->A11.Ins.Byte3bit2= AllBits1.FindRef(3)[2];
	GS->A11.Ins.Byte3bit3= AllBits1.FindRef(3)[3];
	GS->A11.Ins.Byte3bit4= AllBits1.FindRef(3)[4];
	GS->A11.Ins.Byte3bit5= AllBits1.FindRef(3)[5];
	GS->A11.Ins.Byte3bit6= AllBits1.FindRef(3)[6];
	GS->A11.Ins.Byte3bit7= AllBits1.FindRef(3)[7];

	GS->A11.Ins.Byte4bit0= AllBits1.FindRef(4)[0];
	GS->A11.Ins.Byte4bit1= AllBits1.FindRef(4)[1];
	GS->A11.Ins.Byte4bit2= AllBits1.FindRef(4)[2];
	GS->A11.Ins.Byte4bit3= AllBits1.FindRef(4)[3];
	GS->A11.Ins.Byte4bit4= AllBits1.FindRef(4)[4];
	GS->A11.Ins.Byte4bit5= AllBits1.FindRef(4)[5];
	GS->A11.Ins.Byte4bit6= AllBits1.FindRef(4)[6];
	GS->A11.Ins.Byte4bit7= AllBits1.FindRef(4)[7];
	
	GS->A11.Ins.Byte5bit0= AllBits1.FindRef(5)[0];
	GS->A11.Ins.Byte5bit1= AllBits1.FindRef(5)[1];
	GS->A11.Ins.Byte5bit2= AllBits1.FindRef(5)[2];
	GS->A11.Ins.Byte5bit3= AllBits1.FindRef(5)[3];
	GS->A11.Ins.Byte5bit4= AllBits1.FindRef(5)[4];
	GS->A11.Ins.Byte5bit5= AllBits1.FindRef(5)[5];
	GS->A11.Ins.Byte5bit6= AllBits1.FindRef(5)[6];
	GS->A11.Ins.Byte5bit7= AllBits1.FindRef(5)[7];

	GS->A11.Ins.Byte6bit0= AllBits1.FindRef(6)[0];
	GS->A11.Ins.Byte6bit1= AllBits1.FindRef(6)[1];
	GS->A11.Ins.Byte6bit2= AllBits1.FindRef(6)[2];
	GS->A11.Ins.Byte6bit3= AllBits1.FindRef(6)[3];
	GS->A11.Ins.Byte6bit4= AllBits1.FindRef(6)[4];
	GS->A11.Ins.Byte6bit5= AllBits1.FindRef(6)[5];
	GS->A11.Ins.Byte6bit6= AllBits1.FindRef(6)[6];
	GS->A11.Ins.Byte6bit7= AllBits1.FindRef(6)[7];

	GS->A11.Ins.Byte7bit0= AllBits1.FindRef(7)[0];
	GS->A11.Ins.Byte7bit1= AllBits1.FindRef(7)[1];
	GS->A11.Ins.Byte7bit2= AllBits1.FindRef(7)[2];
	GS->A11.Ins.Byte7bit3= AllBits1.FindRef(7)[3];
	GS->A11.Ins.Byte7bit4= AllBits1.FindRef(7)[4];
	GS->A11.Ins.Byte7bit5= AllBits1.FindRef(7)[5];
	GS->A11.Ins.Byte7bit6= AllBits1.FindRef(7)[6];
	GS->A11.Ins.Byte7bit7= AllBits1.FindRef(7)[7];

	GS->A11.Ins.Byte8bit0= AllBits1.FindRef(8)[0];
	GS->A11.Ins.Byte8bit1= AllBits1.FindRef(8)[1];
	GS->A11.Ins.Byte8bit2= AllBits1.FindRef(8)[2];
	GS->A11.Ins.Byte8bit3= AllBits1.FindRef(8)[3];
	GS->A11.Ins.Byte8bit4= AllBits1.FindRef(8)[4];
	GS->A11.Ins.Byte8bit5= AllBits1.FindRef(8)[5];
	GS->A11.Ins.Byte8bit6= AllBits1.FindRef(8)[6];
	GS->A11.Ins.Byte8bit7= AllBits1.FindRef(8)[7];

	GS->A11.Ins.Byte11bit0= AllBits1.FindRef(11)[0];
	GS->A11.Ins.Byte11bit1= AllBits1.FindRef(11)[1];
	GS->A11.Ins.Byte11bit2= AllBits1.FindRef(11)[2];
	GS->A11.Ins.Byte11bit3= AllBits1.FindRef(11)[3];
	GS->A11.Ins.Byte11bit4= AllBits1.FindRef(11)[4];
	GS->A11.Ins.Byte11bit5= AllBits1.FindRef(11)[5];
	GS->A11.Ins.Byte11bit6= AllBits1.FindRef(11)[6];
	GS->A11.Ins.Byte11bit7= AllBits1.FindRef(11)[7];

	GS->A11.Ins.Byte12bit0= AllBits1.FindRef(12)[0];
	GS->A11.Ins.Byte12bit1= AllBits1.FindRef(12)[1];
	GS->A11.Ins.Byte12bit2= AllBits1.FindRef(12)[2];
	GS->A11.Ins.Byte12bit3= AllBits1.FindRef(12)[3];
	GS->A11.Ins.Byte12bit4= AllBits1.FindRef(12)[4];
	GS->A11.Ins.Byte12bit5= AllBits1.FindRef(12)[5];
	GS->A11.Ins.Byte12bit6= AllBits1.FindRef(12)[6];
	GS->A11.Ins.Byte12bit7= AllBits1.FindRef(12)[7];

	GS->A11.Ins.Byte13bit0= AllBits1.FindRef(13)[0];
	GS->A11.Ins.Byte13bit1= AllBits1.FindRef(13)[1];
	GS->A11.Ins.Byte13bit2= AllBits1.FindRef(13)[2];
	GS->A11.Ins.Byte13bit3= AllBits1.FindRef(13)[3];
	GS->A11.Ins.Byte13bit4= AllBits1.FindRef(13)[4];
	GS->A11.Ins.Byte13bit5= AllBits1.FindRef(13)[5];
	GS->A11.Ins.Byte13bit6= AllBits1.FindRef(13)[6];
	GS->A11.Ins.Byte13bit7= AllBits1.FindRef(13)[7];

	GS->A11.Ins.Byte14bit0= AllBits1.FindRef(14)[0];
	GS->A11.Ins.Byte14bit1= AllBits1.FindRef(14)[1];
	GS->A11.Ins.Byte14bit2= AllBits1.FindRef(14)[2];
	GS->A11.Ins.Byte14bit3= AllBits1.FindRef(14)[3];
	GS->A11.Ins.Byte14bit4= AllBits1.FindRef(14)[4];
	GS->A11.Ins.Byte14bit5= AllBits1.FindRef(14)[5];
	GS->A11.Ins.Byte14bit6= AllBits1.FindRef(14)[6];
	GS->A11.Ins.Byte14bit7= AllBits1.FindRef(14)[7];

	GS->A11.Ins.Byte15bit0= AllBits1.FindRef(15)[0];
	GS->A11.Ins.Byte15bit1= AllBits1.FindRef(15)[1];
	GS->A11.Ins.Byte15bit2= AllBits1.FindRef(15)[2];
	GS->A11.Ins.Byte15bit3= AllBits1.FindRef(15)[3];
	GS->A11.Ins.Byte15bit4= AllBits1.FindRef(15)[4];
	GS->A11.Ins.Byte15bit5= AllBits1.FindRef(15)[5];
	GS->A11.Ins.Byte15bit6= AllBits1.FindRef(15)[6];
	GS->A11.Ins.Byte15bit7= AllBits1.FindRef(15)[7];

	GS->A11.Ins.Byte16bit0= AllBits1.FindRef(16)[0];
	GS->A11.Ins.Byte16bit1= AllBits1.FindRef(16)[1];
	GS->A11.Ins.Byte16bit2= AllBits1.FindRef(16)[2];
	GS->A11.Ins.Byte16bit3= AllBits1.FindRef(16)[3];
	GS->A11.Ins.Byte16bit4= AllBits1.FindRef(16)[4];
	GS->A11.Ins.Byte16bit5= AllBits1.FindRef(16)[5];
	GS->A11.Ins.Byte16bit6= AllBits1.FindRef(16)[6];
	GS->A11.Ins.Byte16bit7= AllBits1.FindRef(16)[7];

	GS->A11.Ins.Byte17bit0= AllBits1.FindRef(17)[0];
	GS->A11.Ins.Byte17bit1= AllBits1.FindRef(17)[1];
	GS->A11.Ins.Byte17bit2= AllBits1.FindRef(17)[2];
	GS->A11.Ins.Byte17bit3= AllBits1.FindRef(17)[3];
	GS->A11.Ins.Byte17bit4= AllBits1.FindRef(17)[4];
	GS->A11.Ins.Byte17bit5= AllBits1.FindRef(17)[5];
	GS->A11.Ins.Byte17bit6= AllBits1.FindRef(17)[6];
	GS->A11.Ins.Byte17bit7= AllBits1.FindRef(17)[7];

	GS->A11.Ins.Byte18bit0= AllBits1.FindRef(18)[0];
	GS->A11.Ins.Byte18bit1= AllBits1.FindRef(18)[1];
	GS->A11.Ins.Byte18bit2= AllBits1.FindRef(18)[2];
	GS->A11.Ins.Byte18bit3= AllBits1.FindRef(18)[3];
	GS->A11.Ins.Byte18bit4= AllBits1.FindRef(18)[4];
	GS->A11.Ins.Byte18bit5= AllBits1.FindRef(18)[5];
	GS->A11.Ins.Byte18bit6= AllBits1.FindRef(18)[6];
	GS->A11.Ins.Byte18bit7= AllBits1.FindRef(18)[7];

	GS->A11.Ins.Byte19bit0= AllBits1.FindRef(19)[0];
	GS->A11.Ins.Byte19bit1= AllBits1.FindRef(19)[1];
	GS->A11.Ins.Byte19bit2= AllBits1.FindRef(19)[2];
	GS->A11.Ins.Byte19bit3= AllBits1.FindRef(19)[3];
	GS->A11.Ins.Byte19bit4= AllBits1.FindRef(19)[4];
	GS->A11.Ins.Byte19bit5= AllBits1.FindRef(19)[5];
	GS->A11.Ins.Byte19bit6= AllBits1.FindRef(19)[6];
	GS->A11.Ins.Byte19bit7= AllBits1.FindRef(19)[7];

	GS->A11.Ins.Byte20bit0= AllBits1.FindRef(20)[0];
	GS->A11.Ins.Byte20bit1= AllBits1.FindRef(20)[1];
	GS->A11.Ins.Byte20bit2= AllBits1.FindRef(20)[2];
	GS->A11.Ins.Byte20bit3= AllBits1.FindRef(20)[3];
	GS->A11.Ins.Byte20bit4= AllBits1.FindRef(20)[4];
	GS->A11.Ins.Byte20bit5= AllBits1.FindRef(20)[5];
	GS->A11.Ins.Byte20bit6= AllBits1.FindRef(20)[6];
	GS->A11.Ins.Byte20bit7= AllBits1.FindRef(20)[7];

	GS->A11.Ins.Byte21bit0= AllBits1.FindRef(21)[0];
	GS->A11.Ins.Byte21bit1= AllBits1.FindRef(21)[1];
	GS->A11.Ins.Byte21bit2= AllBits1.FindRef(21)[2];
	GS->A11.Ins.Byte21bit3= AllBits1.FindRef(21)[3];
	GS->A11.Ins.Byte21bit4= AllBits1.FindRef(21)[4];
	GS->A11.Ins.Byte21bit5= AllBits1.FindRef(21)[5];
	GS->A11.Ins.Byte21bit6= AllBits1.FindRef(21)[6];
	GS->A11.Ins.Byte21bit7= AllBits1.FindRef(21)[7];
	
	GS->A11.Ins.Byte27=ReceiveBytes[35];
	GS->A11.Ins.Byte28=ReceiveBytes[36];
	GS->A11.Ins.Byte29=ReceiveBytes[37];
	GS->A11.Ins.Byte30=ReceiveBytes[38];
}

void AUDPCockpitPort::ConvertStruct2(const TArray<uint8>&RecvData)
{
	//左台数据传输BUG（串口服务器或串口数据错误）
	if(AllBits2.FindRef(15)[0]==1&&AllBits2.FindRef(15)[1]==1&&AllBits2.FindRef(15)[2]==1)
	{
		GEngine->AddOnScreenDebugMessage(-1,5.f,FColor::Red,TEXT("1111"));
		return;
	}
	
	//左台
	GS->A11.Lcs.Byte1bit0= AllBits2.FindRef(1)[0];
	GS->A11.Lcs.Byte1bit1= AllBits2.FindRef(1)[1];
	GS->A11.Lcs.Byte1bit2= AllBits2.FindRef(1)[2];
	GS->A11.Lcs.Byte1bit3= AllBits2.FindRef(1)[3];
	GS->A11.Lcs.Byte1bit4= AllBits2.FindRef(1)[4];
	GS->A11.Lcs.Byte1bit5= AllBits2.FindRef(1)[5];
	GS->A11.Lcs.Byte1bit6= AllBits2.FindRef(1)[6];
	GS->A11.Lcs.Byte1bit7= AllBits2.FindRef(1)[7];

	GS->A11.Lcs.Byte2bit0= AllBits2.FindRef(2)[0];
	GS->A11.Lcs.Byte2bit1= AllBits2.FindRef(2)[1];
	GS->A11.Lcs.Byte2bit2= AllBits2.FindRef(2)[2];
	GS->A11.Lcs.Byte2bit3= AllBits2.FindRef(2)[3];
	GS->A11.Lcs.Byte2bit4= AllBits2.FindRef(2)[4];
	GS->A11.Lcs.Byte2bit5= AllBits2.FindRef(2)[5];
	GS->A11.Lcs.Byte2bit6= AllBits2.FindRef(2)[6];
	GS->A11.Lcs.Byte2bit7= AllBits2.FindRef(2)[7];

	GS->A11.Lcs.Byte10bit0= AllBits2.FindRef(10)[0];
	GS->A11.Lcs.Byte10bit1= AllBits2.FindRef(10)[1];
	GS->A11.Lcs.Byte10bit2= AllBits2.FindRef(10)[2];
	GS->A11.Lcs.Byte10bit3= AllBits2.FindRef(10)[3];
	GS->A11.Lcs.Byte10bit4= AllBits2.FindRef(10)[4];
	GS->A11.Lcs.Byte10bit5= AllBits2.FindRef(10)[5];
	GS->A11.Lcs.Byte10bit6= AllBits2.FindRef(10)[6];
	GS->A11.Lcs.Byte10bit7= AllBits2.FindRef(10)[7];

	GS->A11.Lcs.Byte11bit0= AllBits2.FindRef(11)[0];
	GS->A11.Lcs.Byte11bit1= AllBits2.FindRef(11)[1];
	GS->A11.Lcs.Byte11bit2= AllBits2.FindRef(11)[2];
	GS->A11.Lcs.Byte11bit3= AllBits2.FindRef(11)[3];
	GS->A11.Lcs.Byte11bit4= AllBits2.FindRef(11)[4];
	GS->A11.Lcs.Byte11bit5= AllBits2.FindRef(11)[5];
	GS->A11.Lcs.Byte11bit6= AllBits2.FindRef(11)[6];
	GS->A11.Lcs.Byte11bit7= AllBits2.FindRef(11)[7];

	GS->A11.Lcs.Byte12bit0= AllBits2.FindRef(12)[0];
	GS->A11.Lcs.Byte12bit1= AllBits2.FindRef(12)[1];
	GS->A11.Lcs.Byte12bit2= AllBits2.FindRef(12)[2];
	GS->A11.Lcs.Byte12bit3= AllBits2.FindRef(12)[3];
	GS->A11.Lcs.Byte12bit4= AllBits2.FindRef(12)[4];
	GS->A11.Lcs.Byte12bit5= AllBits2.FindRef(12)[5];
	GS->A11.Lcs.Byte12bit6= AllBits2.FindRef(12)[6];
	GS->A11.Lcs.Byte12bit7= AllBits2.FindRef(12)[7];

	GS->A11.Lcs.Byte13bit0= AllBits2.FindRef(13)[0];
	GS->A11.Lcs.Byte13bit1= AllBits2.FindRef(13)[1];
	GS->A11.Lcs.Byte13bit2= AllBits2.FindRef(13)[2];
	GS->A11.Lcs.Byte13bit3= AllBits2.FindRef(13)[3];
	GS->A11.Lcs.Byte13bit4= AllBits2.FindRef(13)[4];
	GS->A11.Lcs.Byte13bit5= AllBits2.FindRef(13)[5];
	GS->A11.Lcs.Byte13bit6= AllBits2.FindRef(13)[6];
	GS->A11.Lcs.Byte13bit7= AllBits2.FindRef(13)[7];

	GS->A11.Lcs.Byte14bit0= AllBits2.FindRef(14)[0];
	GS->A11.Lcs.Byte14bit1= AllBits2.FindRef(14)[1];
	GS->A11.Lcs.Byte14bit2= AllBits2.FindRef(14)[2];
	GS->A11.Lcs.Byte14bit3= AllBits2.FindRef(14)[3];
	GS->A11.Lcs.Byte14bit4= AllBits2.FindRef(14)[4];
	GS->A11.Lcs.Byte14bit5= AllBits2.FindRef(14)[5];
	GS->A11.Lcs.Byte14bit6= AllBits2.FindRef(14)[6];
	GS->A11.Lcs.Byte14bit7= AllBits2.FindRef(14)[7];

	GS->A11.Lcs.Byte15bit0= AllBits2.FindRef(15)[0];
	GS->A11.Lcs.Byte15bit1= AllBits2.FindRef(15)[1];
	GS->A11.Lcs.Byte15bit2= AllBits2.FindRef(15)[2];
	GS->A11.Lcs.Byte15bit3= AllBits2.FindRef(15)[3];
	GS->A11.Lcs.Byte15bit4= AllBits2.FindRef(15)[4];
	GS->A11.Lcs.Byte15bit5= AllBits2.FindRef(15)[5];
	GS->A11.Lcs.Byte15bit6= AllBits2.FindRef(15)[6];
	GS->A11.Lcs.Byte15bit7= AllBits2.FindRef(15)[7];
	//飞防数据
	GS->Fs11.sw_dlink=(bool)(AllBits2.FindRef(4)[1]);
	GS->Fs11.sw_saupad_state=(bool)(AllBits2.FindRef(3)[6]);
	GS->Fs11.sw_saupad_auto=(bool)(AllBits2.FindRef(1)[4]);
	GS->Fs11.sw_saupad_clear=(bool)AllBits2.FindRef(2)[0];
	GS->Fs11.sw_saupad_altstab=(bool)AllBits2.FindRef(1)[7];
	GS->Fs11.sw_saupad_hightstab=(bool)AllBits2.FindRef(1)[5];
}

void AUDPCockpitPort::ConvertStruct3(const TArray<uint8>&ReceiveBytes)
{
	//右台

	GS->A11.Rcs.Byte1bit0= AllBits3.FindRef(1)[0];
	GS->A11.Rcs.Byte1bit1= AllBits3.FindRef(1)[1];
	GS->A11.Rcs.Byte1bit2= AllBits3.FindRef(1)[2];
	GS->A11.Rcs.Byte1bit3= AllBits3.FindRef(1)[3];
	GS->A11.Rcs.Byte1bit4= AllBits3.FindRef(1)[4];
	GS->A11.Rcs.Byte1bit5= AllBits3.FindRef(1)[5];
	GS->A11.Rcs.Byte1bit6= AllBits3.FindRef(1)[6];
	GS->A11.Rcs.Byte1bit7= AllBits3.FindRef(1)[7];

	GS->A11.Rcs.Byte2bit0= AllBits3.FindRef(2)[0];
	GS->A11.Rcs.Byte2bit1= AllBits3.FindRef(2)[1];
	GS->A11.Rcs.Byte2bit2= AllBits3.FindRef(2)[2];
	GS->A11.Rcs.Byte2bit3= AllBits3.FindRef(2)[3];
	GS->A11.Rcs.Byte2bit4= AllBits3.FindRef(2)[4];
	GS->A11.Rcs.Byte2bit5= AllBits3.FindRef(2)[5];
	GS->A11.Rcs.Byte2bit6= AllBits3.FindRef(2)[6];
	GS->A11.Rcs.Byte2bit7= AllBits3.FindRef(2)[7];

	GS->A11.Rcs.Byte3bit0= AllBits3.FindRef(3)[0];
	GS->A11.Rcs.Byte3bit1= AllBits3.FindRef(3)[1];
	GS->A11.Rcs.Byte3bit2= AllBits3.FindRef(3)[2];
	GS->A11.Rcs.Byte3bit3= AllBits3.FindRef(3)[3];
	GS->A11.Rcs.Byte3bit4= AllBits3.FindRef(3)[4];
	GS->A11.Rcs.Byte3bit5= AllBits3.FindRef(3)[5];
	GS->A11.Rcs.Byte3bit6= AllBits3.FindRef(3)[6];
	GS->A11.Rcs.Byte3bit7= AllBits3.FindRef(3)[7];

	GS->A11.Rcs.Byte4bit0= AllBits3.FindRef(4)[0];
	GS->A11.Rcs.Byte4bit1= AllBits3.FindRef(4)[1];
	GS->A11.Rcs.Byte4bit2= AllBits3.FindRef(4)[2];
	GS->A11.Rcs.Byte4bit3= AllBits3.FindRef(4)[3];
	GS->A11.Rcs.Byte4bit4= AllBits3.FindRef(4)[4];
	GS->A11.Rcs.Byte4bit5= AllBits3.FindRef(4)[5];
	GS->A11.Rcs.Byte4bit6= AllBits3.FindRef(4)[6];
	GS->A11.Rcs.Byte4bit7= AllBits3.FindRef(4)[7];

	GS->A11.Rcs.Byte5bit0= AllBits3.FindRef(5)[0];
	GS->A11.Rcs.Byte5bit1= AllBits3.FindRef(5)[1];
	GS->A11.Rcs.Byte5bit2= AllBits3.FindRef(5)[2];
	GS->A11.Rcs.Byte5bit3= AllBits3.FindRef(5)[3];
	GS->A11.Rcs.Byte5bit4= AllBits3.FindRef(5)[4];
	GS->A11.Rcs.Byte5bit5= AllBits3.FindRef(5)[5];
	GS->A11.Rcs.Byte5bit6= AllBits3.FindRef(5)[6];
	GS->A11.Rcs.Byte5bit7= AllBits3.FindRef(5)[7];

	GS->A11.Rcs.Byte6bit0= AllBits3.FindRef(6)[0];
	GS->A11.Rcs.Byte6bit1= AllBits3.FindRef(6)[1];
	GS->A11.Rcs.Byte6bit2= AllBits3.FindRef(6)[2];
	GS->A11.Rcs.Byte6bit3= AllBits3.FindRef(6)[3];
	GS->A11.Rcs.Byte6bit4= AllBits3.FindRef(6)[4];
	GS->A11.Rcs.Byte6bit5= AllBits3.FindRef(6)[5];
	GS->A11.Rcs.Byte6bit6= AllBits3.FindRef(6)[6];
	GS->A11.Rcs.Byte6bit7= AllBits3.FindRef(6)[7];
}

void AUDPCockpitPort::ConvertStruct4(const TArray<uint8>&ReceiveBytes)
{
	//飞防
	GS->Fs11.sw_stick_link=(bool)AllBits4.FindRef(2)[6];
	GS->Fs11.sw_stick_level=(bool)AllBits4.FindRef(2)[1];
	GS->Fs11.sw_stick_saucut=(bool)AllBits4.FindRef(1)[0];
	GS->Fs11.sw_stick_trim[0]=(bool)AllBits4.FindRef(1)[5];
	GS->Fs11.sw_stick_trim[1]=(bool)AllBits4.FindRef(1)[6];
	GS->Fs11.sw_stick_trim[2]=(bool)AllBits4.FindRef(1)[7];
	GS->Fs11.sw_stick_trim[3]=(bool)AllBits4.FindRef(2)[0];
	
	//驾驶杆   航电
	GS->A11.Aps.Byte1bit0= AllBits4.FindRef(1)[0];
	GS->A11.Aps.Byte1bit1= AllBits4.FindRef(1)[1];
	GS->A11.Aps.Byte1bit2= AllBits4.FindRef(1)[2];
	GS->A11.Aps.Byte1bit3= AllBits4.FindRef(1)[3];
	GS->A11.Aps.Byte1bit4= AllBits4.FindRef(1)[4];
	GS->A11.Aps.Byte1bit5= AllBits4.FindRef(1)[5];
	GS->A11.Aps.Byte1bit6= AllBits4.FindRef(1)[6];
	GS->A11.Aps.Byte1bit7= AllBits4.FindRef(1)[7];

	GS->A11.Aps.Byte2bit0= AllBits4.FindRef(2)[0];
	GS->A11.Aps.Byte2bit1= AllBits4.FindRef(2)[1];
	GS->A11.Aps.Byte2bit2= AllBits4.FindRef(2)[2];
	GS->A11.Aps.Byte2bit3= AllBits4.FindRef(2)[3];
	GS->A11.Aps.Byte2bit4= AllBits4.FindRef(2)[4];
	GS->A11.Aps.Byte2bit5= AllBits4.FindRef(2)[5];
	GS->A11.Aps.Byte2bit6= AllBits4.FindRef(2)[6];

	GS->A11.Aps.A=Convert12Bit(ReceiveBytes[14],ReceiveBytes[15]);
	GS->A11.Aps.B=Convert12Bit(ReceiveBytes[16],ReceiveBytes[17]);
}

void AUDPCockpitPort::ConvertStruct5(const TArray<uint8>&ReceiveBytes)
{
	//油门左发
	GS->A11.Atl.Byte1bit0= AllBits5.FindRef(1)[0];
	GS->A11.Atl.Byte1bit1= AllBits5.FindRef(1)[1];

	GS->A11.Atl.A=Convert12Bit(ReceiveBytes[5],ReceiveBytes[6]);
}

void AUDPCockpitPort::ConvertStruct6(const TArray<uint8>&ReceiveBytes)
{
	//飞防
	GS->Fs11.sw_airbrk=(bool)AllBits6.FindRef(2)[6];
	//油门右发
	GS->A11.Atr.Byte1bit0= AllBits6.FindRef(1)[0];
	GS->A11.Atr.Byte1bit1= AllBits6.FindRef(1)[1];
	GS->A11.Atr.Byte1bit2= AllBits6.FindRef(1)[2];
	GS->A11.Atr.Byte1bit3= AllBits6.FindRef(1)[3];
	GS->A11.Atr.Byte1bit4= AllBits6.FindRef(1)[4];
	GS->A11.Atr.Byte1bit5= AllBits6.FindRef(1)[5];
	GS->A11.Atr.Byte1bit6= AllBits6.FindRef(1)[6];
	GS->A11.Atr.Byte1bit7= AllBits6.FindRef(1)[7];

	GS->A11.Atr.Byte2bit0= AllBits6.FindRef(2)[0];
	GS->A11.Atr.Byte2bit1= AllBits6.FindRef(2)[1];
	GS->A11.Atr.Byte2bit2= AllBits6.FindRef(2)[2];
	GS->A11.Atr.Byte2bit3= AllBits6.FindRef(2)[3];
	GS->A11.Atr.Byte2bit4= AllBits6.FindRef(2)[4];
	GS->A11.Atr.Byte2bit5= AllBits6.FindRef(2)[5];
	GS->A11.Atr.Byte2bit6= AllBits6.FindRef(2)[6];
	GS->A11.Atr.Byte2bit7= AllBits6.FindRef(2)[7];
	
	GS->A11.Atr.Byte3bit0= AllBits6.FindRef(3)[0];
}

void AUDPCockpitPort::ConvertStruct1_16(const TArray<uint8>& ReceiveBytes)
{
	GS->A16.Ins.Byte1bit0=AllBits1.FindRef(1)[0];
	GS->A16.Ins.Byte1bit1=AllBits1.FindRef(1)[1];
	GS->A16.Ins.Byte1bit2=AllBits1.FindRef(1)[2];
	GS->A16.Ins.Byte1bit3=AllBits1.FindRef(1)[3];
	GS->A16.Ins.Byte1bit4=AllBits1.FindRef(1)[4];
	GS->A16.Ins.Byte1bit5=AllBits1.FindRef(1)[5];
	GS->A16.Ins.Byte1bit6=AllBits1.FindRef(1)[6];
	GS->A16.Ins.Byte1bit7=AllBits1.FindRef(1)[7];
	GS->A16.Ins.Byte2bit0=AllBits1.FindRef(2)[0];
	GS->A16.Ins.Byte2bit1=AllBits1.FindRef(2)[1];
	GS->A16.Ins.Byte2bit2=AllBits1.FindRef(2)[2];
	GS->A16.Ins.Byte2bit3=AllBits1.FindRef(2)[3];
	GS->A16.Ins.Byte2bit4=AllBits1.FindRef(2)[4];
	GS->A16.Ins.Byte2bit5=AllBits1.FindRef(2)[5];
	GS->A16.Ins.Byte2bit6=AllBits1.FindRef(2)[6];
	GS->A16.Ins.Byte2bit7=AllBits1.FindRef(2)[7];
	GS->A16.Ins.Byte3bit0=AllBits1.FindRef(3)[0];
	GS->A16.Ins.Byte3bit1=AllBits1.FindRef(3)[1];
	GS->A16.Ins.Byte3bit2=AllBits1.FindRef(3)[2];
	GS->A16.Ins.Byte3bit3=AllBits1.FindRef(3)[3];
	GS->A16.Ins.Byte3bit4=AllBits1.FindRef(3)[4];
	GS->A16.Ins.Byte3bit5=AllBits1.FindRef(3)[5];
	GS->A16.Ins.Byte3bit6=AllBits1.FindRef(3)[6];
	GS->A16.Ins.Byte3bit7=AllBits1.FindRef(3)[7];
	GS->A16.Ins.Byte4bit0=AllBits1.FindRef(4)[0];
	GS->A16.Ins.Byte4bit1=AllBits1.FindRef(4)[1];
	GS->A16.Ins.Byte4bit2=AllBits1.FindRef(4)[2];
	GS->A16.Ins.Byte4bit3=AllBits1.FindRef(4)[3];
	GS->A16.Ins.Byte4bit4=AllBits1.FindRef(4)[4];
	GS->A16.Ins.Byte4bit5=AllBits1.FindRef(4)[5];
	GS->A16.Ins.Byte4bit6=AllBits1.FindRef(4)[6];
	GS->A16.Ins.Byte4bit7=AllBits1.FindRef(4)[7];
	GS->A16.Ins.Byte5bit0=AllBits1.FindRef(5)[0];
	GS->A16.Ins.Byte5bit1=AllBits1.FindRef(5)[1];
	GS->A16.Ins.Byte5bit2=AllBits1.FindRef(5)[2];
	GS->A16.Ins.Byte5bit3=AllBits1.FindRef(5)[3];
	GS->A16.Ins.Byte5bit4=AllBits1.FindRef(5)[4];
	GS->A16.Ins.Byte5bit5=AllBits1.FindRef(5)[5];
	GS->A16.Ins.Byte5bit6=AllBits1.FindRef(5)[6];
	GS->A16.Ins.Byte5bit7=AllBits1.FindRef(5)[7];
	GS->A16.Ins.Byte6bit0=AllBits1.FindRef(6)[0];
	GS->A16.Ins.Byte6bit1=AllBits1.FindRef(6)[1];
	GS->A16.Ins.Byte6bit2=AllBits1.FindRef(6)[2];
	GS->A16.Ins.Byte6bit3=AllBits1.FindRef(6)[3];
	GS->A16.Ins.Byte6bit4=AllBits1.FindRef(6)[4];
	GS->A16.Ins.Byte6bit5=AllBits1.FindRef(6)[5];
	GS->A16.Ins.Byte6bit6=AllBits1.FindRef(6)[6];
	GS->A16.Ins.Byte6bit7=AllBits1.FindRef(6)[7];
	GS->A16.Ins.Byte7bit0=AllBits1.FindRef(7)[0];
	GS->A16.Ins.Byte7bit1=AllBits1.FindRef(7)[1];
	GS->A16.Ins.Byte7bit2=AllBits1.FindRef(7)[2];
	GS->A16.Ins.Byte7bit3=AllBits1.FindRef(7)[3];
	GS->A16.Ins.Byte7bit4=AllBits1.FindRef(7)[4];
	GS->A16.Ins.Byte7bit5=AllBits1.FindRef(7)[5];
	GS->A16.Ins.Byte7bit6=AllBits1.FindRef(7)[6];
	GS->A16.Ins.Byte7bit7=AllBits1.FindRef(7)[7];
	GS->A16.Ins.Byte8bit0=AllBits1.FindRef(8)[0];
	GS->A16.Ins.Byte8bit1=AllBits1.FindRef(8)[1];
	GS->A16.Ins.Byte8bit2=AllBits1.FindRef(8)[2];
	GS->A16.Ins.Byte8bit3=AllBits1.FindRef(8)[3];
	GS->A16.Ins.Byte8bit4=AllBits1.FindRef(8)[4];
	GS->A16.Ins.Byte8bit5=AllBits1.FindRef(8)[5];
	GS->A16.Ins.Byte8bit6=AllBits1.FindRef(8)[6];
	GS->A16.Ins.Byte8bit7=AllBits1.FindRef(8)[7];
	GS->A16.Ins.Byte9bit0=AllBits1.FindRef(9)[0];
	GS->A16.Ins.Byte9bit1=AllBits1.FindRef(9)[1];
	GS->A16.Ins.Byte9bit2=AllBits1.FindRef(9)[2];
	GS->A16.Ins.Byte9bit3=AllBits1.FindRef(9)[3];
	GS->A16.Ins.Byte9bit4=AllBits1.FindRef(9)[4];
	GS->A16.Ins.Byte9bit5=AllBits1.FindRef(9)[5];
	GS->A16.Ins.Byte9bit6=AllBits1.FindRef(9)[6];
	GS->A16.Ins.Byte9bit7=AllBits1.FindRef(9)[7];
	GS->A16.Ins.Byte10bit0=AllBits1.FindRef(10)[0];
	GS->A16.Ins.Byte10bit1=AllBits1.FindRef(10)[1];
	GS->A16.Ins.Byte10bit2=AllBits1.FindRef(10)[2];
	GS->A16.Ins.Byte10bit3=AllBits1.FindRef(10)[3];
	GS->A16.Ins.Byte10bit4=AllBits1.FindRef(10)[4];
	GS->A16.Ins.Byte10bit5=AllBits1.FindRef(10)[5];
	GS->A16.Ins.Byte10bit6=AllBits1.FindRef(10)[6];
	GS->A16.Ins.Byte10bit7=AllBits1.FindRef(10)[7];
	GS->A16.Ins.Byte11bit0=AllBits1.FindRef(11)[0];
	GS->A16.Ins.Byte11bit1=AllBits1.FindRef(11)[1];
	GS->A16.Ins.Byte11bit2=AllBits1.FindRef(11)[2];
	GS->A16.Ins.Byte11bit3=AllBits1.FindRef(11)[3];
	GS->A16.Ins.Byte11bit4=AllBits1.FindRef(11)[4];
	GS->A16.Ins.Byte11bit5=AllBits1.FindRef(11)[5];
	GS->A16.Ins.Byte11bit6=AllBits1.FindRef(11)[6];
	GS->A16.Ins.Byte11bit7=AllBits1.FindRef(11)[7];
	GS->A16.Ins.Byte12bit0=AllBits1.FindRef(12)[0];
	GS->A16.Ins.Byte12bit1=AllBits1.FindRef(12)[1];
	GS->A16.Ins.Byte12bit2=AllBits1.FindRef(12)[2];
	GS->A16.Ins.Byte12bit3=AllBits1.FindRef(12)[3];
	GS->A16.Ins.Byte12bit4=AllBits1.FindRef(12)[4];
	GS->A16.Ins.Byte12bit5=AllBits1.FindRef(12)[5];
	GS->A16.Ins.Byte12bit6=AllBits1.FindRef(12)[6];
	GS->A16.Ins.Byte12bit7=AllBits1.FindRef(12)[7];
	GS->A16.Ins.Byte13bit0=AllBits1.FindRef(13)[0];
	GS->A16.Ins.Byte13bit1=AllBits1.FindRef(13)[1];
	GS->A16.Ins.Byte13bit2=AllBits1.FindRef(13)[2];
	GS->A16.Ins.Byte13bit3=AllBits1.FindRef(13)[3];
	GS->A16.Ins.Byte13bit4=AllBits1.FindRef(13)[4];
	GS->A16.Ins.Byte13bit5=AllBits1.FindRef(13)[5];
	GS->A16.Ins.Byte13bit6=AllBits1.FindRef(13)[6];
	GS->A16.Ins.Byte13bit7=AllBits1.FindRef(13)[7];
	GS->A16.Ins.Byte14bit0=AllBits1.FindRef(14)[0];
	GS->A16.Ins.Byte14bit1=AllBits1.FindRef(14)[1];
	GS->A16.Ins.Byte14bit2=AllBits1.FindRef(14)[2];
	GS->A16.Ins.Byte14bit3=AllBits1.FindRef(14)[3];
	GS->A16.Ins.Byte14bit4=AllBits1.FindRef(14)[4];
	GS->A16.Ins.Byte14bit5=AllBits1.FindRef(14)[5];
	GS->A16.Ins.Byte14bit6=AllBits1.FindRef(14)[6];
	GS->A16.Ins.Byte14bit7=AllBits1.FindRef(14)[7];
	GS->A16.Ins.Byte15bit0=AllBits1.FindRef(15)[0];
	GS->A16.Ins.Byte15bit1=AllBits1.FindRef(15)[1];
	GS->A16.Ins.Byte15bit2=AllBits1.FindRef(15)[2];
	GS->A16.Ins.Byte15bit3=AllBits1.FindRef(15)[3];
	GS->A16.Ins.Byte15bit4=AllBits1.FindRef(15)[4];
	GS->A16.Ins.Byte15bit5=AllBits1.FindRef(15)[5];
	GS->A16.Ins.Byte15bit6=AllBits1.FindRef(15)[6];
	GS->A16.Ins.Byte15bit7=AllBits1.FindRef(15)[7];
	GS->A16.Ins.Byte16bit0=AllBits1.FindRef(16)[0];
	GS->A16.Ins.Byte16bit1=AllBits1.FindRef(16)[1];
	GS->A16.Ins.Byte16bit2=AllBits1.FindRef(16)[2];
	GS->A16.Ins.Byte16bit3=AllBits1.FindRef(16)[3];
	GS->A16.Ins.Byte16bit4=AllBits1.FindRef(16)[4];
	GS->A16.Ins.Byte16bit5=AllBits1.FindRef(16)[5];
	GS->A16.Ins.Byte16bit6=AllBits1.FindRef(16)[6];
	GS->A16.Ins.Byte16bit7=AllBits1.FindRef(16)[7];
	GS->A16.Ins.Byte17bit0=AllBits1.FindRef(17)[0];
	GS->A16.Ins.Byte17bit1=AllBits1.FindRef(17)[1];
	GS->A16.Ins.Byte17bit2=AllBits1.FindRef(17)[2];
	GS->A16.Ins.Byte17bit3=AllBits1.FindRef(17)[3];
	GS->A16.Ins.Byte17bit4=AllBits1.FindRef(17)[4];
	GS->A16.Ins.Byte17bit5=AllBits1.FindRef(17)[5];
	GS->A16.Ins.Byte17bit6=AllBits1.FindRef(17)[6];
	GS->A16.Ins.Byte17bit7=AllBits1.FindRef(17)[7];
	GS->A16.Ins.Byte18bit0=AllBits1.FindRef(18)[0];
	GS->A16.Ins.Byte18bit1=AllBits1.FindRef(18)[1];
	GS->A16.Ins.Byte18bit2=AllBits1.FindRef(18)[2];
	GS->A16.Ins.Byte18bit3=AllBits1.FindRef(18)[3];
	GS->A16.Ins.Byte18bit4=AllBits1.FindRef(18)[4];
	GS->A16.Ins.Byte18bit5=AllBits1.FindRef(18)[5];
	GS->A16.Ins.Byte18bit6=AllBits1.FindRef(18)[6];
	GS->A16.Ins.Byte18bit7=AllBits1.FindRef(18)[7];
	GS->A16.Ins.Byte19bit0=AllBits1.FindRef(19)[0];
	GS->A16.Ins.Byte19bit1=AllBits1.FindRef(19)[1];
	GS->A16.Ins.Byte19bit2=AllBits1.FindRef(19)[2];
	GS->A16.Ins.Byte19bit3=AllBits1.FindRef(19)[3];
	GS->A16.Ins.Byte19bit4=AllBits1.FindRef(19)[4];
	GS->A16.Ins.Byte19bit5=AllBits1.FindRef(19)[5];
	GS->A16.Ins.Byte19bit6=AllBits1.FindRef(19)[6];
	GS->A16.Ins.Byte19bit7=AllBits1.FindRef(19)[7];
	GS->A16.Ins.Byte20bit0=AllBits1.FindRef(20)[0];
	GS->A16.Ins.Byte20bit1=AllBits1.FindRef(20)[1];
	GS->A16.Ins.Byte20bit2=AllBits1.FindRef(20)[2];
	GS->A16.Ins.Byte20bit3=AllBits1.FindRef(20)[3];
	GS->A16.Ins.Byte20bit4=AllBits1.FindRef(20)[4];
	GS->A16.Ins.Byte20bit5=AllBits1.FindRef(20)[5];
	GS->A16.Ins.Byte20bit6=AllBits1.FindRef(20)[6];
	GS->A16.Ins.Byte20bit7=AllBits1.FindRef(20)[7];
	GS->A16.Ins.Byte21bit0=AllBits1.FindRef(21)[0];
	GS->A16.Ins.Byte21bit1=AllBits1.FindRef(21)[1];
	GS->A16.Ins.Byte21bit2=AllBits1.FindRef(21)[2];
	GS->A16.Ins.Byte21bit3=AllBits1.FindRef(21)[3];
	GS->A16.Ins.Byte21bit4=AllBits1.FindRef(21)[4];
	GS->A16.Ins.Byte21bit5=AllBits1.FindRef(21)[5];
	GS->A16.Ins.Byte21bit6=AllBits1.FindRef(21)[6];
	GS->A16.Ins.Byte21bit7=AllBits1.FindRef(21)[7];
	GS->A16.Ins.Byte22bit0=AllBits1.FindRef(22)[0];
	GS->A16.Ins.Byte22bit1=AllBits1.FindRef(22)[1];
	GS->A16.Ins.Byte22bit2=AllBits1.FindRef(22)[2];
	GS->A16.Ins.Byte22bit3=AllBits1.FindRef(22)[3];
	GS->A16.Ins.Byte22bit4=AllBits1.FindRef(22)[4];
	GS->A16.Ins.Byte22bit5=AllBits1.FindRef(22)[5];
	GS->A16.Ins.Byte22bit6=AllBits1.FindRef(22)[6];
	GS->A16.Ins.Byte22bit7=AllBits1.FindRef(22)[7];
	GS->A16.Ins.Byte23bit0=AllBits1.FindRef(23)[0];
	GS->A16.Ins.Byte23bit1=AllBits1.FindRef(23)[1];
	GS->A16.Ins.Byte23bit2=AllBits1.FindRef(23)[2];
	GS->A16.Ins.Byte23bit3=AllBits1.FindRef(23)[3];
	GS->A16.Ins.Byte23bit4=AllBits1.FindRef(23)[4];
	GS->A16.Ins.Byte23bit5=AllBits1.FindRef(23)[5];
	GS->A16.Ins.Byte23bit6=AllBits1.FindRef(23)[6];
	GS->A16.Ins.Byte23bit7=AllBits1.FindRef(23)[7];

	GS->A16.Ins.Byte24=ReceiveBytes[33];
	GS->A16.Ins.Byte25=ReceiveBytes[34];
	GS->A16.Ins.Byte26=ReceiveBytes[35];
	GS->A16.Ins.Byte27=ReceiveBytes[36];
	GS->A16.Ins.Byte28=ReceiveBytes[37];
	GS->A16.Ins.Byte29=ReceiveBytes[38];
}

void AUDPCockpitPort::ConvertStruct2_16(const TArray<uint8>& ReceiveBytes)
{
	GS->A16.Lcs.Byte1bit0=AllBits2.FindRef(1)[0];
	GS->A16.Lcs.Byte1bit1=AllBits2.FindRef(1)[1];
	GS->A16.Lcs.Byte1bit2=AllBits2.FindRef(1)[2];
	GS->A16.Lcs.Byte1bit3=AllBits2.FindRef(1)[3];
	GS->A16.Lcs.Byte1bit4=AllBits2.FindRef(1)[4];
	GS->A16.Lcs.Byte1bit5=AllBits2.FindRef(1)[5];
	GS->A16.Lcs.Byte1bit6=AllBits2.FindRef(1)[6];
	GS->A16.Lcs.Byte1bit7=AllBits2.FindRef(1)[7];
	
	GS->A16.Lcs.Byte3bit0=AllBits2.FindRef(3)[0];
	GS->A16.Lcs.Byte3bit1=AllBits2.FindRef(3)[1];
	GS->A16.Lcs.Byte3bit2=AllBits2.FindRef(3)[2];
	GS->A16.Lcs.Byte3bit3=AllBits2.FindRef(3)[3];
	GS->A16.Lcs.Byte3bit4=AllBits2.FindRef(3)[4];
	GS->A16.Lcs.Byte3bit5=AllBits2.FindRef(3)[5];
	GS->A16.Lcs.Byte3bit6=AllBits2.FindRef(3)[6];
	GS->A16.Lcs.Byte3bit7=AllBits2.FindRef(3)[7];

	GS->A16.Lcs.Byte7bit0=AllBits2.FindRef(7)[0];
	GS->A16.Lcs.Byte7bit1=AllBits2.FindRef(7)[1];
	GS->A16.Lcs.Byte7bit2=AllBits2.FindRef(7)[2];
	GS->A16.Lcs.Byte7bit3=AllBits2.FindRef(7)[3];
	GS->A16.Lcs.Byte7bit4=AllBits2.FindRef(7)[4];
	GS->A16.Lcs.Byte7bit5=AllBits2.FindRef(7)[5];
	GS->A16.Lcs.Byte7bit6=AllBits2.FindRef(7)[6];
	GS->A16.Lcs.Byte7bit7=AllBits2.FindRef(7)[7];
	GS->A16.Lcs.Byte8bit0=AllBits2.FindRef(8)[0];
	GS->A16.Lcs.Byte8bit1=AllBits2.FindRef(8)[1];
	GS->A16.Lcs.Byte8bit2=AllBits2.FindRef(8)[2];
	GS->A16.Lcs.Byte8bit3=AllBits2.FindRef(8)[3];
	GS->A16.Lcs.Byte8bit4=AllBits2.FindRef(8)[4];
	GS->A16.Lcs.Byte8bit5=AllBits2.FindRef(8)[5];
	GS->A16.Lcs.Byte8bit6=AllBits2.FindRef(8)[6];
	GS->A16.Lcs.Byte8bit7=AllBits2.FindRef(8)[7];
	GS->A16.Lcs.Byte9bit0=AllBits2.FindRef(9)[0];
	GS->A16.Lcs.Byte9bit1=AllBits2.FindRef(9)[1];
	GS->A16.Lcs.Byte9bit2=AllBits2.FindRef(9)[2];
	GS->A16.Lcs.Byte9bit3=AllBits2.FindRef(9)[3];
	GS->A16.Lcs.Byte9bit4=AllBits2.FindRef(9)[4];
	GS->A16.Lcs.Byte9bit5=AllBits2.FindRef(9)[5];
	GS->A16.Lcs.Byte9bit6=AllBits2.FindRef(9)[6];
	GS->A16.Lcs.Byte9bit7=AllBits2.FindRef(9)[7];
	GS->A16.Lcs.Byte10bit0=AllBits2.FindRef(10)[0];
	GS->A16.Lcs.Byte10bit1=AllBits2.FindRef(10)[1];
	GS->A16.Lcs.Byte10bit2=AllBits2.FindRef(10)[2];
	GS->A16.Lcs.Byte10bit3=AllBits2.FindRef(10)[3];
	GS->A16.Lcs.Byte10bit4=AllBits2.FindRef(10)[4];
	GS->A16.Lcs.Byte10bit5=AllBits2.FindRef(10)[5];
	GS->A16.Lcs.Byte10bit6=AllBits2.FindRef(10)[6];
	GS->A16.Lcs.Byte10bit7=AllBits2.FindRef(10)[7];
	
	GS->A16.Lcs.Byte11bit0=AllBits2.FindRef(11)[0];
	
}

void AUDPCockpitPort::ConvertStruct3_16(const TArray<uint8>& ReceiveBytes)
{
	GS->A16.Rcs.Byte1bit0=AllBits3.FindRef(1)[0];
	GS->A16.Rcs.Byte1bit1=AllBits3.FindRef(1)[1];
	GS->A16.Rcs.Byte1bit2=AllBits3.FindRef(1)[2];
	GS->A16.Rcs.Byte1bit3=AllBits3.FindRef(1)[3];
	GS->A16.Rcs.Byte1bit4=AllBits3.FindRef(1)[4];
	GS->A16.Rcs.Byte1bit5=AllBits3.FindRef(1)[5];
	GS->A16.Rcs.Byte1bit6=AllBits3.FindRef(1)[6];
	GS->A16.Rcs.Byte1bit7=AllBits3.FindRef(1)[7];
	GS->A16.Rcs.Byte2bit0=AllBits3.FindRef(2)[0];
	GS->A16.Rcs.Byte2bit1=AllBits3.FindRef(2)[1];
	
	GS->A16.Rcs.Byte3bit0=AllBits3.FindRef(3)[0];
	GS->A16.Rcs.Byte3bit1=AllBits3.FindRef(3)[1];
	GS->A16.Rcs.Byte3bit2=AllBits3.FindRef(3)[2];
	GS->A16.Rcs.Byte3bit3=AllBits3.FindRef(3)[3];
	GS->A16.Rcs.Byte3bit4=AllBits3.FindRef(3)[4];
	GS->A16.Rcs.Byte3bit5=AllBits3.FindRef(3)[5];
	GS->A16.Rcs.Byte3bit6=AllBits3.FindRef(3)[6];
	GS->A16.Rcs.Byte3bit7=AllBits3.FindRef(3)[7];
	GS->A16.Rcs.Byte4bit0=AllBits3.FindRef(4)[0];
	GS->A16.Rcs.Byte4bit1=AllBits3.FindRef(4)[1];
	GS->A16.Rcs.Byte4bit2=AllBits3.FindRef(4)[2];
	GS->A16.Rcs.Byte4bit3=AllBits3.FindRef(4)[3];
	GS->A16.Rcs.Byte4bit4=AllBits3.FindRef(4)[4];
	GS->A16.Rcs.Byte4bit5=AllBits3.FindRef(4)[5];
	GS->A16.Rcs.Byte4bit6=AllBits3.FindRef(4)[6];
	GS->A16.Rcs.Byte4bit7=AllBits3.FindRef(4)[7];
	GS->A16.Rcs.Byte5bit0=AllBits3.FindRef(5)[0];
	GS->A16.Rcs.Byte5bit1=AllBits3.FindRef(5)[1];
	GS->A16.Rcs.Byte5bit2=AllBits3.FindRef(5)[2];
	GS->A16.Rcs.Byte5bit3=AllBits3.FindRef(5)[3];
	GS->A16.Rcs.Byte5bit4=AllBits3.FindRef(5)[4];
	GS->A16.Rcs.Byte5bit5=AllBits3.FindRef(5)[5];
	GS->A16.Rcs.Byte5bit6=AllBits3.FindRef(5)[6];
	GS->A16.Rcs.Byte5bit7=AllBits3.FindRef(5)[7];
	GS->A16.Rcs.Byte6bit0=AllBits3.FindRef(6)[0];
	GS->A16.Rcs.Byte6bit1=AllBits3.FindRef(6)[1];
	GS->A16.Rcs.Byte6bit2=AllBits3.FindRef(6)[2];
	GS->A16.Rcs.Byte6bit3=AllBits3.FindRef(6)[3];
	GS->A16.Rcs.Byte6bit4=AllBits3.FindRef(6)[4];
	GS->A16.Rcs.Byte6bit5=AllBits3.FindRef(6)[5];
	GS->A16.Rcs.Byte6bit6=AllBits3.FindRef(6)[6];
	GS->A16.Rcs.Byte6bit7=AllBits3.FindRef(6)[7];
	GS->A16.Rcs.Byte7bit0=AllBits3.FindRef(7)[0];
	GS->A16.Rcs.Byte7bit1=AllBits3.FindRef(7)[1];
	GS->A16.Rcs.Byte7bit2=AllBits3.FindRef(7)[2];
	GS->A16.Rcs.Byte7bit3=AllBits3.FindRef(7)[3];
	GS->A16.Rcs.Byte7bit4=AllBits3.FindRef(7)[4];
	GS->A16.Rcs.Byte7bit5=AllBits3.FindRef(7)[5];
	GS->A16.Rcs.Byte7bit6=AllBits3.FindRef(7)[6];
	GS->A16.Rcs.Byte7bit7=AllBits3.FindRef(7)[7];
	
	GS->A16.Rcs.Byte8bit0=AllBits3.FindRef(8)[0];
	GS->A16.Rcs.Byte8bit1=AllBits3.FindRef(8)[1];

	GS->A16.Rcs.Byte9=ReceiveBytes[18];	
	GS->A16.Rcs.Byte10=ReceiveBytes[19];
	GS->A16.Rcs.Byte11=ReceiveBytes[20];
	GS->A16.Rcs.Byte12=ReceiveBytes[21];
	GS->A16.Rcs.Byte13=ReceiveBytes[22];
	GS->A16.Rcs.Byte14=ReceiveBytes[23];
	GS->A16.Rcs.Byte15=ReceiveBytes[24];
	GS->A16.Rcs.Byte16=ReceiveBytes[25];
	GS->A16.Rcs.Byte17=ReceiveBytes[26];
	GS->A16.Rcs.Byte18=ReceiveBytes[27];

}

void AUDPCockpitPort::ConvertStruct4_16(const TArray<uint8>& ReceiveBytes)
{
	GS->A16.Aps.Byte1bit0=AllBits4.FindRef(1)[0];
	GS->A16.Aps.Byte1bit1=AllBits4.FindRef(1)[1];
	GS->A16.Aps.Byte1bit2=AllBits4.FindRef(1)[2];
	GS->A16.Aps.Byte1bit3=AllBits4.FindRef(1)[3];
	GS->A16.Aps.Byte1bit4=AllBits4.FindRef(1)[4];
	GS->A16.Aps.Byte1bit5=AllBits4.FindRef(1)[5];
	GS->A16.Aps.Byte1bit6=AllBits4.FindRef(1)[6];
	GS->A16.Aps.Byte1bit7=AllBits4.FindRef(1)[7];
	GS->A16.Aps.Byte2bit0=AllBits4.FindRef(2)[0];
	GS->A16.Aps.Byte2bit1=AllBits4.FindRef(2)[1];
	GS->A16.Aps.Byte2bit2=AllBits4.FindRef(2)[2];
	GS->A16.Aps.Byte2bit3=AllBits4.FindRef(2)[3];
	GS->A16.Aps.Byte2bit4=AllBits4.FindRef(2)[4];
	GS->A16.Aps.Byte2bit5=AllBits4.FindRef(2)[5];
	GS->A16.Aps.Byte2bit6=AllBits4.FindRef(2)[6];
	GS->A16.Aps.Byte2bit7=AllBits4.FindRef(2)[7];
	GS->A16.Aps.Byte3bit0=AllBits4.FindRef(3)[0];
	GS->A16.Aps.Byte3bit1=AllBits4.FindRef(3)[1];
	GS->A16.Aps.Byte3bit2=AllBits4.FindRef(3)[2];

	GS->A16.Aps.A=Convert12Bit(ReceiveBytes[14],ReceiveBytes[15]);
	GS->A16.Aps.B=Convert12Bit(ReceiveBytes[16],ReceiveBytes[17]);
}

void AUDPCockpitPort::ConvertStruct5_16(const TArray<uint8>& ReceiveBytes)
{
	GS->A16.Atl.Byte1bit0=AllBits5.FindRef(1)[0];
	GS->A16.Atl.Byte1bit1=AllBits5.FindRef(1)[1];
	
	GS->A16.Atl.A=Convert12Bit(ReceiveBytes[14],ReceiveBytes[15]);
	
}

void AUDPCockpitPort::ConvertStruct6_16(const TArray<uint8>& ReceiveBytes)
{
	GS->A16.Atr.Byte1bit0=AllBits6.FindRef(1)[0];
	GS->A16.Atr.Byte1bit1=AllBits6.FindRef(1)[1];
	GS->A16.Atr.Byte1bit2=AllBits6.FindRef(1)[2];
	GS->A16.Atr.Byte1bit3=AllBits6.FindRef(1)[3];
	GS->A16.Atr.Byte1bit4=AllBits6.FindRef(1)[4];
	GS->A16.Atr.Byte1bit5=AllBits6.FindRef(1)[5];
	GS->A16.Atr.Byte1bit6=AllBits6.FindRef(1)[6];
	GS->A16.Atr.Byte1bit7=AllBits6.FindRef(1)[7];
	GS->A16.Atr.Byte2bit0=AllBits6.FindRef(2)[0];
	GS->A16.Atr.Byte2bit1=AllBits6.FindRef(2)[1];
	GS->A16.Atr.Byte2bit2=AllBits6.FindRef(2)[2];
	GS->A16.Atr.Byte2bit3=AllBits6.FindRef(2)[3];
	GS->A16.Atr.Byte2bit4=AllBits6.FindRef(2)[4];
	GS->A16.Atr.Byte2bit5=AllBits6.FindRef(2)[5];
	GS->A16.Atr.Byte2bit6=AllBits6.FindRef(2)[6];
	GS->A16.Atr.Byte2bit7=AllBits6.FindRef(2)[7];
	GS->A16.Atr.Byte3bit0=AllBits6.FindRef(3)[0];
	GS->A16.Atr.Byte3bit1=AllBits6.FindRef(3)[1];
	GS->A16.Atr.Byte3bit2=AllBits6.FindRef(3)[2];
	GS->A16.Atr.Byte3bit3=AllBits6.FindRef(3)[3];
	GS->A16.Atr.Byte3bit4=AllBits6.FindRef(3)[4];
	GS->A16.Atr.Byte3bit5=AllBits6.FindRef(3)[5];
}

void AUDPCockpitPort::ConvertStruct1_20(const TArray<uint8>& ReceiveBytes)
{
	GS->A20.Ins.Byte1bit0=AllBits1.FindRef(1)[0];
	GS->A20.Ins.Byte1bit1=AllBits1.FindRef(1)[1];
	GS->A20.Ins.Byte1bit2=AllBits1.FindRef(1)[2];
	GS->A20.Ins.Byte1bit3=AllBits1.FindRef(1)[3];
	GS->A20.Ins.Byte1bit4=AllBits1.FindRef(1)[4];
	GS->A20.Ins.Byte1bit5=AllBits1.FindRef(1)[5];
	GS->A20.Ins.Byte1bit6=AllBits1.FindRef(1)[6];
	GS->A20.Ins.Byte1bit7=AllBits1.FindRef(1)[7];
	GS->A20.Ins.Byte2bit0=AllBits1.FindRef(2)[0];
	GS->A20.Ins.Byte2bit1=AllBits1.FindRef(2)[1];
	GS->A20.Ins.Byte2bit2=AllBits1.FindRef(2)[2];
	GS->A20.Ins.Byte2bit3=AllBits1.FindRef(2)[3];
	GS->A20.Ins.Byte2bit4=AllBits1.FindRef(2)[4];
	GS->A20.Ins.Byte2bit5=AllBits1.FindRef(2)[5];
	GS->A20.Ins.Byte2bit6=AllBits1.FindRef(2)[6];
	GS->A20.Ins.Byte2bit7=AllBits1.FindRef(2)[7];
	GS->A20.Ins.Byte3bit0=AllBits1.FindRef(3)[0];
	GS->A20.Ins.Byte3bit1=AllBits1.FindRef(3)[1];
	GS->A20.Ins.Byte3bit2=AllBits1.FindRef(3)[2];
	GS->A20.Ins.Byte3bit3=AllBits1.FindRef(3)[3];
	GS->A20.Ins.Byte3bit4=AllBits1.FindRef(3)[4];
	GS->A20.Ins.Byte3bit5=AllBits1.FindRef(3)[5];
	GS->A20.Ins.Byte3bit6=AllBits1.FindRef(3)[6];
	GS->A20.Ins.Byte3bit7=AllBits1.FindRef(3)[7];
	GS->A20.Ins.Byte4bit0=AllBits1.FindRef(4)[0];
	GS->A20.Ins.Byte4bit1=AllBits1.FindRef(4)[1];
	GS->A20.Ins.Byte4bit2=AllBits1.FindRef(4)[2];
	GS->A20.Ins.Byte4bit3=AllBits1.FindRef(4)[3];
	GS->A20.Ins.Byte4bit4=AllBits1.FindRef(4)[4];
	GS->A20.Ins.Byte4bit5=AllBits1.FindRef(4)[5];
	GS->A20.Ins.Byte4bit6=AllBits1.FindRef(4)[6];
	GS->A20.Ins.Byte4bit7=AllBits1.FindRef(4)[7];
	GS->A20.Ins.Byte5bit0=AllBits1.FindRef(5)[0];
	GS->A20.Ins.Byte5bit1=AllBits1.FindRef(5)[1];
	GS->A20.Ins.Byte5bit2=AllBits1.FindRef(5)[2];
	GS->A20.Ins.Byte5bit3=AllBits1.FindRef(5)[3];
	GS->A20.Ins.Byte5bit4=AllBits1.FindRef(5)[4];
	GS->A20.Ins.Byte5bit5=AllBits1.FindRef(5)[5];
	GS->A20.Ins.Byte5bit6=AllBits1.FindRef(5)[6];
	GS->A20.Ins.Byte5bit7=AllBits1.FindRef(5)[7];
	GS->A20.Ins.Byte6bit0=AllBits1.FindRef(6)[0];
	GS->A20.Ins.Byte6bit1=AllBits1.FindRef(6)[1];
	GS->A20.Ins.Byte6bit2=AllBits1.FindRef(6)[2];
	GS->A20.Ins.Byte6bit3=AllBits1.FindRef(6)[3];
	GS->A20.Ins.Byte6bit4=AllBits1.FindRef(6)[4];
	GS->A20.Ins.Byte6bit5=AllBits1.FindRef(6)[5];
	GS->A20.Ins.Byte6bit6=AllBits1.FindRef(6)[6];
	GS->A20.Ins.Byte6bit7=AllBits1.FindRef(6)[7];
	GS->A20.Ins.Byte7bit0=AllBits1.FindRef(7)[0];
	GS->A20.Ins.Byte7bit1=AllBits1.FindRef(7)[1];
	GS->A20.Ins.Byte7bit2=AllBits1.FindRef(7)[2];
	GS->A20.Ins.Byte7bit3=AllBits1.FindRef(7)[3];
	GS->A20.Ins.Byte7bit4=AllBits1.FindRef(7)[4];
	GS->A20.Ins.Byte7bit5=AllBits1.FindRef(7)[5];
	GS->A20.Ins.Byte7bit6=AllBits1.FindRef(7)[6];
	GS->A20.Ins.Byte7bit7=AllBits1.FindRef(7)[7];
	GS->A20.Ins.Byte8bit0=AllBits1.FindRef(8)[0];
	GS->A20.Ins.Byte8bit1=AllBits1.FindRef(8)[1];
	GS->A20.Ins.Byte8bit2=AllBits1.FindRef(8)[2];
	GS->A20.Ins.Byte8bit3=AllBits1.FindRef(8)[3];
	GS->A20.Ins.Byte8bit4=AllBits1.FindRef(8)[4];
	GS->A20.Ins.Byte8bit5=AllBits1.FindRef(8)[5];
	GS->A20.Ins.Byte8bit6=AllBits1.FindRef(8)[6];
	GS->A20.Ins.Byte8bit7=AllBits1.FindRef(8)[7];
	GS->A20.Ins.Byte9bit0=AllBits1.FindRef(9)[0];
	GS->A20.Ins.Byte9bit1=AllBits1.FindRef(9)[1];
	GS->A20.Ins.Byte9bit2=AllBits1.FindRef(9)[2];
	GS->A20.Ins.Byte9bit3=AllBits1.FindRef(9)[3];
	GS->A20.Ins.Byte9bit4=AllBits1.FindRef(9)[4];
	GS->A20.Ins.Byte9bit5=AllBits1.FindRef(9)[5];
	GS->A20.Ins.Byte9bit6=AllBits1.FindRef(9)[6];
	GS->A20.Ins.Byte9bit7=AllBits1.FindRef(9)[7];
	GS->A20.Ins.Byte10bit0=AllBits1.FindRef(10)[0];
	GS->A20.Ins.Byte10bit1=AllBits1.FindRef(10)[1];
	GS->A20.Ins.Byte10bit2=AllBits1.FindRef(10)[2];
	GS->A20.Ins.Byte10bit3=AllBits1.FindRef(10)[3];
	GS->A20.Ins.Byte10bit4=AllBits1.FindRef(10)[4];
	GS->A20.Ins.Byte10bit5=AllBits1.FindRef(10)[5];
	GS->A20.Ins.Byte10bit6=AllBits1.FindRef(10)[6];
	GS->A20.Ins.Byte10bit7=AllBits1.FindRef(10)[7];
}

void AUDPCockpitPort::ConvertStruct2_20(const TArray<uint8>& ReceiveBytes)
{
	GS->A20.Lcs.Byte1bit0=AllBits2.FindRef(1)[0];
	GS->A20.Lcs.Byte1bit1=AllBits2.FindRef(1)[1];
	GS->A20.Lcs.Byte1bit2=AllBits2.FindRef(1)[2];
	GS->A20.Lcs.Byte1bit3=AllBits2.FindRef(1)[3];
	GS->A20.Lcs.Byte1bit4=AllBits2.FindRef(1)[4];
	GS->A20.Lcs.Byte1bit5=AllBits2.FindRef(1)[5];
	GS->A20.Lcs.Byte1bit6=AllBits2.FindRef(1)[6];
	GS->A20.Lcs.Byte1bit7=AllBits2.FindRef(1)[7];
	GS->A20.Lcs.Byte2bit0=AllBits2.FindRef(2)[0];
	GS->A20.Lcs.Byte2bit1=AllBits2.FindRef(2)[1];
	GS->A20.Lcs.Byte2bit2=AllBits2.FindRef(2)[2];
	GS->A20.Lcs.Byte2bit3=AllBits2.FindRef(2)[3];
	GS->A20.Lcs.Byte2bit4=AllBits2.FindRef(2)[4];
	GS->A20.Lcs.Byte2bit5=AllBits2.FindRef(2)[5];
	GS->A20.Lcs.Byte2bit6=AllBits2.FindRef(2)[6];
	GS->A20.Lcs.Byte2bit7=AllBits2.FindRef(2)[7];
	
	GS->A20.Lcs.Byte5bit0=AllBits2.FindRef(5)[0];
	GS->A20.Lcs.Byte5bit1=AllBits2.FindRef(5)[1];
	GS->A20.Lcs.Byte5bit2=AllBits2.FindRef(5)[2];
	GS->A20.Lcs.Byte5bit3=AllBits2.FindRef(5)[3];
	GS->A20.Lcs.Byte5bit4=AllBits2.FindRef(5)[4];
	GS->A20.Lcs.Byte5bit5=AllBits2.FindRef(5)[5];
	GS->A20.Lcs.Byte5bit6=AllBits2.FindRef(5)[6];
	GS->A20.Lcs.Byte5bit7=AllBits2.FindRef(5)[7];
}

void AUDPCockpitPort::ConvertStruct3_20(const TArray<uint8>& ReceiveBytes)
{
	GS->A20.Rcs.Byte5bit0=AllBits3.FindRef(5)[0];
	GS->A20.Rcs.Byte5bit1=AllBits3.FindRef(5)[1];
	GS->A20.Rcs.Byte5bit2=AllBits3.FindRef(5)[2];
	GS->A20.Rcs.Byte5bit3=AllBits3.FindRef(5)[3];
}

void AUDPCockpitPort::ConvertStruct4_20(const TArray<uint8>& ReceiveBytes)
{
	GS->A20.Aps.Byte1bit0=AllBits4.FindRef(1)[0];
	GS->A20.Aps.Byte1bit1=AllBits4.FindRef(1)[1];
	GS->A20.Aps.Byte1bit2=AllBits4.FindRef(1)[2];
	GS->A20.Aps.Byte1bit3=AllBits4.FindRef(1)[3];
	GS->A20.Aps.Byte1bit4=AllBits4.FindRef(1)[4];
	GS->A20.Aps.Byte1bit5=AllBits4.FindRef(1)[5];
	GS->A20.Aps.Byte1bit6=AllBits4.FindRef(1)[6];
	GS->A20.Aps.Byte1bit7=AllBits4.FindRef(1)[7];
	GS->A20.Aps.Byte2bit0=AllBits4.FindRef(2)[0];
	GS->A20.Aps.Byte2bit1=AllBits4.FindRef(2)[1];
	GS->A20.Aps.Byte2bit2=AllBits4.FindRef(2)[2];
	GS->A20.Aps.Byte2bit3=AllBits4.FindRef(2)[3];
	GS->A20.Aps.Byte2bit4=AllBits4.FindRef(2)[4];
	GS->A20.Aps.Byte2bit5=AllBits4.FindRef(2)[5];
	GS->A20.Aps.Byte2bit6=AllBits4.FindRef(2)[6];
	GS->A20.Aps.Byte2bit7=AllBits4.FindRef(2)[7];
	GS->A20.Aps.Byte3bit0=AllBits4.FindRef(3)[0];
	GS->A20.Aps.Byte3bit1=AllBits4.FindRef(3)[1];
	GS->A20.Aps.Byte3bit2=AllBits4.FindRef(3)[2];
	GS->A20.Aps.Byte3bit3=AllBits4.FindRef(3)[3];
	GS->A20.Aps.Byte3bit4=AllBits4.FindRef(3)[4];
	GS->A20.Aps.Byte3bit5=AllBits4.FindRef(3)[5];
	GS->A20.Aps.Byte3bit6=AllBits4.FindRef(3)[6];
	GS->A20.Aps.Byte3bit7=AllBits4.FindRef(3)[7];
	GS->A20.Aps.Byte4bit0=AllBits4.FindRef(4)[0];
	GS->A20.Aps.Byte4bit1=AllBits4.FindRef(4)[1];
	GS->A20.Aps.Byte4bit2=AllBits4.FindRef(4)[2];
	GS->A20.Aps.Byte4bit3=AllBits4.FindRef(4)[3];
}

void AUDPCockpitPort::ConvertStruct5_20(const TArray<uint8>& ReceiveBytes)
{
	GS->A20.Atl.Byte1bit0=AllBits5.FindRef(1)[0];
	GS->A20.Atl.Byte1bit1=AllBits5.FindRef(1)[1];
	GS->A20.Atl.Byte1bit2=AllBits5.FindRef(1)[2];
	GS->A20.Atl.Byte1bit3=AllBits5.FindRef(1)[3];
	GS->A20.Atl.Byte1bit4=AllBits5.FindRef(1)[4];
	GS->A20.Atl.Byte1bit5=AllBits5.FindRef(1)[5];

	GS->A20.Atl.A=Convert12Bit(ReceiveBytes[14],ReceiveBytes[15]);
}

void AUDPCockpitPort::ConvertStruct6_20(const TArray<uint8>& ReceiveBytes)
{
	GS->A20.Atr.Byte1bit0=AllBits6.FindRef(1)[0];
	GS->A20.Atr.Byte1bit1=AllBits6.FindRef(1)[1];
	GS->A20.Atr.Byte1bit2=AllBits6.FindRef(1)[2];
	GS->A20.Atr.Byte1bit3=AllBits6.FindRef(1)[3];
	GS->A20.Atr.Byte1bit4=AllBits6.FindRef(1)[4];
	GS->A20.Atr.Byte1bit5=AllBits6.FindRef(1)[5];
	GS->A20.Atr.Byte1bit6=AllBits6.FindRef(1)[6];
	GS->A20.Atr.Byte1bit7=AllBits6.FindRef(1)[7];
	GS->A20.Atr.Byte2bit0=AllBits6.FindRef(2)[0];
	GS->A20.Atr.Byte2bit1=AllBits6.FindRef(2)[1];
	GS->A20.Atr.Byte2bit2=AllBits6.FindRef(2)[2];
	GS->A20.Atr.Byte2bit3=AllBits6.FindRef(2)[3];
	GS->A20.Atr.Byte2bit4=AllBits6.FindRef(2)[4];
	GS->A20.Atr.Byte2bit5=AllBits6.FindRef(2)[5];
	GS->A20.Atr.Byte2bit6=AllBits6.FindRef(2)[6];
	GS->A20.Atr.Byte2bit7=AllBits6.FindRef(2)[7];
	GS->A20.Atr.Byte3bit0=AllBits6.FindRef(3)[0];
	GS->A20.Atr.Byte3bit1=AllBits6.FindRef(3)[1];
	GS->A20.Atr.Byte3bit2=AllBits6.FindRef(3)[2];
	GS->A20.Atr.Byte3bit3=AllBits6.FindRef(3)[3];
	GS->A20.Atr.Byte3bit4=AllBits6.FindRef(3)[4];
	GS->A20.Atr.Byte3bit5=AllBits6.FindRef(3)[5];

	GS->A20.Atr.A=Convert12Bit(ReceiveBytes[14],ReceiveBytes[15]);
	GS->A20.Atr.B=Convert12Bit(ReceiveBytes[16],ReceiveBytes[17]);
}


uint16 AUDPCockpitPort::Convert12Bit(uint8 Byte1, uint8 Byte2)
{
	
	// 将两个字节合成一个两字节的数据类型
	uint16 result = ((static_cast<uint16>(Byte1) & 0xFF) << 4) | ((static_cast<uint16>(Byte2) & 0xF0) >> 4);
	//UE_LOG(LogTemp, Log, TEXT("Result: %04X"), result);
	//GEngine->AddOnScreenDebugMessage(-1,5.f,FColor::Red,FString::Printf(TEXT("Result:%04X,%d"),result,result));
	return result;
	// 输出合成的两字节数据
	
}

double AUDPCockpitPort::GetBreakValue(double min, double max, double cur)
{
	
	float percentage=(cur-min)/(max-min);
	double result=FMath::Clamp(percentage,0.f,1.f);
	return result;
}

uint16 AUDPCockpitPort::GetBreakValue2(uint16 min, uint16 max, uint16 cur)
{
	int percentage=(cur-min)/(max-min);
	int result=FMath::Clamp(percentage,-1,1);
	return result;
}
