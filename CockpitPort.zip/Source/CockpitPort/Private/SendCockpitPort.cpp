// Fill out your copyright notice in the Description page of Project Settings.


#include "SendCockpitPort.h"

#include "CockpitPortGameStateBase.h"
#include "Algo/Copy.h"
#include "CockpitPort/CockpitPortGameModeBase.h"
#include "Common/UdpSocketBuilder.h"

// Sets default values
ASendCockpitPort::ASendCockpitPort()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	command10.Add(4001,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x10, 0x01, 0x08, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x10});
	command10.Add(4002,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x10, 0x02, 0x04, 0xff, 0xff, 0xff, 0xff, 0x11});
	command10.Add(4003,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x10, 0x03, 0x0c, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x12});
	command10.Add(4004,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x10, 0x04, 0x00, 0x13});
	command10.Add(4005,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x10, 0x05, 0x00, 0x14});
	command10.Add(4006,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x10, 0x06, 0x00, 0x15});
	command10.Add(4007,{0x07, 0x03, 0x00, 0x00, 0x00, 0x01, 0x84, 0x6c});
	command10.Add(4008,{0x08, 0x03, 0x00, 0x00, 0x00, 0x01, 0x84, 0x93});

	//54 57 53 00 01 00 11 01 00 11
	command11.Add(4001,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x01, 0x0d, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,0x11});
	//command11.Add(4001,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x01, 0x00, 0x11});
	//command11.Add(4002,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x02, 0x00, 0x12});
	//command11.Add(4002,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x02, 0x0b, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x12});
	command11.Add(4002,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x02, 0x0b, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1d});
	command11.Add(4003,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x03, 0x16, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x13});
	//command11.Add(4003,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x03, 0x00, 0x13});

	command11.Add(4004,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x04, 0x00, 0x14});
	command11.Add(4005,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x05, 0x00, 0x15});
	command11.Add(4006,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x11, 0x06, 0x00, 0x16});
	command11.Add(4007,{0x07, 0x03, 0x00, 0x00, 0x00, 0x01, 0x84, 0x6c});
	command11.Add(4008,{0x08, 0x03, 0x00, 0x00, 0x00, 0x01, 0x84, 0x93});
	
	command16.Add(4001,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x16, 0x01, 0x0a, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x16});
	command16.Add(4002,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x16, 0x02, 0x0a, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x17});
	command16.Add(4003,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x16, 0x03, 0x09, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x18});
	command16.Add(4004,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x16, 0x04, 0x00, 0x19});
	command16.Add(4005,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x16, 0x05, 0x00, 0x1a});
	command16.Add(4006,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x16, 0x06, 0x00, 0x1b});
	command16.Add(4007,{0x07, 0x03, 0x00, 0x00, 0x00, 0x01, 0x84, 0x6c});
	command16.Add(4008,{0x08, 0x03, 0x00, 0x00, 0x00, 0x01, 0x84, 0x93});
	
	command20.Add(4001,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x20, 0x01, 0x08, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x20});
	command20.Add(4002,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x20, 0x02, 0x09, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x21});
	command20.Add(4003,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x20, 0x03, 0x07, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x22});
	command20.Add(4004,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x20, 0x04, 0x00, 0x23});
	command20.Add(4005,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x20, 0x05, 0x00, 0x24});
	command20.Add(4006,{0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0x20, 0x06, 0x00, 0x25});
	command20.Add(4007,{0x07, 0x03, 0x00, 0x00, 0x00, 0x01, 0x84, 0x6c});
	command20.Add(4008,{0x08, 0x03, 0x00, 0x00, 0x00, 0x01, 0x84, 0x93});
	//GS = Cast<ACockpitPortGameStateBase>(UGameplayStatics::GetGameState(GetWorld()));
	
}

// Called when the game starts or when spawned
void ASendCockpitPort::BeginPlay()
{
	Super::BeginPlay();
	
	int32 sent = 0;
	GS = Cast<ACockpitPortGameStateBase>(UGameplayStatics::GetGameState(GetWorld()));
	ACockpitPortGameModeBase*GM=Cast<ACockpitPortGameModeBase>(GetWorld()->GetAuthGameMode());
	PlaneIndex=GM->PlaneModel;
	
}

// Called every frame
void ASendCockpitPort::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void ASendCockpitPort::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (SenderSocket)
	{
		SenderSocket->Close();
		ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(SenderSocket);
	}
	delete commandtemp;
	commandtemp=nullptr;
	
}

bool ASendCockpitPort::StartUDPSender(const FString& YourChosenSocketName, const FString& TheIP, const int32 ThePort)
{
	RemoteAddr = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->CreateInternetAddr();
	bool bIsValid;
	RemoteAddr->SetIp(*TheIP, bIsValid);
	RemoteAddr->SetPort(ThePort);
	if (!bIsValid)
	{
		UE_LOG(LogTemp, Warning, TEXT("Rama UDP Sender>> IP address was not valid! "), *TheIP);
		return false;
	}

	SenderSocket = FUdpSocketBuilder(*YourChosenSocketName)
	  .AsReusable()
	.AsNonBlocking()
	  .WithSendBufferSize(2 * 1024 * 1024);

	int32 SendSize = 2 * 1024 * 1024;
	SenderSocket->SetSendBufferSize(SendSize, SendSize);
	SenderSocket->SetReceiveBufferSize(SendSize, SendSize);
	if (bIsValid)
	{
		bIsValid = true;
	}
	return bIsValid;
}

void ASendCockpitPort::LoadSendCommand(int32 PlaneModel,int32 Key)
{
	TMap<int32,TArray<uint8>>AllCommand;
	switch (PlaneModel)
	{
	case 10:AllCommand=command10;break;
	case 11:AllCommand=command11;break;
	case 16:AllCommand=command16;break;
	case 20:AllCommand=command20;break;
		default:
			;
	}
	int32 num=AllCommand.Find(Key)->Num();
	if(AllCommand.FindRef(Key).Num()>0)
	{
		const uint8*Dataptr=AllCommand.Find(Key)->GetData();
		length=AllCommand.FindRef(Key).Num();
		commandtemp=new uint8[num];
		FMemory::Memcpy(commandtemp,Dataptr,sizeof(uint8)*num);
	}
}

bool ASendCockpitPort::RamaUDPSender_SendCommand()
{
	if (!SenderSocket)
	{
		UE_LOG(LogTemp, Warning, TEXT("No sender socket"));
		return false;
	}
	//消息处理
	int32 BytesSent = 0;
	int32 sent = 0;
	if(SendPort==4004&&PlaneIndex==20)
	{
		if(count==0)
		{
			SenderSocket->SendTo(commandtemp, length, BytesSent, *RemoteAddr);
			count=1;
		}
		else 
		{
			SenderSocket->SendTo(command20_2, 5, BytesSent, *RemoteAddr);
			count=0;
		}
		
	}
	else
	{
		SenderSocket->SendTo(commandtemp, length, BytesSent, *RemoteAddr);
	}
	
	if (BytesSent < 0)
	{
		const FString Str = "Socket is valid but the receiver received 0 bytes, make sure it is listening properly!";
		return false;
	}
	//UE_LOG(LogTemp, Warning, TEXT("UDP Send Succcess! INFO Sent = %s "), *ToSend);

	return true;
}

bool ASendCockpitPort::RamaUDPSender_SendData()
{
	if (!SenderSocket)
	{
		UE_LOG(LogTemp, Warning, TEXT("No sender socket"));
		return false;
	}
	int32 BytesSent = 0;
	int32 sent = 0;
	uint8*TEMP=nullptr;
	switch (PlaneIndex)
	{
		case 10:TEMP=(uint8*)&GS->A10;break;
		case 11:TEMP=(uint8*)&GS->A11;break;
		case 16:TEMP=(uint8*)&GS->A16;break;
		case 20:TEMP=(uint8*)&GS->A20;break;
		default:
			;
	}
	
	SenderSocket->SendTo(TEMP, sizeof (ACockpitPortGameStateBase::A11), BytesSent, *RemoteAddr);
	if (BytesSent < 0)
	{
		const FString Str = "Socket is valid but the receiver received 0 bytes, make sure it is listening properly!";
		UE_LOG(LogTemp, Error, TEXT("%s"), *Str);
		return false;
	}
	//UE_LOG(LogTemp, Warning, TEXT("UDP Send Succcess! INFO Sent = %s "), *ToSend);
	return true;
}

bool ASendCockpitPort::RamaUDPSender_SendDataFS()
{
	if (!SenderSocket)
	{
		UE_LOG(LogTemp, Warning, TEXT("No sender socket"));
		return false;
	}
	int32 BytesSent = 0;
	int32 sent = 0;
	uint8*TEMP=nullptr;
	int32 Fs_count=0;
	switch (PlaneIndex)
	{
		case 10:TEMP=(uint8*)&GS->Fs10;
		Fs_count=sizeof GS->Fs10;
		break;
		case 11:TEMP=(uint8*)&GS->Fs11;
		Fs_count=sizeof GS->Fs11;
		break;
		case 16:TEMP=(uint8*)&GS->Fs16;
		Fs_count=sizeof GS->Fs16;
		break;
		case 20:TEMP=(uint8*)&GS->Fs20;
		Fs_count=sizeof GS->Fs20;
		break;
		default:
			;
	}
	
	SenderSocket->SendTo(TEMP, Fs_count, BytesSent, *RemoteAddr);
	if (BytesSent < 0)
	{
		const FString Str = "Socket is valid but the receiver received 0 bytes, make sure it is listening properly!";
		UE_LOG(LogTemp, Error, TEXT("%s"), *Str);
		return false;
	}
	//UE_LOG(LogTemp, Warning, TEXT("UDP Send Succcess! INFO Sent = %s "), *ToSend);
	return true;
}

bool ASendCockpitPort::RamaUDPSender_SendDate(TArray<uint8> data)
{
	if (!SenderSocket)
	{
		UE_LOG(LogTemp, Warning, TEXT("No sender socket"));
		return false;
	}
	//消息处理
	int32 BytesSent = 0;
	int32 size = data.Num();
	int32 sent = 0;
	SenderSocket->SendTo(&data[0], size, BytesSent, *RemoteAddr);
	if (BytesSent < 0)
	{
		const FString Str = "Socket is valid but the receiver received 0 bytes, make sure it is listening properly!";
		UE_LOG(LogTemp, Error, TEXT("%s"), *Str);
		return false;
	}
	//UE_LOG(LogTemp, Warning, TEXT("UDP Send Succcess! INFO Sent = %s "), *ToSend);
	return true;
}

