// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include <stdbool.h>

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Runtime/Sockets/Public/Sockets.h"
#include "Sockets/Public/SocketSubsystem.h"
#include"Runtime/Networking/Public/Common/UdpSocketReceiver.h"
#include "Runtime/Networking/Public/Common/UdpSocketBuilder.h"
#include "UDPCockpitPort.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnUdpByteMessageDelegate, const TArray<uint8>&, Message, const FString&, SenderIp);
UCLASS()
class COCKPITPORT_API AUDPCockpitPort : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AUDPCockpitPort();
	
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	//FSocket* ListenSocket=nullptr;
	//FUdpSocketReceiver* Receiver = nullptr;//
	class ACockpitPortGameStateBase*GS;
	TMap<int32,FSocket*>ListenSockets;//键为端口，值为该端口下的Socket
	TArray<FUdpSocketReceiver*>Receivers;
	int32 Ports[8]{5001,5002,5003,5004,5005,5006,5007,5008};
	uint8 TEMPPORT[8][9];
	//收到的所有字节数据
	//TArray<uint8> ReceiveBytes;
	//座舱的所有信息
	TMap<int32,TArray<uint8>>AllBits1;
	TMap<int32,TArray<uint8>>AllBits2;
	TMap<int32,TArray<uint8>>AllBits3;
	TMap<int32,TArray<uint8>>AllBits4;
	TMap<int32,TArray<uint8>>AllBits5;
	TMap<int32,TArray<uint8>>AllBits6;
	TMap<int32,TArray<uint8>>AllBits7;
	TMap<int32,TArray<uint8>>AllBits8;
	//最终结构体数据
	uint8 SerialPort=0;
	uint16 curbv;
	uint16 curbv2;

	int32 PlaneIndex;
public:
	UFUNCTION()
	bool ReadBit(uint8 ByteValue,int32 BitIndex);//获取该字节的某一位
	
	UFUNCTION()
	static FString GetLocalIpAddress()
	{
		FString IpAddr("NONE");

		bool canBind = false;
		TSharedRef<FInternetAddr>LocalIp = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->GetLocalHostAddr(*GLog,canBind);

		if(LocalIp->IsValid())
		{
			IpAddr = LocalIp->ToString(false); //如果想附加端口就写 ture
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("Failed to get local address."));
			return " ";
		}
		return IpAddr;
	}//获取本地IP
	UFUNCTION(BlueprintCallable, Category = "UDP")
	void StartUDPReceiver(const FString& YourChosenSocketName,
	const FString& TheIP, const int32 ThePort);//初始化UDP收包
	
	void RecvData(const FArrayReaderPtr& Data, const FIPv4Endpoint& From);//实际数据接收

	void ConvertBytes(TMap<int32,TArray<uint8>>&Bytes,int32& ByteIndex,TArray<uint8>RecvData);//将字节流转换为所需数据

	void ConvertStruct1_10(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct2_10(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct3_10(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct4_10(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct5_10(const TArray<uint8>&ReceiveBytes);
	
	void ConvertStruct1(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct2(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct3(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct4(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct5(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct6(const TArray<uint8>&ReceiveBytes);

	void ConvertStruct1_16(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct2_16(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct3_16(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct4_16(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct5_16(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct6_16(const TArray<uint8>&ReceiveBytes);

	void ConvertStruct1_20(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct2_20(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct3_20(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct4_20(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct5_20(const TArray<uint8>&ReceiveBytes);
	void ConvertStruct6_20(const TArray<uint8>&ReceiveBytes);
	//8位转为一字节数据
	TMap<int32,TArray<uint8>>FrameHeaderArray10;
	TMap<int32,TArray<uint8>>FrameHeaderArray11;
	TMap<int32,TArray<uint8>>FrameHeaderArray16;
	TMap<int32,TArray<uint8>>FrameHeaderArray20;
	//读取12位有效数据
	uint16 Convert12Bit(uint8 Byte1,uint8 Byte2);	
	//获取刹车的程度比例
	//获取刹车百分比
	double GetBreakValue(double min,double max,double cur);

	uint16 GetBreakValue2(uint16 min,uint16 max,uint16 cur);
	UPROPERTY(BlueprintAssignable, Category = "Socket|Event")
	FOnUdpByteMessageDelegate OnByteMessage;
};
