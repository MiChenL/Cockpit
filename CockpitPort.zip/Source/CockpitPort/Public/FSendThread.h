﻿#pragma once

#include "HAL/RunnableThread.h"
class FSendThread : public FRunnable
{
public:
	
	FSendThread();
	FSendThread(class ASendCockpitPort*SendCockpitPort);
	virtual ~FSendThread();

	// FRunnable interface
	virtual bool Init() override;
	virtual uint32 Run() override;
	virtual void Stop() override;
	virtual void Exit() override;
	// End of FRunnable interface
	FRunnableThread *Thread;
	// 设置 Socket 发送的消息
	//void SetMessage(const FString& NewMessage);
private:
	// 在这里添加你的 Socket 相关的成员变量和方法
	ASendCockpitPort*MyClassInstance;
	FThreadSafeBool Stopping;
public:
	FString SocketIP;
	int32 Port;
	int32 PlaneIndex;
	int32 Index;//1、座舱，2、航电 3、飞防
	float SleepSecond;
};