// Fill out your copyright notice in the Description page of Project Settings.

#pragma once


#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Kismet/GameplayStatics.h"
#include "SendCockpitPort.generated.h"



UCLASS()
class COCKPITPORT_API ASendCockpitPort : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ASendCockpitPort();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	int32 ip;
	//发送端口
	int32 SendPort;
	//飞机型号
	int32 PlaneIndex;
	//指令发送长度
	int32 length;
	//查询设备型号数据，返回当前设备ID号；当前设备位置标记；校验和  例：54 57 53 00 01 00 Y1 Y2 00 SUM
	uint8 command[10] = { 0x54, 0x57, 0x53, 0x00, 0x01, 0x00, 0xff, 0xff, 0x00, 0xfd };
	//机型20二次查询 角度查询指令
	uint8 command20_2[5]={0x68,0x04,0x00,0x04,0x08};

	int32 count=0;

	//确定机型后的查询座舱信息指令
	TMap<int32,TArray<uint8>>command10;
	TMap<int32,TArray<uint8>>command11;
	TMap<int32,TArray<uint8>>command16;
	TMap<int32,TArray<uint8>>command20;
	//实际向座舱发送的指令
	uint8*commandtemp=nullptr;
	//发送实际飞防和航电的数据
	class ACockpitPortGameStateBase*GS=nullptr;
	
	//FFlight11S Flight11;
	FSocket* SenderSocket;
	//远程的地址
	TSharedPtr<FInternetAddr> RemoteAddr;
	UFUNCTION(BlueprintCallable, Category = "UDP")
	bool StartUDPSender(const FString& YourChosenSocketName, const FString& TheIP,const int32 ThePort);
	//动态读取要发送的指令 command为实际发送的指令，Key为对应发送接口的查询键(发送的端口)
	void LoadSendCommand(int32 PlaneModel,int32 Key);
	//向指定IP端口发送数据
	UFUNCTION(BlueprintCallable, Category = "UDP")
	bool RamaUDPSender_SendCommand();
	UFUNCTION(BlueprintCallable, Category = "UDP")
	bool RamaUDPSender_SendData();
	UFUNCTION(BlueprintCallable, Category = "UDP")
	bool RamaUDPSender_SendDataFS();
	UFUNCTION(BlueprintCallable, Category = "UDP")
	bool RamaUDPSender_SendDate(TArray<uint8>data);
};
