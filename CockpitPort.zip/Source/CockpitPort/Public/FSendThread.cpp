﻿#include "FSendThread.h"

#include "SendCockpitPort.h"

FSendThread::FSendThread()
{
	
}

FSendThread::FSendThread(class ASendCockpitPort*SendCockpitPort)
	: MyClassInstance(SendCockpitPort),Stopping(false),SleepSecond(0.01)
{
	
}

FSendThread::~FSendThread()
{
	
	if(Thread)
	{
		delete Thread;
		Thread = nullptr;
	}
	Stop();
}

bool FSendThread::Init()
{
	// 初始化你的 Socket 相关的代码
	
	if (MyClassInstance)
	{
		switch (Index)
		{
		case 1:		MyClassInstance->StartUDPSender(TEXT("SendSocket"),SocketIP,Port);
					MyClassInstance->LoadSendCommand(PlaneIndex,Port);
					break;
		case 2:
			MyClassInstance->StartUDPSender(TEXT("SendSocket"),SocketIP,Port);//航电

			break;
		case 3:		MyClassInstance->StartUDPSender(TEXT("SendSocket"),SocketIP,Port);
			break;
				default: ;
		}
	}
	
	return true;
}

uint32 FSendThread::Run()
{
	
	while (!Stopping)
	{
		// 在这里实现每隔 10 毫秒发送消息的逻辑
		// 使用 FPlatformProcess::Sleep 来控制线程的休眠时间
		if (MyClassInstance)
		{
			switch (Index)
			{
			case 1:		MyClassInstance->RamaUDPSender_SendCommand();
						break;
			case 2:     MyClassInstance->RamaUDPSender_SendData();
						break;
			case 3:     MyClassInstance->RamaUDPSender_SendDataFS();
						break;
					default: ;
			}
			
			
		}
		
		// 例如：
		// SendMessage(MessageToSend);
		FPlatformProcess::Sleep(SleepSecond);
	}

	return 0;
}

void FSendThread::Stop()
{
	Stopping = true;
}

void FSendThread::Exit()
{
	// 清理你的 Socket 相关资源
}