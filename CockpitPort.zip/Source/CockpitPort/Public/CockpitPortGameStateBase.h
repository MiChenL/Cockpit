// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameStateBase.h"
#include "CockpitPortGameStateBase.generated.h"

#pragma pack(push,1)
USTRUCT()
struct FFlight10_FS
{
	GENERATED_BODY()
	int sw_gear;  //起落架位置
	int sw_airbrk;//减速板位置
	int sw_umbrl; //减速伞位置
	int sw_nwoper;
	int sw_missileabandon;
	
	int pb_start;
	int pb_engpark;
	int sw_operatemode;
	int pb_startinair;
	int sw_boostingcut;
	int sw_autoadjust;
	int sw_antiasthma;
	int sw_trainfighting;
	int sw_automanual;
	int sw_ZEQadjust;;
	
	int sw_confb;
	int sw_confb1;
	int sw_autolevel;
	int sw_autocut;
	int sw_autopilot;
	int sw_lattrim;
	int sw_dlink;
	int sw_simbackup;
	int sw_manualreset;

	double pb1;
	double pb2;
};
#pragma pack(pop)

#pragma pack(push,1)
USTRUCT()
struct FFlight11_FS
{
	GENERATED_BODY()
	bool sw_gear;  //起落架位置	9,1
	bool sw_dlink; //刚性链接状态	左台 4.1
	bool sw_airbrk;//减速板位置	油门右发 S8
	bool sw_umbrl; //减速伞位置	
	
	bool sw_stick_link; //驾驶杆上联合操纵扳机 2,6
	bool sw_stick_level;//驾驶杆上的改平按钮 2,1
	bool sw_stick_saucut;//驾驶杆上的CAY断开按钮 1,0 
	bool sw_stick_trim[4];//驾驶杆上的四位配平按钮     0：上（1，5） 1：下（1，6）  2：左（1，7） 3：右（2，0）

	bool sw_saupad_state;		//CAY 控制板 状态 左台3，6
	bool sw_saupad_auto;		//CAY 控制板 自动 左台 1，4
	bool sw_saupad_clear;		//CAY 控制板	消除	左台2，0
	bool sw_saupad_altstab;		//CAY 控制板	气压高度 左台 1，7
	bool sw_saupad_hightstab;	//CAY 控制板	无线电高度 左台 1，5
	

	double pb1;			//左主轮刹车操作位置
	double pb2;			//右主轮刹车操纵位置
};
#pragma pack(pop)

#pragma pack(push,1)
USTRUCT()
struct FFlight16_FS
{
	GENERATED_BODY()
	bool sw_gear;  //起落架位置
	bool sw_dlink; //刚性链接状态
	bool sw_airbrk;//减速板位置
	bool sw_umbrl; //减速伞位置
	
	bool bt_stick_link; //驾驶杆上
	bool bt_stick_level;
	bool bt_stick_saucut;
	bool bt_stick_trim[4];
	bool sw_stick_autobrk;
	bool sw_pestick_brake;
	bool bt_pestick_autope;
	int  sw_pestick_velset;
	bool bt_ufcp_auto;
	bool bt_ufcp_angstab;
	bool bt_ufcp_altstab;
	bool bt_ufcp_hightstab;
	bool bt_ufcp_velstab;
	bool bt_ufcp_machstab;
	bool bt_ufcp_pathctrl;
	
	double pb1;
	double pb2;
};
#pragma pack(pop)

#pragma pack(push,1)
USTRUCT()
struct FFlight20_FS
{
	GENERATED_BODY()
	int sw_gear;  //起落架位置
	int sw_airbrk;//减速板位置
	int sw_umbrl; //减速伞位置
	int sw_nwoper;
	
	int sw_missileabandon;
	int pb_start;
	int pb_engpark;
	int sw_operatemode;
	int pb_startinair;
	int sw_boostingcut;
	int sw_autoadjust;
	int sw_antiasthma;
	int sw_trainfighting;
	int sw_automanual;
	int sw_ZEQadjust;;
	
	int sw_confb;
	int sw_confb1;
	
	int sw_autolevel;
	int sw_autocut;
	int sw_autopilot;
	int sw_dlink;
	
	int sw_lattrim;
	int sw_simbackup;
	int sw_manualreset;
	double pb1;
	double pb2;
};
#pragma pack(pop)




#pragma pack(push,1)
USTRUCT()
struct FAvionics_10
{
	GENERATED_BODY()
	struct InstrumentPanel//仪表盘
	{

	     short Byte1bit0;	  // 飞控按键按下  
         short Byte1bit1;	  // 火警按键按下  
         short Byte1bit2;	  // 停车按键按下  
         short Byte1bit3;	  // 主警告按键按下  
         short Byte1bit4;	  // 阻力伞-放伞  
         short Byte1bit5;	  // 阻力伞-放伞  
         short Byte1bit6;	  // 着陆灯/自动/断 钮子拨到 着陆灯   
         short Byte1bit7;	  // 着陆灯断  
         short Byte2bit0;	  // 旋钮开关拨到 油箱 按下  
         short Byte2bit1;	  // 旋钮开关拨到 ● 按下  
		 short Byte2bit2;	  // 旋钮开关拨到 箔▲条 按下  
         short Byte2bit3;	  // 旋钮开关拨到 外挂 按下  
         short Byte2bit4;	  // 钮子开关拨到 手动    
         short Byte2bit5;	  // 钮子开关拨到 关1  
         short Byte2bit6;	  // 钮子开关拨到 开     
         short Byte2bit7;	  // 钮子开关拨到 关2  
         short Byte3bit0;	  // 氧气准备按键按下
         short Byte3bit1;	  //备用氧气 按键 按下  
         short Byte3bit2;	  //空气活门 按键 按下  
         short Byte3bit3;	  //平显亮度 电位器开关 开  
         short Byte3bit4;	  //UFCP亮度 电位器开关 开  
         short Byte3bit5;	  //UFCP -->1 按钮 按下  
         short Byte3bit6;	  //UFCP -->2 按钮 按下  
         short Byte3bit7;	  //UFCP -->3 按钮 按下  
         short Byte4bit0;	  //UFCP -->4 按钮 按下  
         short Byte4bit1;	  //UFCP -->5 按钮 按下  
         short Byte4bit2;	  //音量1▲ 按钮 按下  
         short Byte4bit3;	  //音量1▼ 按钮 按下   
         short Byte4bit4;	  //音量2▲ 按钮 按下   
         short Byte4bit5;	  //音量2▼ 按钮 按下  
         short Byte4bit6;	  //故障单1 按钮 按下  
         short Byte4bit7;	  //2 按钮 按下  
         short Byte5bit0;	  //3 按钮 按下  
         short Byte5bit1;	  //航路点4 按钮 按下  
         short Byte5bit2;	  //时间5 按钮 按下  
         short Byte5bit3;	  //6 按钮 按下  
         short Byte5bit4;	  //识别7 按钮 按下  
         short Byte5bit5;	  //音量8 按钮 按下  
         short Byte5bit6;	  //9 按钮 按下  
         short Byte5bit7;	  //返回 按钮 按下  
         short Byte6bit0;	  //文电0 按钮 按下  
         short Byte6bit1;	  //+/- 按钮 按下  
         short Byte6bit2;	  //偏置 按钮 按下  
         short Byte6bit3;	  //标记 按钮 按下  
         short Byte6bit4;	  //修正 按钮 按下
         short Byte6bit5;	  //惯导 按钮 按下  
         short Byte6bit6;	  //驾驶仪 按钮 按下  
         short Byte6bit7;	  //锁定 按钮 按下  
         short Byte7bit0;	  //记录 按钮 按下  
         short Byte7bit1;	  //红外 按钮 按下  
         short Byte7bit2;	  //字符亮度▲ 按钮 按下  
         short Byte7bit3;	  //字符亮度▼ 按钮 按下  
         short Byte7bit4;	  //优先 按钮 按下  
         short Byte7bit5;	  //静默 按钮 按下  
         short Byte7bit6;	  //音量3▲ 按钮 按下  
         short Byte7bit7;	  //音量3▼ 按钮 按下  
         short Byte8bit0;	  //UFCP <--1 按钮 按下  
         short Byte8bit1;	  //UFCP <--2 按钮 按下  
         short Byte8bit2;	  //UFCP <--3 按钮 按下  
         short Byte8bit3;	  //UFCP <--4 按钮 按下  
         short Byte8bit4;	  //UFCP <--5 按钮 按下  
         short Byte8bit5;	  //左屏字符+ 按键 按下  
         short Byte8bit6;	  //左屏字符- 按键 按下  
         short Byte8bit7;	  //左屏左1 按键 按下  
         short Byte9bit0;	  //左屏左2 按键 按下  
         short Byte9bit1;	  //左屏左3 按键 按下  
         short Byte9bit2;	  //左屏左4 按键 按下  
         short Byte9bit3;	  //左屏左5 按键 按下  
         short Byte9bit4;	  //左屏左6 按键 按下  
         short Byte9bit5;	  //左屏左7 按键 按下  
         short Byte9bit6;	  //左屏左8 按键 按下
         short Byte9bit7;   //左屏对比度+ 按键 按下  
         short Byte10bit0;  //左屏对比度- 按键 按下  
         short Byte10bit1;  //左屏下1 按键 按下  
         short Byte10bit2;  //左屏下2 按键 按下  
         short Byte10bit3;  //左屏下3 按键 按下  
         short Byte10bit4;  //左屏下4 按键 按下  
         short Byte10bit5;  //左屏下5 按键 按下  
         short Byte10bit6;  //左屏亮度+ 按键 按下  
         short Byte10bit7;  //左屏亮度- 按键 按下  
         short Byte11bit0;  //左屏开关旋钮 拨到 开  
         short Byte11bit1;  //左屏右1 按键 按下  
         short Byte11bit2;  //左屏右2 按键 按下  
         short Byte11bit3;  //左屏右3 按键 按下  
         short Byte11bit4;  //左屏右4 按键 按下  
         short Byte11bit5;  //左屏右5 按键 按下  
         short Byte11bit6;  //左屏右6 按键 按下  
         short Byte11bit7;  //左屏右7 按键 按下  
         short Byte12bit0;  //左屏右8 按键 按下  
         short Byte12bit1;  //左屏上1 按键 按下  
         short Byte12bit2;  //左屏上2 按键 按下  
         short Byte12bit3;  //左屏上3 按键 按下  
         short Byte12bit4;  //左屏上4 按键 按下  
         short Byte12bit5;  //左屏上5 按键 按下  
         short Byte12bit6;  //中屏字符+ 按键 按下  
         short Byte12bit7;  //中屏字符- 按键 按下  
         short Byte13bit0;  //中屏左1 按键 按下  
         short Byte13bit1;  //中屏左2 按键 按下  
         short Byte13bit2;  //中屏左3 按键 按下
         short Byte13bit3;  //中屏左4 按键 按下  
         short Byte13bit4;  //中屏左5 按键 按下  
         short Byte13bit5;  //中屏左6 按键 按下  
         short Byte13bit6;  //中屏左7 按键 按下  
         short Byte13bit7;  //中屏左8 按键 按下  
         short Byte14bit0;  // 中屏对比度+ 按键，用于增加中屏对比度    
         short Byte14bit1;  // 中屏对比度- 按键，用于减少中屏对比度    
         short Byte14bit2;  //中屏下1 按键，用于操作中屏下的功能1    
         short Byte14bit3;  //中屏下2 按键，用于操作中屏下的功能2  
         short Byte14bit4;  // 中屏下3 按键 按下    
         short Byte14bit5;  // 中屏下4 按键 按下    
         short Byte14bit6;  // 中屏下5 按键 按下    
         short Byte14bit7;  // 中屏亮度+ 按键 按下    
         short Byte15bit0;  // 中屏亮度- 按键 按下    
         short Byte15bit1;  // 中屏开关旋钮 拨到 开    
         short Byte15bit2;  //中屏右1 按键 按下  
         short Byte15bit3;  //中屏右2 按键 按下  
         short Byte15bit4;  //中屏右3 按键 按下    
         short Byte15bit5;  // 中屏右4 按键 按下    
         short Byte15bit6;  // 中屏右5 按键 按下    
         short Byte15bit7;  // 中屏右6 按键 按下    
         short Byte16bit0;  // 中屏右7 按键 按下    
         short Byte16bit1;  // 中屏右8 按键 按下    
         short Byte16bit2;  //中屏上1 按键 按下    
         short Byte16bit3;  //中屏上2 按键 按下  
         short Byte16bit4;  // 中屏上3 按键 按下    
         short Byte16bit5;  // 中屏上4 按键 按下    
         short Byte16bit6;  // 中屏上5 按键 按下    
         short Byte16bit7;  //右屏字符+ 按键 按下   
         short Byte17bit0;  //右屏字符- 按键 按下
         short Byte17bit1;  //右屏左1 按键 按下              
         short Byte17bit2;  //右屏左2 按键 按下                
         short Byte17bit3;  //右屏左3 按键 按下                
         short Byte17bit4;  //右屏左4 按键 按下                
         short Byte17bit5;  //右屏左5 按键 按下                 
         short Byte17bit6;  //右屏左6 按键 按下              
         short Byte17bit7;  //右屏左7 按键 按下               
         short Byte18bit0;  //右屏左8 按键 按下            
         short Byte18bit1;  // 右屏对比度+ 按键 按下             
         short Byte18bit2;  // 右屏对比度- 按键 按下               
         short Byte18bit3;  //右屏下1 按键 按下                 
         short Byte18bit4;  //右屏下2 按键 按下               
         short Byte18bit5;  //右屏下3 按键 按下                  
         short Byte18bit6;  //右屏下4 按键 按下                
         short Byte18bit7;  //右屏下5 按键 按下             
         short Byte19bit0;  // 右屏亮度+ 按键 按下               
         short Byte19bit1;  // 右屏亮度- 按键 按下               
         short Byte19bit2;  // 右屏开关旋钮 拨到 开             
         short Byte19bit3;  //右屏右1 按键 按下                
         short Byte19bit4;  //右屏右2 按键 按下                 
         short Byte19bit5;  //右屏右3 按键 按下                
         short Byte19bit6;  //右屏右4 按键 按下               
         short Byte19bit7;  //右屏右5 按键 按下                
         short Byte20bit0;  //右屏右6 按键 按下                 
         short Byte20bit1;  //右屏右7 按键 按下             
         short Byte20bit2;  //右屏右8 按键 按下               
         short Byte20bit3;  //右屏上1 按键 按下                
         short Byte20bit4;  //右屏上2 按键 按下           
         short Byte20bit5;  //右屏上3 按键 按下               
         short Byte20bit6;  //右屏上4 按键 按下            
         short Byte20bit7;  //右屏上5 按键 按下
			
			
         short Byte21; 			//场压装订 电位计  
         short Byte22; 			//亮/暗 电位计  
         short Byte23; 			//平显对比度 电位计  
         short Byte24; 			//UFCP对比度亮度 电位计  
         short Byte25;			//平显亮度 电位计  
         short Byte26;			//UFCP亮度 电位计

	};
	struct Leftcontrolsole//左操控台
	{
		
			short Byte1bit0;				// 起落架指示灯盒 检灯 按钮 按下  
            short Byte1bit1;				// 应急投放 按钮 按下 
            short Byte1bit2;				// 起落架推到 收起  
            short Byte1bit3;				// 起落架推到 放下  
            short Byte1bit4;				// 起落架信号电源开关 通  
            short Byte1bit5;				// 刹车电源开关 通  
            short Byte1bit6;				// 刹车通道 停机  
            short Byte1bit7;				// 检灯 按钮 按下  
            short Byte2bit0;				// 军械控制拨到 主军械  
            short Byte2bit1;				// 军械控制拨到 训练  
            short Byte2bit2;				// 拖曳诱饵拨到 抛弃  
            short Byte2bit3;				// 拖曳诱饵拨到 放缆 
            short Byte2bit4;				// 空地/空空-空地  
            short Byte2bit5;				// 构型1/构型2-构型1  
            short Byte2bit6;				// 主起/前起/断开-主起  
            short Byte2bit7;				// 主起/前起/断开-断开  
            short Byte3bit0;				// 直接连接/断-直接连接  
            short Byte3bit1;				// 自检测 按钮 按下  
            short Byte3bit2;				// 复位 按钮 按下  
            short Byte3bit3;				// 航向配平-左
            short Byte3bit4;				// 航向配平-右  
            short Byte3bit5;				// 模拟备份/自动-模拟备份  
            short Byte3bit6;				// 交联阀-开  
            short Byte3bit7;				// 起动泵-开  
            short Byte4bit0;				// 输油/加油-输油  
            short Byte4bit1;				// 座椅-升  
            short Byte4bit2;				// 座椅-降          
            short Byte4bit3;				// 左供-开  
            short Byte4bit4;				// 右供-开  
            short Byte4bit5;				// 输油泵-前拨  
            short Byte4bit6;				// 放油阀-通  
            short Byte4bit7;				// 停车 按钮 按下  
            short Byte5bit0;				// 空中起动-前拨  
            short Byte5bit1;				// 自动调节器-前拨  
            short Byte5bit2;				// 应急断加力-前拨  
            short Byte5bit3;				// 地面起动 按钮 按下  
            short Byte5bit4;				// 防喘-前拨  
            short Byte5bit5;				// 增推/战斗/训练-增推  
            short Byte5bit6;				// 增推/战斗/训练-训练  
            short Byte5bit7;				// 起动机/起动/冷开车-起动机  
            short Byte6bit0;				// 起动机/起动/冷开车-冷开车  
            short Byte6bit1;				// 备用氧-手动  
            short Byte6bit2;				 // 上左按键-按下  
            short Byte6bit3;				 // 上中按键-按下  
            short Byte6bit4;				// 上右按键-按下  
            short Byte6bit5;				 // 左上1按键-按下  
            short Byte6bit6;				 // 左上2按键-按下
            short Byte6bit7;				// 左上3按键-按下  
            short Byte7bit0;				// 左上4按键-按下  
            short Byte7bit1;				// 左上5按键-按下  
            short Byte7bit2;				 // 右上1按键-按下  
            short Byte7bit3;				 // 右上2按键-按下 
            short Byte7bit4;					// 右上3按键-按下  
            short Byte7bit5;					// 右上4按键-按下  
            short Byte7bit6;					// 右上5按键-按下  
            short Byte7bit7;				// DKC 按钮 按下  
            short Byte8bit0;				// 销密 按钮 按下
		
            short Byte9;		 // 超短波音量  0，最小；255，最大
            short Byte10; 			// 短波音量  0，最小；255，最大
            short Byte11;			 // 导航音量  0，最小；255，最大
            short Byte12;				// 亮度  0，最小；255，最大
            short Byte13;		// 字符亮度 0，最小；255，最大

		
	};
	struct Rightcontrolsole//右操控台
{

		short Byte1bit0;			// 白天/自动/夜晚-白天  
		short Byte1bit1;			// 白天/自动/夜晚-夜晚  
		short Byte1bit2;			// 自检 按钮 按下  
		short Byte1bit3;			// 4位波段开关-设置  
		short Byte1bit4;			// 4位波段开关-快对  
		short Byte1bit5;			// 4位波段开关-导航  
		short Byte1bit6;			// 4位波段开关-罗经  
		short Byte1bit7;			// 防拥/正常-防拥  
		short Byte2bit0;			// 复位按钮-按下  
		short Byte2bit1;			// 平显-白天  
		short Byte2bit2;			// 平显-夜间  
		short Byte2bit3;			// 下显-白天  
		short Byte2bit4;			// 下显-夜间  
		short Byte2bit5;			// 头显 按键-按下  
		short Byte2bit6;			// 综合调试 按键-按下  
		short Byte2bit7;			// 空白1 按键-按下  
		short Byte3bit0;			// 空白2 按键-按下  
		short Byte3bit1;			// 左吊舱 按键-按下  
		short Byte3bit2;			// 右吊舱 按键-按下  
		short Byte3bit3;			// 空白3 按键-按下  
		short Byte3bit4;			// 空白4 按键-按下  
		short Byte3bit5;			// 外挂管理 按键-按下  
		short Byte3bit6;			// 电子战 按键-按下  
		short Byte3bit7;			// 光电保护 按键-按下  
		short Byte4bit0;			// 诱饵 按键-按下  
		short Byte4bit1;			// 雷达 按键-按下  
		short Byte4bit2;			// 红外雷达 按键-按下  
		short Byte4bit3;			// J数据链 按键-按下  
		short Byte4bit4;			 // 综合记录 按键-按下  
		short Byte4bit5;			// 惯导 按键-按下
		short Byte4bit6;			// 任务机1 按键-按下  
		short Byte4bit7;			// 任务机2 按键-按下  
		short Byte5bit0;			 // 通信导航 按键-按下  
		short Byte5bit1;			// 战斗 按键-按下  
		short Byte5bit2;			// 训练 按键-按下  
		short Byte5bit3;			// 关机 按键-按下  
		short Byte5bit4;			// 蓄电池 钮子开关-前拨  
		short Byte5bit5;			// 交发 钮子开关-前拨
		short Byte5bit6;			// 直发 钮子开关-前拨
		short Byte5bit7;			// 应急发/变整 按钮-按下
		short Byte6bit0;			// 仪表/显示照明 带开关电位器-开关通
		short Byte6bit1;			// 操纵台照明 带开关电位器-开关通
		short Byte6bit2;			// 辅助/应急照明 带开关电位器-开关通
		short Byte6bit3;			// 自动/手动 钮子开关-自动
		short Byte6bit4;			// 加热/制冷 带开关电位器-开关通
		short Byte6bit5;			// 4位波段开关-排烟
		short Byte6bit6;			// 4位波段开关-正常
		short Byte6bit7;			// 4位波段开关-关
		short Byte7bit0;			// 4位波段开关-冲压空气
		short Byte7bit1;			// 除雾 按钮-按下
		short Byte7bit2;			// 选择I 钮子开关-前拨
		short Byte7bit3;			// 选择II 钮子开关-前拨
		short Byte7bit4;			// 夜视/断/正常 钮子开关-夜视
		short Byte7bit5;			// 夜视/断/正常 钮子开关-正常
		short Byte7bit6;			// 防撞灯/断/牵引照明 钮子开关-防撞灯
		short Byte7bit7;			// 防撞灯/断/牵引照明 钮子开关-牵引照明
		short Byte8bit0;			// 空中加油灯 通/断 钮子开关-通
		short Byte8bit1;			// 空中加油灯 带开关电位器-开关通
		short Byte8bit2;			// 航行灯 亮/暗 钮子开关-亮
		short Byte8bit3;			// 航行灯 闪/稳 钮子开关-闪
		short Byte8bit4;			// 6位波段开关-1
		short Byte8bit5;			// 6位波段开关-2
		short Byte8bit6;			// 6位波段开关-3
		short Byte8bit7;			// 6位波段开关-4
		short Byte9bit0;			// 6位波段开关-编码
		short Byte9bit1;			// 6位波段开关-断
		short Byte9bit2;			// 编队灯 带开关电位器-开关通
		short Byte9bit3;			// 切断阀 钮子开关-通油
		short Byte9bit4;			// 捷联航姿 钮子开关-通
		
		short Byte10;		//亮度
		short Byte11;		//亮度
		short Byte12;		//仪表/显示照明
		short Byte13;		//操作台照明
		short Byte14;		//辅助/应急照明
		short Byte15;		//亮度微调
		short Byte16;		//加热/制冷
		short Byte17;		//空中加油灯2
		short Byte18;		//编队灯
	
};
	struct AircraftPilotStick//驾驶杆
	{
		short Byte1bit0;   //S1前推
		short Byte1bit1;   //S1后推
		short Byte1bit2;   //S1左推
		short Byte1bit3;   //S1右推
		short Byte1bit4;   //S1下压
		short Byte1bit5;   //S2前推
		short Byte1bit6;   //S2后推
		short Byte1bit7;   //S2左推
		short Byte2bit0;   //S2右推
		short Byte2bit1;   //S2下压
		short Byte2bit2;   //S3按下
		short Byte2bit3;   //S4第一档行程
		short Byte2bit4;   //S4第二档行程
		short Byte2bit5;   //S5按下
		short Byte2bit6;   //S6上推
		short Byte2bit7;   //S6下推
		short Byte3bit0;   //S6左推
		short Byte3bit1;   //S6右推
		short Byte3bit2;   //S7按下
		short Byte3bit3;   //S8按下
		short Byte3bit4;   //S9按下


	};
	struct AircraftThrottle//油门
	{
		short Byte1bit0;   //T1前推
		short Byte1bit1;   //T1后推
		short Byte1bit2;   //T1左推
		short Byte1bit3;   //T1右推
		short Byte1bit4;   //T1下压
		short Byte1bit5;   //T2上推
		short Byte1bit6;   //T2下推
		short Byte1bit7;   //T2下压
		short Byte2bit0;   //T3前拨
		short Byte2bit1;   //T3后拨
		short Byte2bit2;   //T4前推
		short Byte2bit3;   //T4后推
		short Byte2bit4;   //T4左推
		short Byte2bit5;   //T4右推
		short Byte2bit6;   //T4下压
		short Byte2bit7;   //T5下压
		short Byte3bit0;   //T6按压
		short Byte3bit1;   //T8上推
		short Byte3bit2;   //T8下推
		
		
		
	};

	InstrumentPanel Ins;
	Leftcontrolsole Lcs;
	Rightcontrolsole Rcs;
	AircraftPilotStick Aps;
	AircraftThrottle Atl;
};
#pragma pack(pop)

#pragma pack(push,1)
USTRUCT()
struct FAvionics_11
{
	GENERATED_BODY()
	
	struct InstrumentPanel//仪表盘
	{

		
		char Byte1bit0;	//液压按键
		char Byte1bit1;	//临界按键
		char Byte1bit2;	//主警告按键
		char Byte1bit3;	//电传按键
		char Byte1bit4;	//火警按键
		char Byte1bit5;	//手操纵按键
		char Byte1bit6;	//
		char Byte1bit7;	//
		

		char Byte2bit0;	//查故按键
		char Byte2bit1;	//航路点按键
		char Byte2bit2;	//燃油按键
		char Byte2bit3;	//时间按键
		char Byte2bit4;	//航向按键
		char Byte2bit5;	//跑道按键
		char Byte2bit6;	//识别按键
		char Byte2bit7;	//1按键
		
		char Byte3bit0;	//2按键
		char Byte3bit1;	//3按键
		char Byte3bit2;	//4按键
		char Byte3bit3;	//5按键
		char Byte3bit4;	//6按键
		char Byte3bit5;	//7按键
		char Byte3bit6;	//8按键
		char Byte3bit7;	//9按键
		
		char Byte4bit0;	//返回按键
		char Byte4bit1;	//0按键
		char Byte4bit2;	//空白按键
		char Byte4bit3;	//切偏按键
		char Byte4bit4;	//校正按键
		char Byte4bit5;	//标识按键
		char Byte4bit6;	//再入按键
		char Byte4bit7;	//左1按键
		
		char Byte5bit0;	//左2按键
		char Byte5bit1;	//左3按键
		char Byte5bit2;	//左4按键
		char Byte5bit3;	//右1按键
		char Byte5bit4;	//右2按键
		char Byte5bit5;	//右3按键
		char Byte5bit6;	//右4按键
		char Byte5bit7;	//
		
		char Byte6bit0;	//正负开关-上
		char Byte6bit1;	//正负开关-下
		char Byte6bit2;	//
		char Byte6bit3;	//
		char Byte6bit4;	//
		char Byte6bit5;	//
		char Byte6bit6;	//
		char Byte6bit7;	//
		
		char Byte7bit0;	//作战开关
		char Byte7bit1;	//供电开关
		char Byte7bit2;	//电源开关
		char Byte7bit3;	//引信开关
		char Byte7bit4;	//应急投射-断
		char Byte7bit5;	//应急投射-非导
		char Byte7bit6;	//应急投射-身导
		char Byte7bit7;	//应急投射-翼导
		
		char Byte8bit0;	//应急投射-9/10
		char Byte8bit1;	//应急投射-2/1
		char Byte8bit2;	//应急投射-3/4
		char Byte8bit3;	//应急投射-5/6
		char Byte8bit4;	//应急投射-炮
		char Byte8bit5;	//导弹应急发射按钮
		char Byte8bit6;	//外挂物应急放弃
		char Byte8bit7;	//
		
		char Byte11bit0;	//左下显U1按键
		char Byte11bit1;	//左下显U2按键
		char Byte11bit2;	//左下显U3按键
		char Byte11bit3;	//左下显U4按键
		char Byte11bit4;	//左下显U5按键
		char Byte11bit5;	//左下显D1按键
		char Byte11bit6;	//左下显D2按键
		char Byte11bit7;	//左下显D3按键

		char Byte12bit0;	//左下显D4按键
		char Byte12bit1;	//左下显D5按键
		char Byte12bit2;	//左下显L1按键
		char Byte12bit3;	//左下显L2按键
		char Byte12bit4;	//左下显L3按键
		char Byte12bit5;	//左下显L4按键
		char Byte12bit6;	//左下显L5按键
		char Byte12bit7;	//左下显R1按键
		
		char Byte13bit0;	//左下显R2按键
		char Byte13bit1;	//左下显R3按键
		char Byte13bit2;	//左下显R4按键
		char Byte13bit3;	//左下显R5按键
		char Byte13bit4;	//左下显电源开关
		char Byte13bit5;	///
		char Byte13bit6;	///
		char Byte13bit7;	///

		char Byte14bit0;	//中下显U1按键
		char Byte14bit1;	//中下显U2按键
		char Byte14bit2;	//中下显U3按键
		char Byte14bit3;	//中下显U4按键
		char Byte14bit4;	//中下显U5按键
		char Byte14bit5;	//中下显D1按键
		char Byte14bit6;	//中下显D2按键
		char Byte14bit7;	//中下显D3按键
		
		char Byte15bit0;	//中下显D4按键
		char Byte15bit1;	//中下显D5按键
		char Byte15bit2;	//中下显L1按键
		char Byte15bit3;	//中下显L2按键
		char Byte15bit4;	//中下显L3按键
		char Byte15bit5;	//中下显L4按键
		char Byte15bit6;	//中下显L5按键
		char Byte15bit7;	//中下显R1按键
		
		char Byte16bit0;	//中下显R2按键
		char Byte16bit1;	//中下显R3按键
		char Byte16bit2;	//中下显R4按键
		char Byte16bit3;	//中下显R5按键
		char Byte16bit4;	//中下显电源开关
		char Byte16bit5;	///
		char Byte16bit6;	///
		char Byte16bit7;	///
		
		char Byte17bit0;	//右下显U1按键
		char Byte17bit1;	//右下显U2按键
		char Byte17bit2;	//右下显U3按键
		char Byte17bit3;	//右下显U4按键
		char Byte17bit4;	//右下显U5按键
		char Byte17bit5;	//右下显D1按键
		char Byte17bit6;	//右下显D2按键
		char Byte17bit7;	//右下显D3按键
		
		char Byte18bit0;	//右下显D4按键
		char Byte18bit1;	//右下显D5按键
		char Byte18bit2;	//右下显L1按键
		char Byte18bit3;	//右下显L2按键
		char Byte18bit4;	//右下显L3按键
		char Byte18bit5;	//右下显L4按键
		char Byte18bit6;	//右下显L5按键
		char Byte18bit7;	//右下显R1按键
		
		char Byte19bit0;	//右下显R2按键
		char Byte19bit1;	//右下显R3按键
		char Byte19bit2;	//右下显R4按键
		char Byte19bit3;	//右下显R5按键
		char Byte19bit4;	//右下显电源开关
		char Byte19bit5;	//
		char Byte19bit6;	//
		char Byte19bit7;	//
		
		char Byte20bit0;	//左发参主按键
		char Byte20bit1;	//左发参垂直按键
		char Byte20bit2;	//左发参+按键
		char Byte20bit3;	//左发参-按键
		char Byte20bit4;	//左发参水平按键
		char Byte20bit5;	//左发参发参按键
		char Byte20bit6;	//左发参组合按键
		char Byte20bit7;	///
		
		char Byte21bit0;	//右发参主按键
		char Byte21bit1;	//右发参垂直按键
		char Byte21bit2;	//右发参+按键
		char Byte21bit3;	//右发参-按键
		char Byte21bit4;	//右发参水平按键
		char Byte21bit5;	//右发参发参按键
		char Byte21bit6;	//右发参组合按键
		char Byte21bit7;	///
		
		char Byte27;	//头盔瞄准具电位计
		char Byte28;	//光电雷达灵敏度电位计
		char Byte29;	//左电位计
		char Byte30;	//右电位计

	};

	struct Leftcontrolsole//左操控台
	{
		char Byte1bit0;//交联开关
		char Byte1bit1;//着陆按键
		char Byte1bit2;//引导按键
		char Byte1bit3;//导航按键
		char Byte1bit4;//自动按键
		char Byte1bit5;//无线电高度稳定按键
		char Byte1bit6;//垂线按键
		char Byte1bit7;//气压高度稳定按键

		char Byte2bit0;//清除按键
		char Byte2bit1;//
		char Byte2bit2;//
		char Byte2bit3;//
		char Byte2bit4;//
		char Byte2bit5;//
		char Byte2bit6;//
		char Byte2bit7;//

		char Byte10bit0;//白天/手动/夜-白天
		char Byte10bit1;//白天/手动/夜-手动
		char Byte10bit2;//删除1/正常/删除2-删除1
		char Byte10bit3;//删除1/正常/删除2-正常
		char Byte10bit4;//38开关
		char Byte10bit5;//禁止/正常/降级-禁止
		char Byte10bit6;//禁止/正常/降级-正常
		char Byte10bit7;//干扰应急按钮

		char Byte11bit0;//激光接通开关
		char Byte11bit1;//截获开关
		char Byte11bit2;//探测中心开关
		char Byte11bit3;//头瞄开关
		char Byte11bit4;//辐射/断/假负载-辐射
		char Byte11bit5;//辐射/断/假负载-断
		char Byte11bit6;//指挥机/长机/僚机-指挥机
		char Byte11bit7;//指挥机/长机/僚机-长机

		char Byte12bit0;//指挥机/长机/僚机-僚机
		char Byte12bit1;//47开关
		char Byte12bit2;//双机1/双机2/机群/断开-双机1
		char Byte12bit3;//双机1/双机2/机群/断开-双机2
		char Byte12bit4;//双机1/双机2/机群/断开-机群
		char Byte12bit5;//双机1/双机2/机群/断开-断开
		char Byte12bit6;//数话转换开关
		char Byte12bit7;///

		char Byte13bit0;//加电按键
		char Byte13bit1;//记录按键
		char Byte13bit2;//删除按键
		char Byte13bit3;//标记按键
		char Byte13bit4;//空白按键1
		char Byte13bit5;//电子战按键
		char Byte13bit6;//雷达按键
		char Byte13bit7;//光电按键

		char Byte14bit0;//空白按键2
		char Byte14bit1;//非航电按键
		char Byte14bit2;//数传按键
		char Byte14bit3;//任务机按键
		char Byte14bit4;//航姿按键
		char Byte14bit5;//外挂按键
		char Byte14bit6;//显控1按键
		char Byte14bit7;//显控2按键

		char Byte15bit0;//大气机按键
		char Byte15bit1;//惯导按键
		char Byte15bit2;//通导按键
		char Byte15bit3;//系统开按键
		char Byte15bit4;//系统关按键
		char Byte15bit5;///
		char Byte15bit6;///
		char Byte15bit7;///
		
	};

	struct Rightcontrolsole//右操控台
	{
		char Byte1bit0;//激活按键
		char Byte1bit1;//罗盘按键
		char Byte1bit2;//243按键
		char Byte1bit3;//1按键
		char Byte1bit4;//2按键
		char Byte1bit5;//3按键
		char Byte1bit6;//4按键
		char Byte1bit7;//5按键

		char Byte2bit0;//6按键
		char Byte2bit1;//7按键
		char Byte2bit2;//8按键
		char Byte2bit3;//9按键
		char Byte2bit4;//0按键
		char Byte2bit5;//确认按键
		char Byte2bit6;//模式按键
		char Byte2bit7;//通讯按键

		char Byte3bit0;//导航按键
		char Byte3bit1;//通话按键
		char Byte3bit2;//明密按键
		char Byte3bit3;//亮增按键
		char Byte3bit4;//亮减按键
		char Byte3bit5;///
		char Byte3bit6;///
		char Byte3bit7;///

		char Byte4bit0;//M-0.9
		char Byte4bit1;//M-1.3
		char Byte4bit2;//M-1.8
		char Byte4bit3;//M-2.16
		char Byte4bit4;//引导开关
		char Byte4bit5;//Hkm-4
		char Byte4bit6;//Hkm-7
		char Byte4bit7;//Hkm-11

		char Byte5bit0;//Hkm-14
		char Byte5bit1;//Hkm-17
		char Byte5bit2;//KF6接通按键
		char Byte5bit3;//KF6断开开关
		char Byte5bit4;///
		char Byte5bit5;///
		char Byte5bit6;///
		char Byte5bit7;///

		char Byte6bit0;//
		char Byte6bit1;//
		char Byte6bit2;//
		char Byte6bit3;//
		char Byte6bit4;//蓄电池1开关
		char Byte6bit5;//蓄电池2开关
		char Byte6bit6;//总电源开关
		char Byte6bit7;//总电源开关
	};

	struct AircraftPilotStick//驾驶杆
	{
		char Byte1bit0;//S1按下
		char Byte1bit1;//S2上推
		char Byte1bit2;//S2下推
		char Byte1bit3;//S2左推
		char Byte1bit4;//S2右推
		char Byte1bit5;//S3上推
		char Byte1bit6;//S3下推
		char Byte1bit7;//S3左推

		char Byte2bit0;//S3右推
		char Byte2bit1;//S4按下
		char Byte2bit2;//S7第一档按下（小扳机，自锁）
		char Byte2bit3;//S6下压
		char Byte2bit4;//S5下压（大扳机） 或 S7第二档按下（自复位）
		char Byte2bit5;//S8按下
		char Byte2bit6;//S9按下

		uint16 A;
		uint16 B;
	};
	struct AircraftThrottleLeft//油门左发
	{
		char Byte1bit0;//S2按下
		char Byte1bit1;//S6按下
		uint16 A;
	};

	struct AircraftThrottleRight//油门右发
	{
		char Byte1bit0;//S3按下
		char Byte1bit1;//S4上推
		char Byte1bit2;//S4下推
		char Byte1bit3;//S4左（后）推
		char Byte1bit4;//S4右（前）推
		char Byte1bit5;//S4按压
		char Byte1bit6;//S5上推
		char Byte1bit7;//S5下推

		char Byte2bit0;//S5左（后）推
		char Byte2bit1;//S5右（前）推
		char Byte2bit2;//S5按压
		char Byte2bit3;//S7前推
		char Byte2bit4;//S7后推
		char Byte2bit5;//S7按压
		char Byte2bit6;//S8前拨
		char Byte2bit7;//S8后拨
		
		char Byte3bit0;//S9按下
	};
	InstrumentPanel Ins;
	Leftcontrolsole Lcs;
	Rightcontrolsole Rcs;
	AircraftPilotStick Aps;
	AircraftThrottleLeft Atl;
	AircraftThrottleRight Atr;
};
#pragma pack(pop)

#pragma pack(push,1)
USTRUCT()
struct FAvionics_16
{
	GENERATED_BODY()
	struct InstrumentPanel//仪表盘
	{
		
		char Byte1bit0;		//火警按键
		char Byte1bit1;		//手操纵按键
		char Byte1bit2;		//液压按键
		char Byte1bit3;		//a,ny临界按键
		char Byte1bit4;		//电传按键
		char Byte1bit5;		///
		char Byte1bit6;		///
		char Byte1bit7;		///
		char Byte2bit0;		//干扰应急按钮
		char Byte2bit1;		//炸弹引信
		char Byte2bit2;		//导弹供气
		char Byte2bit3;		//武器供电
		char Byte2bit4;		//武器应急投弃-断
		char Byte2bit5;		//武器应急投弃-全投
		char Byte2bit6;		//武器应急投弃-机身
		char Byte2bit7;		//武器应急投弃-机翼
		char Byte3bit0;		//武器应急投弃-诱饵切缆
		char Byte3bit1;		//武器应急投弃-炮备份
		char Byte3bit2;		//武器应急投弃-下压
		char Byte3bit3;		//主警告按键
		char Byte3bit4;		///
		char Byte3bit5;		///
		char Byte3bit6;		///
		char Byte3bit7;		///
		char Byte4bit0;		//方向舵校准-左
		char Byte4bit1;		//方向舵校准-右
		char Byte4bit2;		//起落架放下按键
		char Byte4bit3;		///
		char Byte4bit4;		///
		char Byte4bit5;		///
		char Byte4bit6;		///
		char Byte4bit7;		///
		char Byte5bit0;		//左上1按键
		char Byte5bit1;		//左上2按键
		char Byte5bit2;		//左上3按键
		char Byte5bit3;		//左上4按键
		char Byte5bit4;		//左上周边按键1
		char Byte5bit5;		//左上周边按键2
		char Byte5bit6;		//左上周边按键3
		char Byte5bit7;		//左上周边按键4
		char Byte6bit0;		//左上周边按键5
		char Byte6bit1;		//右上周边按键1
		char Byte6bit2;		//右上周边按键2
		char Byte6bit3;		//右上周边按键3
		char Byte6bit4;		//右上周边按键4
		char Byte6bit5;		//右上周边按键5
		char Byte6bit6;		//查故按键
		char Byte6bit7;		//备用按键
		char Byte7bit0;		//确认按键
		char Byte7bit1;		//返回按键
		char Byte7bit2;		//O自飞控按键
		char Byte7bit3;		//引导按键
		char Byte7bit4;		//设置按键
		char Byte7bit5;		//防拥按键
		char Byte7bit6;		//记录按键
		char Byte7bit7;		//O记录按键
		char Byte8bit0;		//O降级按键
		char Byte8bit1;		//O通导备按键
		char Byte8bit2;		//通导按键
		char Byte8bit3;		//机场按键
		char Byte8bit4;		//航路点按键
		char Byte8bit5;		//查看按键
		char Byte8bit6;		//燃油按键
		char Byte8bit7;		//标/校按键
		char Byte9bit0;		//O组合按键
		char Byte9bit1;		//辐射按键
		char Byte9bit2;		///
		char Byte9bit3;		///
		char Byte9bit4;		///
		char Byte9bit5;		///
		char Byte9bit6;		///
		char Byte9bit7; 	///
		char Byte10bit0;	//液电按键
		char Byte10bit1;	//发参按键
		char Byte10bit2;	//水平按键
		char Byte10bit3;	//确认按键
		char Byte10bit4;	//垂直按键
		char Byte10bit5;	//检查按键
		char Byte10bit6;	//菜单按键
		char Byte10bit7;	//+按键
		char Byte11bit0;	//-按键
		char Byte11bit1;	///
		char Byte11bit2;	///
		char Byte11bit3;	///
		char Byte11bit4;	///
		char Byte11bit5;	///
		char Byte11bit6;	///
		char Byte11bit7;	///
		char Byte12bit0;	//上左按键1
		char Byte12bit1;	//上左按键2
		char Byte12bit2;	//上左按键3
		char Byte12bit3;	//上左按键4
		char Byte12bit4;	//上左按键5
		char Byte12bit5;	//上左按键6
		char Byte12bit6;	//上左按键7
		char Byte12bit7;	//上左按键8
		char Byte13bit0;	//上左按键9
		char Byte13bit1;	//上左按键10
		char Byte13bit2;	//上左按键11
		char Byte13bit3;	//上左按键12
		char Byte13bit4;	//下左按键1
		char Byte13bit5;	//下左按键2
		char Byte13bit6;	//下左按键3
		char Byte13bit7;	//下左按键4
		char Byte14bit0;	//下左按键5
		char Byte14bit1;	//下左按键6
		char Byte14bit2;	//下左按键7
		char Byte14bit3;	//下左按键8
		char Byte14bit4;	//下左按键9
		char Byte14bit5;	//下左按键10
		char Byte14bit6;	//下左按键11
		char Byte14bit7;	//下左按键12
		char Byte15bit0;	//左上按键1
		char Byte15bit1;	//左上按键2
		char Byte15bit2;	//左上按键3
		char Byte15bit3;	//左上按键4
		char Byte15bit4;	//左上按键5
		char Byte15bit5;	//左上按键6
		char Byte15bit6;	//左上按键7
		char Byte15bit7;	//左上按键8
		char Byte16bit0;	//右上按键1
		char Byte16bit1;	//右上按键2
		char Byte16bit2;	//右上按键3
		char Byte16bit3;	//右上按键4
		char Byte16bit4;	//右上按键5
		char Byte16bit5;	//右上按键6
		char Byte16bit6;	//右上按键7
		char Byte16bit7;	//右上按键8
		char Byte17bit0;	//字符按键+
		char Byte17bit1;	//字符按键-
		char Byte17bit2;	//对比度按键+
		char Byte17bit3;	//对比度按键-
		char Byte17bit4;	//亮度按键+
		char Byte17bit5;	//亮度按键-
		char Byte17bit6;	//旋钮开关
		char Byte17bit7;	//
		char Byte18bit0;	//上左按键1
		char Byte18bit1;	//上左按键2
		char Byte18bit2;	//上左按键3
		char Byte18bit3;	//上左按键4
		char Byte18bit4;	//上左按键5
		char Byte18bit5;	//上左按键6
		char Byte18bit6;	//上左按键7
		char Byte18bit7;	//上左按键8
		char Byte19bit0;	//上左按键9
		char Byte19bit1;	//上左按键10
		char Byte19bit2;	//上左按键11
		char Byte19bit3;	//上左按键12
		char Byte19bit4;	//下左按键1
		char Byte19bit5;	//下左按键2
		char Byte19bit6;	//下左按键3
		char Byte19bit7;	//下左按键4
		char Byte20bit0;	//下左按键5
		char Byte20bit1;	//下左按键6
		char Byte20bit2;	//下左按键7
		char Byte20bit3;	//下左按键8
		char Byte20bit4;	//下左按键9
		char Byte20bit5;	//下左按键10
		char Byte20bit6;	//下左按键11
		char Byte20bit7;	//下左按键12
		char Byte21bit0;	//左上按键1
		char Byte21bit1;	//左上按键2
		char Byte21bit2;	//左上按键3
		char Byte21bit3;	//左上按键4
		char Byte21bit4;	//左上按键5
		char Byte21bit5;	//左上按键6
		char Byte21bit6;	//左上按键7
		char Byte21bit7;	//左上按键8
		char Byte22bit0;	//右上按键1
		char Byte22bit1;	//右上按键2
		char Byte22bit2;	//右上按键3
		char Byte22bit3;	//右上按键4
		char Byte22bit4;	//右上按键5
		char Byte22bit5;	//右上按键6
		char Byte22bit6;	//右上按键7
		char Byte22bit7;	//右上按键8
		char Byte23bit0;	//字符按键+
		char Byte23bit1;	//字符按键-
		char Byte23bit2;	//对比度按键+
		char Byte23bit3;	//对比度按键-
		char Byte23bit4;	//亮度按键+
		char Byte23bit5;	//亮度按键-
		char Byte23bit6;	//旋钮开关
		char Byte23bit7;	//
		char Byte24;	//手动板位给定左电位计
		char Byte25;	//手动板位给定右电位计
		char Byte26;	//平显电位计
		char Byte27;	//平显光栅电位计
		char Byte28;	//头盔电位计
		char Byte29;	//窗口电位计
		
	};
	struct Leftcontrolsole//左操控台
	{
		char Byte1bit0;//起落架收起
		char Byte1bit1;//空中加油打开/自动/关闭-打开
		char Byte1bit2;//空中加油打开/自动/关闭-关闭
		char Byte1bit3;//加油探管开关
		char Byte1bit4;//加油灯开关
		char Byte1bit5;//探管应急放开关
		char Byte1bit6;//放油开关
		char Byte1bit7;///

		char Byte3bit0;//大气传感器加温开关
		char Byte3bit1;//关闭空调开关
		char Byte3bit2;//座舱加温开关-自动
		char Byte3bit3;//座舱加温开关-热
		char Byte3bit4;//座舱加温开关-冷
		char Byte3bit5;//风挡防冰开关
		char Byte3bit6;//前轮操纵开关
		char Byte3bit7;//着陆开关-着陆

		char Byte7bit0;	//航电开关
		char Byte7bit1;	//告警开关
		char Byte7bit2;	//武器总开关
		char Byte7bit3;	//辐射开关
		char Byte7bit4;	//辐射管理-静默
		char Byte7bit5;	//辐射管理-准静默
		char Byte7bit6;	//辐射管理-正常
		char Byte7bit7;	//辐射管理-备用
		char Byte8bit0;	//嵌入训练开关
		char Byte8bit1;	//头盔降噪开关
		char Byte8bit2;	//备用开关
		char Byte8bit3;	//显示开关
		char Byte8bit4;	//诱饵开关-投放
		char Byte8bit5;	//诱饵开关-抛弃
		char Byte8bit6;	//高度表按键
		char Byte8bit7;	//通导按键
		char Byte9bit0;	//JIDS按键
		char Byte9bit1;	//上右2空白按键
		char Byte9bit2;	//上右1空白按键
		char Byte9bit3;	//红外按键
		char Byte9bit4;	//对抗按键
		char Byte9bit5;	//雷达按键
		char Byte9bit6;	//光电按键
		char Byte9bit7; //中右1空白按键
		char Byte10bit0;//任务机按键
		char Byte10bit1;//外挂按键
		char Byte10bit2;//大气机按键
		char Byte10bit3;//惯导1按键
		char Byte10bit4;//惯导2按键
		char Byte10bit5;//系统开按键
		char Byte10bit6;//系统关按键
		char Byte10bit7;//

		char Byte11bit0;//直流开关
		
	};
	struct Rightcontrolsole//右操控台
{
		char Byte1bit0;//模式-断
		char Byte1bit1;//模式-超短波
		char Byte1bit2;//模式-短波
		char Byte1bit3;//模式-卫通
		char Byte1bit4;//模式-数话
		char Byte1bit5;//毁钥按键
		char Byte1bit6;//通话按键
		char Byte1bit7;//数/话按键
		char Byte2bit0;//音响按键
		char Byte2bit1;//罗盘按键
		

		char Byte3bit0;//仪表台电位计开关
		char Byte3bit1;//操纵台电位计开关
		char Byte3bit2;//泛光灯电位计开关
		char Byte3bit3;//检灯按键
		char Byte3bit4;//航行编队灯-断
		char Byte3bit5;//航行编队灯-防撞
		char Byte3bit6;//航行编队灯-航行
		char Byte3bit7;//航行编队灯-100
		char Byte4bit0;//航行编队灯-60
		char Byte4bit1;//航行编队灯-20
		char Byte4bit2;//隐蔽/友好开关
		char Byte4bit3;//夜视/常规开关
		char Byte4bit4;//自动/手动开关
		char Byte4bit5;//夜/昼
		char Byte4bit6;//
		char Byte4bit7;//

		char Byte5bit0;//左发动机起按键
		char Byte5bit1;//右发动机起按键
		char Byte5bit2;//防冰自动/断开/手动-自动
		char Byte5bit3;//防冰自动/断开/手动-手动
		char Byte5bit4;//蓄电池1开关
		char Byte5bit5;//蓄电池2开关
		char Byte5bit6;//地面电源/蓄电池配电装置
		char Byte5bit7;//应急直流发电机
		char Byte6bit0;//左交流发电机开关
		char Byte6bit1;//右交流发电机开关
		char Byte6bit2;//"左发冷开车/启动/左起冷开车-左发冷开车"
		char Byte6bit3;//"左发冷开车/启动/左起冷开车-左起冷开车"
		char Byte6bit4;//右发冷开车/启动/右起冷开车-右发冷开车"
		char Byte6bit5;//"右发冷开车/启动/
		char Byte6bit6;//右起冷开车-右起冷开车"
		char Byte6bit7;//左发停车按钮
		char Byte7bit0;//右发停车按钮
		char Byte7bit1;//加力自动节流开关
		char Byte7bit2;//变流器开关
		char Byte7bit3;//
		char Byte7bit4;//
		char Byte7bit5;//
		char Byte7bit6;//
		char Byte7bit7;//

		char Byte8bit0;//PBIT按键
		char Byte8bit1;//MBIT按键

		char Byte9;	//数话音量
		char Byte10;//短波音量
		char Byte11;//电子战音量
		char Byte12;//导航音量
		char Byte13;//超短波音量
		char Byte14;//内话音量
		char Byte15;//仪表台
		char Byte16;//操纵台
		char Byte17;//泛光灯
		char Byte18;//信号灯
		
		
};
	struct AircraftPilotStick//驾驶杆
	{
		char Byte1bit0;//S1按下
		char Byte1bit1;//S2上推
		char Byte1bit2;//S2下推
		char Byte1bit3;//S2左推
		char Byte1bit4;//S2右推
		char Byte1bit5;//S2按压
		char Byte1bit6;//S3上推
		char Byte1bit7;//S3下推
		char Byte2bit0;//S3左推
		char Byte2bit1;//S3右推
		char Byte2bit2;//S4按下
		char Byte2bit3;//S6第一档按下（小扳机，自锁）
		char Byte2bit4;//S5下压（大扳机） 或 S6第二档按下（自复位）
		char Byte2bit5;//S7按下
		char Byte2bit6;//S8按压
		char Byte2bit7;//S9上推
		char Byte3bit0;//S9下推
		char Byte3bit1;//S9按压
		char Byte3bit2;//S10按下


		uint16 A;//S8X
		uint16 B;//S8Y
	};
	struct AircraftThrottleLeft//油门左发
	{
		char Byte1bit0;//S2按下
		char Byte1bit1;//S6按下
		uint16 A;//S1X
	};
	struct AircraftThrottleRight//油门右发
	{
		char Byte1bit0;//S3前推
		char Byte1bit1;//S3后推
		char Byte1bit2;//S3按压
		char Byte1bit3;//S4上推
		char Byte1bit4;//S4下推
		char Byte1bit5;//S4左推（后）
		char Byte1bit6;//S4右推（前）
		char Byte1bit7;//S4按压
		char Byte2bit0;//S5上推
		char Byte2bit1;//S5下推
		char Byte2bit2;//S5左推（后）
		char Byte2bit3;//S5右推（前）
		char Byte2bit4;//S5按压
		char Byte2bit5;//S7上推
		char Byte2bit6;//S7下推
		char Byte2bit7;//S7按压
		char Byte3bit0;//S8前推
		char Byte3bit1;//S8后推
		char Byte3bit2;//S9按下
		char Byte3bit3;//S10上推
		char Byte3bit4;//S10下推
		char Byte3bit5;//S10按压
	};
	InstrumentPanel Ins;
	Leftcontrolsole Lcs;
	Rightcontrolsole Rcs;
	AircraftPilotStick Aps;
	AircraftThrottleLeft Atl;
	AircraftThrottleRight Atr;
};
#pragma pack(pop)

#pragma pack(push,1)
USTRUCT()
struct FAvionics_20
{
	GENERATED_BODY()
	struct InstrumentPanel//仪表盘
	{
		
		char Byte1bit0;	//放伞/抛伞开关
		char Byte1bit1;	//左发火警按键
		char Byte1bit2;	//右发火警按键
		char Byte1bit3;	//警告按键
		char Byte1bit4;	//灭火按键
		char Byte1bit5;	//IPU火警按键
		char Byte1bit6;	//飞控失效按键
		char Byte1bit7;	///
		char Byte2bit0;	//左上方上按键
		char Byte2bit1;	//左上方下按键
		char Byte2bit2;	//设置1按键
		char Byte2bit3;	//真/地2按键
		char Byte2bit4;	//3按键
		char Byte2bit5;	//4按键
		char Byte2bit6;	//真/磁5按键
		char Byte2bit7;	//6按键
		char Byte3bit0;	//秒表7按键
		char Byte3bit1;	//8按键
		char Byte3bit2;	//9按键
		char Byte3bit3;	//返回按键
		char Byte3bit4;	//0
		char Byte3bit5;	//+/-按键
		char Byte3bit6;	//左上周边键1
		char Byte3bit7;	//左上周边键2
		char Byte4bit0;	//左上周边键3
		char Byte4bit1;	//左上周边键4
		char Byte4bit2;	//右上方上按键
		char Byte4bit3;	//右上方下按键
		char Byte4bit4;	//驾驶仪按键
		char Byte4bit5;	//自动油门按键
		char Byte4bit6;	//修正按键
		char Byte4bit7;	//惯导按键
		char Byte5bit0;	//左上周边键1
		char Byte5bit1;	//左上周边键2
		char Byte5bit2;	//左上周边键3
		char Byte5bit3;	//左上周边键4
		char Byte5bit4;	///
		char Byte5bit5;	///
		char Byte5bit6;	///
		char Byte5bit7;	///
		char Byte6bit0;	//上按键1
		char Byte6bit1;	//上按键2
		char Byte6bit2;	//上按键3
		char Byte6bit3;	//上按键4
		char Byte6bit4;	//上按键5
		char Byte6bit5;	//下方上按键
		char Byte6bit6;	//下方下按键
		char Byte6bit7;	///
		char Byte7bit0;	//状态条按键
		char Byte7bit1;	//主菜单按键
		char Byte7bit2;	//恢复按键
		char Byte7bit3;	//备份按键
		char Byte7bit4;	//返回按键
		char Byte7bit5;	//下方上按键
		char Byte7bit6;	//下方下按键
		char Byte7bit7;	///
		char Byte8bit0;	//开/关
		char Byte8bit1;	//左上方上按键
		char Byte8bit2;	//左上方下按键
		char Byte8bit3;	//左上按键1
		char Byte8bit4;	//左上按键2
		char Byte8bit5;	//左上按键3
		char Byte8bit6;	//左上按键4
		char Byte8bit7;	//左上按键5
		char Byte9bit0;	//右上按键1
		char Byte9bit1;	//右上按键2
		char Byte9bit2;	//右上按键3
		char Byte9bit3;	//右上按键4
		char Byte9bit4;	//右上按键5
		char Byte9bit5;	//上左按键1
		char Byte9bit6;	//上左按键2
		char Byte9bit7;	//上左按键3
		char Byte10bit0;//上左按键4
		char Byte10bit1;//上左按键5
		char Byte10bit2;//下左按键1
		char Byte10bit3;//下左按键2
		char Byte10bit4;//下左按键3
		char Byte10bit5;//下左按键4
		char Byte10bit6;//下左按键5
		char Byte10bit7;//
		
	};
	struct Leftcontrolsole//左操控台
	{
		char Byte1bit0;//BFCC/VMC 开关
		char Byte1bit1;//作战/断/训练 开关 - 作战
		char Byte1bit2;//作战/断/训练 开关 - 训练
		char Byte1bit3;//应急放起落架开关
		char Byte1bit4;//着/滑灯 开关 - 着/滑灯
		char Byte1bit5;//着/滑灯 开关 - 断
		char Byte1bit6;//旋转带按压开关 - 1
		char Byte1bit7;//旋转带按压开关 - 2
		char Byte2bit0;//旋转带按压开关 - 3
		char Byte2bit1;//旋转带按压开关 - 4
		char Byte2bit2;//旋转带按压开关 - 5
		char Byte2bit3;//旋转带按压开关 - 按压
		char Byte2bit4;//起落架手柄收起
		char Byte2bit5;///
		char Byte2bit6;///
		char Byte2bit7;///
		char Byte5bit0;//飞控直连开关
		char Byte5bit1;//航向配平开关 - 左
		char Byte5bit2;//航向配平开关 - 右
		char Byte5bit3;//蓄电池开关
		char Byte5bit4;//直发（左）开关
		char Byte5bit5;//直发（右）开关
		char Byte5bit6;///
		char Byte5bit7;///
		
	};
	struct Rightcontrolsole//右操控台
	{
		char Byte5bit0;//供油阀（左）开关 - 通油 
		char Byte5bit1;//供油阀（左）开关 - 断油 
		char Byte5bit2;//供油阀（右）开关 - 通油 
		char Byte5bit3;//供油阀（右）开关 - 断油 
		
	};
	struct AircraftPilotStick//驾驶杆
	{
		char Byte1bit0;//S1上推
		char Byte1bit1;//S1下推
		char Byte1bit2;//S1左推
		char Byte1bit3;//S1右推
		char Byte1bit4;//S1下压
		char Byte1bit5;//S2按下
		char Byte1bit6;//S3上推
		char Byte1bit7;//S3下推
		char Byte2bit0;//S3左推
		char Byte2bit1;//S3右推
		char Byte2bit2;//S4上推
		char Byte2bit3;//S4下推
		char Byte2bit4;//S4左推
		char Byte2bit5;//S4右推
		char Byte2bit6;//S4下压
		char Byte2bit7;//S5按下
		char Byte3bit0;//S6前推
		char Byte3bit1;//S6后推
		char Byte3bit2;//S6上推
		char Byte3bit3;//S6下推
		char Byte3bit4;//S7第1档
		char Byte3bit5;//S7第2档
		char Byte3bit6;//S8前推
		char Byte3bit7;//S8后推
		char Byte4bit0;//S8左推
		char Byte4bit1;//S8右推
		char Byte4bit2;//S8下压
		char Byte4bit3;//S9按下
		
	};
	struct AircraftThrottleLeft//油门左发
	{
		char Byte1bit0;//T7上推
		char Byte1bit1;//T7下推
		char Byte1bit2;//T7按压
		char Byte1bit3;//T8按压
		char Byte1bit4;//T10上推
		char Byte1bit5;//T10下推
		uint16 A;
	};
	struct AircraftThrottleRight//油门右发
	{
		char Byte1bit0;//T1前推
		char Byte1bit1;//T1后推
		char Byte1bit2;//T1上推
		char Byte1bit3;//T1下推
		char Byte1bit4;//T1按压
		char Byte1bit5;//T2按压
		char Byte1bit6;//T3前推
		char Byte1bit7;//T3后推
		char Byte2bit0;//T3上推
		char Byte2bit1;//T3下推
		char Byte2bit2;//T3按压
		char Byte2bit3;//T4上推
		char Byte2bit4;//T4下推
		char Byte2bit5;//T4前推
		char Byte2bit6;//T4后推
		char Byte2bit7;//T4按压
		char Byte3bit0;//T5前推
		char Byte3bit1;//T5后推
		char Byte3bit2;//T6按压
		char Byte3bit3;//T9上推
		char Byte3bit4;//T9下推
		char Byte3bit5;//T9按压

		uint16 A;
		uint16 B;
		
	};
	InstrumentPanel Ins;
	Leftcontrolsole Lcs;
	Rightcontrolsole Rcs;
	AircraftPilotStick Aps;
	AircraftThrottleLeft Atl;
	AircraftThrottleRight Atr;
};
#pragma pack(pop)

UCLASS()
class COCKPITPORT_API ACockpitPortGameStateBase : public AGameStateBase
{
	GENERATED_BODY()
public:
	ACockpitPortGameStateBase();
	FFlight10_FS Fs10;
	
	FFlight11_FS Fs11;
	
	FFlight16_FS Fs16;
	
	FFlight20_FS Fs20;
	
	FAvionics_10 A10;
	FAvionics_11 A11;
	FAvionics_16 A16;
	FAvionics_20 A20;
	
};
