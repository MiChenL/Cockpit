// Copyright Epic Games, Inc. All Rights Reserved.

#include "CockpitPort.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, CockpitPort, "CockpitPort" );
