// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "FSendThread.h"
#include "GameFramework/GameModeBase.h"
#include "CockpitPortGameModeBase.generated.h"

/**
 * 
 */

UCLASS()
class COCKPITPORT_API ACockpitPortGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	ACockpitPortGameModeBase();
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
public:
	//飞机型号
	int32 PlaneModel;
	//发送端口
	TArray<int32>SendPorts{4001,4002,4003,4004,4005,4006,4007,4008};
	//发包实例
	TArray<class ASendCockpitPort*>SendCockpitPorts;
	class ASendCockpitPort*MyObject;
	//自定义线程
	TArray<class FSendThread*>SendThreads;
	class FSendThread* MyThread;
	//读取本地INI配置文件
	FString ReadINIFileString(FString Section,FString Key);
	
	int32 ReadINIFileInt(FString Section,FString Key);
	UPROPERTY(BlueprintReadWrite)
	bool IsStop=false;
	
};
